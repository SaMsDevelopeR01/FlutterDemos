import 'package:cool_alert/cool_alert.dart';
import 'package:firebasereg/main.dart';
import 'package:firebasereg/repository/firebase_api_client.dart';
import 'package:firebasereg/repository/firebase_repository.dart';
import 'package:firebasereg/update.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'AddData.dart';
import 'bloc/firebase_bloc.dart';
import 'bloc/firebase_event.dart';
import 'bloc/firebase_state.dart';
import 'models/note.dart';
import 'package:http/http.dart' as http;

class HomePage extends StatefulWidget {
  const HomePage({Key key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  var email = "";
  Note note;

  _HomePageState();

  Future<String> getValidationData(BuildContext mainContext) async {
    final SharedPreferences sharedPreferences =
        await SharedPreferences.getInstance();
    BlocProvider.of<FirebaseBloc>(mainContext).add(ResetUsersList());
    var obtainedEmail = sharedPreferences.getString('emailId');
    return obtainedEmail;
  }

  @override
  Widget build(BuildContext mainContext) {
    BlocProvider.of<FirebaseBloc>(mainContext).add(ResetUsersList());

    return Scaffold(
      appBar: AppBar(title: Text("Home  ${this.email}"), actions: <Widget>[
        FlatButton(
          minWidth: 5.0,
          onPressed: () async {
            CoolAlert.show(
                context: mainContext,
                type: CoolAlertType.confirm,
                text: "Are you sure you want to Logout?",
                onConfirmBtnTap: () async {
                  var sharedPreferences = await SharedPreferences.getInstance();
                  BlocProvider.of<FirebaseBloc>(mainContext)
                      .add(ResetLoginData());
                  sharedPreferences.remove('emailId');
                  sharedPreferences.clear();
                  final FirebaseRepository repository = FirebaseRepository(
                    firebaseApiClient: FirebaseApiClient(
                      httpClient: http.Client(),
                    ),
                  );

                  await Navigator.of(mainContext).pop();
                  await Navigator.of(mainContext).push(MaterialPageRoute(
                      builder: (_) => BlocProvider.value(
                          value: BlocProvider.of<FirebaseBloc>(mainContext),
                          child: MyApp(
                            repository: repository,
                          ))));
                });
          },
          child: Icon(
            Icons.logout,
            color: Colors.white,
          ),
        ),
      ]),
      body: FutureBuilder<String>(
          future: getValidationData(mainContext),
          builder: (BuildContext context, AsyncSnapshot<String> snapshot) {
            this.email = snapshot.data;
            return BlocBuilder<FirebaseBloc, FirebaseState>(
                builder: (context, state) {
              if (state is DataEmpty) {
                BlocProvider.of<FirebaseBloc>(mainContext)
                    .add(fetchData(email));
              }

              if (state is DataError) {
                return Center(
                  child: Text('Failed to Users Data'),
                );
              }

              if (state is DataLoaded) {
                return Container(
                    child: Column(
                  children: [
                    Flexible(child: getNoteListView(mainContext, state.Data)),
                    Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Container(
                        child: Align(
                          alignment: Alignment.bottomLeft,
                          child: Text(
                            'Total: ${state.Data.length}',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w800,
                              color: Colors.blue,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ));
              }

              if (state is UserDetailDelete) {
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  BlocProvider.of<FirebaseBloc>(mainContext)
                      .add(ResetUsersList());
                });
              }

              return Center(
                child: CircularProgressIndicator(),
              );
            });
          }),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          var res = await Navigator.of(mainContext).push(MaterialPageRoute(
              builder: (_) => BlocProvider.value(
                  value: BlocProvider.of<FirebaseBloc>(mainContext),
                  child: AddData(
                    email: email,
                  ))));

          if (res != null && res == true) {
            BlocProvider.of<FirebaseBloc>(mainContext).add(ResetUsersList());
          }
        },
        child: Icon(Icons.add),
      ),
    );
  }

  Widget getNoteListView(BuildContext mainContext, List<Note> arrayNotes) {
    print(arrayNotes);
    TextStyle titleStyle = Theme.of(context).textTheme.subhead;
    return arrayNotes.length == 0
        ? Container(
            child: Center(
                child: Text(
              "No Data Found",
              style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.bold,
              ),
            )),
          )
        : ListView.builder(
            itemCount: arrayNotes.length,
            itemBuilder: (BuildContext context, int position) {
              return Column(
                children: [
                  Dismissible(
                    key: Key(arrayNotes[position].toString()),
                    child: ListTile(
                      leading: CircleAvatar(
                          backgroundColor: Colors.yellow,
                          child: ClipRRect(
                              borderRadius: BorderRadius.circular(50.0),
                              child: Image.network(
                                arrayNotes[position].picture,
                                fit: BoxFit.cover,
                                height: 100,
                                width: 100,
                              ))),
                      title: Text(
                        arrayNotes[position].title,
                        style: titleStyle,
                      ),
                      subtitle: Text(arrayNotes[position].detail),
                    ),
                    secondaryBackground: slideLeftBackground(),
                    background: slideRightBackground(),
                    confirmDismiss: (direction) async {
                      if (direction == DismissDirection.endToStart) {
                        final bool res = await showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return deleteDialog(
                                  mainContext,
                                  arrayNotes[position].title,
                                  arrayNotes[position].id);
                            });
                        return res;
                      } else {
                        final bool res = await showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return updateDialog(
                                  mainContext,
                                  arrayNotes[position].title,
                                  arrayNotes[position].id);
                            });
                        return res;
                      }
                    },
                  ),
                  Divider(
                    height: 2.0,
                  ),
                ],
              );
            });
  }

  Widget deleteDialog(BuildContext mainContext, String title, String id) {
    return AlertDialog(
      content: Text("Are you sure you want to delete '$title' ?"),
      actions: <Widget>[
        FlatButton(
          child: Text(
            "Cancel",
            style: TextStyle(color: Colors.black),
          ),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        FlatButton(
          child: Text(
            "Delete",
            style: TextStyle(color: Colors.red),
          ),
          onPressed: () {
            BlocProvider.of<FirebaseBloc>(mainContext)
                .add(DeleteUserDetail(id));
            // setState(() {
            //arrayNotes.removeAt(position);
            //});
            Navigator.of(context).pop();
          },
        ),
      ],
    );
  }

  Widget updateDialog(BuildContext mainContext, String title, String id) {
    return AlertDialog(
      content: Text("Are you sure you want to edit '$title' ?"),
      actions: <Widget>[
        FlatButton(
          child: Text(
            "Cancel",
            style: TextStyle(color: Colors.black),
          ),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        FlatButton(
          child: Text(
            "Edit",
            style: TextStyle(color: Colors.green),
          ),
          onPressed: () async {
            Navigator.of(context).pop();
            var value = await Navigator.of(mainContext).push(MaterialPageRoute(
                builder: (_) => BlocProvider.value(
                      value: BlocProvider.of<FirebaseBloc>(mainContext),
                      child: UpdatePage(
                        email: email,
                        id: id,
                      ),
                    )));
            Navigator.of(context).pop();
            print("RES UDPAED:$value");
            if (value != null && value) {
              //upadate success
              CoolAlert.show(
                context: context,
                type: CoolAlertType.success,
                text: "Profile updated successfully!",
              );
            }
          },
        ),
      ],
    );
  }

  Widget slideLeftBackground() {
    return Container(
      color: Colors.red,
      child: Align(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            Icon(
              Icons.delete,
              color: Colors.white,
            ),
            Text(
              " Delete",
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
              textAlign: TextAlign.right,
            ),
            SizedBox(
              width: 20,
            ),
          ],
        ),
        alignment: Alignment.centerRight,
      ),
    );
  }

  Widget slideRightBackground() {
    return Container(
      color: Colors.green,
      child: Align(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            SizedBox(
              width: 20,
            ),
            Icon(
              Icons.edit,
              color: Colors.white,
            ),
            Text(
              " Edit",
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
              textAlign: TextAlign.left,
            ),
          ],
        ),
        alignment: Alignment.centerLeft,
      ),
    );
  }
}
