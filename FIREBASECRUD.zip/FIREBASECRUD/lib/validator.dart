class Validator {
  String password;

  static isValidEmail(String email) {
    if (email == null) {
      return 'Please Enter Email';
    } else if (!RegExp(
            r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
        .hasMatch(email)) {
      return 'Enter Valid Email';
    }
    return null;
  }

  static isValidPassword(String password) {
    if (password == null) {
      return 'Please Enter Password';
    } else if (!RegExp(
            r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,14}$')
        .hasMatch(password)) {
      return 'Enter Valid Password';
    } else {
      return null;
    }
  }

  static isValidConfirmPassword(String password, String confirmPassword) {
    if (confirmPassword == null) {
      return 'Please Enter Confirm Password';
    } else if (confirmPassword != password) {
      return 'Not Match';
    } else if (!RegExp(
            r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,14}$')
        .hasMatch(confirmPassword)) {
      return 'Enter Valid Confirm Password';
    } else {
      return null;
    }
  }

  static isValidMobileNo(String phoneNo) {
    if (phoneNo.length < 0 || phoneNo.length == 0 || phoneNo.length == 10) {
      return null;
    } else {
      return 'Enter Valid Phone No.';
    }
  }

  static isValidTitle(String title) {
    if (title == null) {
      return 'Please Enter Title';
    } else if (title.length < 4 || title.length > 12) {
      return 'Title length should be between 4 to 12 character';
    }
    return null;
  }

  static isValidDetail(String detail) {
    if (detail == null) {
      return 'Please Enter Description';
    } else if (detail.length > 25) {
      return 'Description length must be less then 25';
    }
    return null;
  }
}
