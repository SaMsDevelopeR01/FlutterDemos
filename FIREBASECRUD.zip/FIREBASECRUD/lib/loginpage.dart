import 'package:firebasereg/bloc/firebase_bloc.dart';
import 'package:firebasereg/bloc/firebase_event.dart';
import 'package:firebasereg/bloc/firebase_state.dart';
import 'package:firebasereg/main.dart';
import 'package:firebasereg/registerpage.dart';
import 'package:firebasereg/repository/firebase_api_client.dart';
import 'package:firebasereg/repository/firebase_repository.dart';
import 'package:firebasereg/validator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with SingleTickerProviderStateMixin {
  Animation iconAnimation;
  AnimationController iconAnimationController;

  final _emailController = TextEditingController();
  final formKey = GlobalKey<FormState>();

  var scaffoldKey = GlobalKey<ScaffoldState>();

  String email, password;

  @override
  void initState() {
    super.initState();
    iconAnimationController =
        AnimationController(vsync: this, duration: Duration(milliseconds: 500));
    iconAnimation = CurvedAnimation(
        curve: Curves.fastOutSlowIn, parent: iconAnimationController);

    iconAnimation.addListener(() {
      setState(() {});
    });
    iconAnimationController.forward();
  }

  @override
  void dispose() {
    iconAnimationController.dispose();
    super.dispose();
  }

  Future<bool> setIsLogin() async {
    final SharedPreferences sharedPreferences =
        await SharedPreferences.getInstance();
    await sharedPreferences.setString('emailId', this.email);

    var obtainedEmail = sharedPreferences.getString('emailId');
    return true;
  }

  @override
  Widget build(BuildContext mainContext) {
    BlocProvider.of<FirebaseBloc>(mainContext).add(ResetLoginData());
    return Scaffold(
      key: scaffoldKey,
      body: BlocBuilder<FirebaseBloc, FirebaseState>(builder: (context, state) {
        //print(state);
        if (state is DataLoaded) {
          BlocProvider.of<FirebaseBloc>(mainContext).add(ResetLoginData());
        }

        if (state is LoginEmpty) {
          return Container(
            child: body(mainContext),
          );
        }

        if (state is LoginError) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            scaffoldKey.currentState.showSnackBar(SnackBar(
              content: Text(
                "Invalid User",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              backgroundColor: Colors.red,
            ));
          });

          return Container(
            child: body(mainContext),
          );
        }

        if (state is LoginLoaded) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            final FirebaseRepository repository = FirebaseRepository(
              firebaseApiClient: FirebaseApiClient(
                httpClient: http.Client(),
              ),
            );

            // print("NEW LOGGED EMAIL:${this.email}");

            Navigator.of(mainContext).pop();
            Navigator.of(mainContext).push(MaterialPageRoute(
                builder: (_) => BlocProvider.value(
                    value: BlocProvider.of<FirebaseBloc>(mainContext),
                    child: MyApp(
                      repository: repository,
                    ))));
          });
        }

        return Center(
          child: CircularProgressIndicator(),
        );
      }),
    );
  }

  Widget body(BuildContext mainContext) {
    return SingleChildScrollView(
      child: Container(
        height: MediaQuery.of(context).size.height,
        padding: EdgeInsets.all(16),
        child: Form(
          key: formKey,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              FlutterLogo(
                size: iconAnimation.value * 100,
              ),
              SizedBox(
                height: 20,
              ),
              TextFormField(
                keyboardType: TextInputType.emailAddress,
                controller: _emailController,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Enter email",
                  labelText: "Email",
                ),
                validator: (val) => Validator.isValidEmail(email),
                onChanged: (val) => email = val,
              ),
              SizedBox(
                height: 20.0,
              ),
              TextFormField(
                obscureText: true,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Enter password",
                  labelText: "Password",
                ),
                keyboardType: TextInputType.text,
                validator: (val) => Validator.isValidPassword(password),
                onChanged: (val) => password = val,
              ),
              SizedBox(
                height: 20.0,
              ),
              RaisedButton(
                onPressed: () async {
                  login(mainContext);
                  // print("finalEmail:$email");
                },
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(80.0)),
                padding: const EdgeInsets.all(0.0),
                child: buttonUI(),
              ),
              SizedBox(
                height: 10.0,
              ),
              RaisedButton(
                onPressed: () {
                  register(mainContext);
                },
                color: Colors.tealAccent,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(80.0)),
                padding: const EdgeInsets.all(0.0),
                child: buttonUI(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void login(BuildContext mainContext) async {
    final Form = formKey.currentState;
    if (Form.validate()) {
      Form.save();
      // print("Form:$email");
      SharedPreferences sharedPreferences =
          await SharedPreferences.getInstance();
      await sharedPreferences.setString('emailId', email);
      BlocProvider.of<FirebaseBloc>(mainContext)
          .add(FetchLogin(email, password));
    }
  }

  void register(BuildContext mainContext) {
    Navigator.of(mainContext).push(MaterialPageRoute(
        builder: (_) => BlocProvider.value(
            value: BlocProvider.of<FirebaseBloc>(context),
            child: RegisterPage())));
  }

  Widget buttonUI() {
    return Ink(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.indigo, Colors.lightBlueAccent],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.all(Radius.circular(80.0)),
      ),
      child: Container(
        constraints: const BoxConstraints(minWidth: 88.0, minHeight: 40.0),
// min sizes for Material buttons
        alignment: Alignment.center,
        child: const Text(
          'Register',
          textAlign: TextAlign.center,
          style: TextStyle(
              fontWeight: FontWeight.bold, fontSize: 15, color: Colors.white),
        ),
      ),
    );
  }
}
