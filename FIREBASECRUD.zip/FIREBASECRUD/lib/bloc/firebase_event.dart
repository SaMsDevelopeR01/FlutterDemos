import 'package:equatable/equatable.dart';

abstract class FirebaseEvent extends Equatable {
  const FirebaseEvent();
}

/*
***Register***
 */
class ResetRegisterData extends FirebaseEvent {
  const ResetRegisterData();

  @override
  List<Object> get props => [];
}

class FetchRegister extends FirebaseEvent {
  final email;
  final password;
  final confirmPassword;
  final phNo;

  const FetchRegister(
      this.email, this.password, this.confirmPassword, this.phNo);

  @override
  List<Object> get props => [];
}

/*
***Login***
 */
class ResetLoginData extends FirebaseEvent {
  const ResetLoginData();

  @override
  List<Object> get props => [];
}

class FetchLogin extends FirebaseEvent {
  final email;
  final password;

  const FetchLogin(this.email, this.password);

  @override
  List<Object> get props => [];
}

/*
***Add Data***
 */
class ResetAddDataList extends FirebaseEvent {
  const ResetAddDataList();

  @override
  List<Object> get props => [];
}

class fetchAddData extends FirebaseEvent {
  final email;
  final title;
  final detail;
  final picture;

  const fetchAddData(this.email, this.title, this.detail, this.picture);

  @override
  List<Object> get props => [];
}

/*
***Data***
 */
class ResetUsersList extends FirebaseEvent {
  const ResetUsersList();

  @override
  List<Object> get props => [];
}

class fetchData extends FirebaseEvent {
  final email;

  const fetchData(this.email);

  @override
  List<Object> get props => [];
}

/*
***UserDetail***
 */
class ResetUserDetail extends FirebaseEvent {
  const ResetUserDetail();

  @override
  List<Object> get props => [];
}

class FetchUserDetail extends FirebaseEvent {
  final id;

  const FetchUserDetail(this.id);

  @override
  List<Object> get props => [];
}

/*
***Updating User Data***
 */
class UpdateUserDetail extends FirebaseEvent {
  final id;
  final email;
  final title;
  final detail;
  final picture;

  const UpdateUserDetail(
    this.id,
    this.email,
    this.title,
    this.detail,
    this.picture,
  );

  @override
  List<Object> get props => [];
}

/*
***Deleting User Data***
 */
class DeleteUserDetail extends FirebaseEvent {
  final email;

  const DeleteUserDetail(this.email);

  @override
  List<Object> get props => [];
}
