import 'package:firebasereg/bloc/firebase_event.dart';
import 'package:firebasereg/bloc/firebase_state.dart';
import 'package:firebasereg/models/note.dart';
import 'package:firebasereg/models/user.dart';
import 'package:firebasereg/repository/firebase_repository.dart';
import 'package:meta/meta.dart';
import 'package:bloc/bloc.dart';

class FirebaseBloc extends Bloc<FirebaseEvent, FirebaseState> {
  final FirebaseRepository repository;

  FirebaseBloc({@required this.repository})
      : assert(repository != null),
        super(LoginEmpty());

  @override
  FirebaseState get initialState => LoginEmpty();

  @override
  Stream<FirebaseState> mapEventToState(FirebaseEvent event) async* {
    if (event is ResetRegisterData) {
      yield RegisterEmpty();
    }

    if (event is FetchRegister) {
      yield RegisterLoading();

      try {
        final User register = (await repository.fetchRegister(
            event.email, event.password, event.confirmPassword, event.phNo));
        yield RegisterLoaded(register: register);
      } catch (e) {
        print(e);
        yield RegisterError();
      }
    }

    if (event is ResetLoginData) {
      yield LoginEmpty();
    }

    if (event is FetchLogin) {
      yield LoginLoading();
      try {
        final User login =
            (await repository.fetchLogin(event.email, event.password));
        yield LoginLoaded(login: login);
      } catch (e) {
        print(e);
        yield LoginError();
      }
    }

    if (event is ResetAddDataList) {
      yield AddDataEmpty();
    }

    if (event is fetchAddData) {
      yield AddDataLoading();
      try {
        final Note addData = (await repository.fetchAddData(
            event.email, event.title, event.detail, event.picture));
        yield AddDataLoaded(addData: addData);
      } catch (e) {
        print(e);
        yield AddDataError();
      }
    }

    if (event is ResetUsersList) {
      yield DataEmpty();
    }

    if (event is fetchData) {
      yield DataLoading();
      try {
        final List<Note> Data = (await repository.fetchData(event.email));
        yield DataLoaded(Data: Data);
      } catch (e) {
        print(e);
        yield DataError();
      }
    }

    if (event is ResetUserDetail) {
      yield UserDetailEmpty();
    }

    if (event is FetchUserDetail) {
      yield UserDetailLoading();
      try {
        final Note userDetail = (await repository.fetchUserDetail(event.id));
        yield UserDetailLoaded(user: userDetail);
      } catch (e) {
        print(e);
        yield UserDetailError();
      }
    }

    if (event is UpdateUserDetail) {
      yield UserDetailLoading();
      try {
        final bool isUserUpdated = (await repository.updateUserDetail(
            event.id, event.email, event.title, event.detail, event.picture));
        yield isUserUpdated
            ? UserDetailUpdated(isUserUpdated: isUserUpdated)
            : UserUpdatedFail();
      } catch (e) {
        print(e);
        yield UserDetailError();
      }
    }

    if (event is DeleteUserDetail) {
      yield UserDetailLoading();
      try {
        final bool isUserDeleted =
            (await repository.deleteUserDetail(event.email));
        yield isUserDeleted
            ? UserDetailDelete(isUserDeleted: isUserDeleted)
            : UserUpdatedFail();
      } catch (e) {
        print(e);
        yield UserDetailError();
      }
    }
  }
}
