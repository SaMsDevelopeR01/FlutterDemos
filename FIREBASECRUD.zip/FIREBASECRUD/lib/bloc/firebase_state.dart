import 'package:firebasereg/models/note.dart';
import 'package:firebasereg/models/user.dart';
import 'package:meta/meta.dart';
import 'package:equatable/equatable.dart';

abstract class FirebaseState extends Equatable {
  const FirebaseState();

  @override
  List<Object> get props => [];
}

/*
***Register State***
 */
class RegisterEmpty extends FirebaseState {}

class RegisterLoading extends FirebaseState {}

class RegisterLoaded extends FirebaseState {
  final User register;

  const RegisterLoaded({@required this.register}) : assert(register != null);

  @override
  List<Object> get props => [];
}

class RegisterError extends FirebaseState {}

/*
***Login State***
 */
class LoginEmpty extends FirebaseState {}

class LoginLoading extends FirebaseState {}

class LoginLoaded extends FirebaseState {
  final User login;

  const LoginLoaded({@required this.login}) : assert(login != null);

  @override
  List<Object> get props => [];
}

class LoginError extends FirebaseState {}

/*
***AddData State***
 */
class AddDataEmpty extends FirebaseState {}

class AddDataLoading extends FirebaseState {}

class AddDataLoaded extends FirebaseState {
  final Note addData;

  const AddDataLoaded({@required this.addData}) : assert(addData != null);

  @override
  List<Object> get props => [];
}

class AddDataError extends FirebaseState {}

/*
***Data State***
 */
class DataEmpty extends FirebaseState {}

class DataLoading extends FirebaseState {}

class DataLoaded extends FirebaseState {
  final List<Note> Data;

  const DataLoaded({@required this.Data}) : assert(Data != null);

  @override
  List<Object> get props => [];
}

class DataError extends FirebaseState {}

/*
***Update***
 */
class UserDetailEmpty extends FirebaseState {}

class UserDetailLoading extends FirebaseState {}

class UserDetailLoaded extends FirebaseState {
  final Note user;

  const UserDetailLoaded({@required this.user}) : assert(user != null);

  @override
  List<Object> get props => [];
}

class UserDetailError extends FirebaseState {}

class UserDetailUpdated extends FirebaseState {
  final bool isUserUpdated;

  const UserDetailUpdated({@required this.isUserUpdated})
      : assert(isUserUpdated != null);

  @override
  List<Object> get props => [];
}

class UserUpdatedFail extends FirebaseState {}

class UserDetailDeleted extends FirebaseState {}

/*
***Delete***
 */
class UserDetailDelete extends FirebaseState {
  final bool isUserDeleted;

  const UserDetailDelete({@required this.isUserDeleted})
      : assert(isUserDeleted != null);

  @override
  List<Object> get props => [];
}
