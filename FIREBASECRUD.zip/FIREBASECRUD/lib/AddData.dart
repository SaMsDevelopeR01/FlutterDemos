import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebasereg/validator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'bloc/firebase_bloc.dart';
import 'bloc/firebase_event.dart';
import 'bloc/firebase_state.dart';

class AddData extends StatefulWidget {
  final email;

  const AddData({Key key, this.email}) : super(key: key);

  @override
  _AddDataState createState() => _AddDataState(email);
}

class _AddDataState extends State<AddData> {
  final formKey = GlobalKey<FormState>();
  final email;

  String title, detail;
  String downloadUrl;

  File _image;
  File selectedImage;

  _AddDataState(this.email);

  @override
  void initState() {
    super.initState();
  }

  _imgFromCamera() async {
    selectedImage = await ImagePicker.pickImage(
        source: ImageSource.camera, imageQuality: 50);
    if (selectedImage != null) {
      setState(() {
        _image = selectedImage;
      });
    }
  }

  Future uploadImage() async {
    final _firebaseStorage = FirebaseStorage.instance;
    var file = File(selectedImage.path);
    //Upload to Firebase
    var snapshot =
        await _firebaseStorage.ref().child('images/imageName').putFile(file);
    downloadUrl = await snapshot.ref.getDownloadURL();
  }

  _imgFromGallery() async {
    selectedImage = await ImagePicker.pickImage(
        source: ImageSource.gallery, imageQuality: 50);
    if (selectedImage != null) {
      setState(() {
        _image = selectedImage;
      });
    } else {
      print("image not selected");
    }
  }

  @override
  Widget build(BuildContext mainContext) {
    //FirebaseBloc firebaseBloc= BlocProvider.of(mainContext);
    //BlocProvider.of<FirebaseBloc>(mainContext).add(ResetAddDataList());
    return Scaffold(
        appBar: AppBar(
          title: Text("Add Data"),
        ),
        body: WillPopScope(child: BlocBuilder<FirebaseBloc, FirebaseState>(
            builder: (mainContext, state) {
          print(state);
          if (state is AddDataEmpty || state is DataLoaded) {
            return Container(
              child: body(mainContext),
            );
          }

          if (state is AddDataError) {
            return Center(
              child: Text('Failed to Fetch Data'),
            );
          }

          if (state is AddDataLoaded) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              // BlocProvider.of<FirebaseBloc>(mainContext).add(ResetUsersList());
              Navigator.of(mainContext).pop(true);
            });
          }

          return Center(
            child: CircularProgressIndicator(),
          );
        }), onWillPop: () {
          BlocProvider.of<FirebaseBloc>(mainContext).add(ResetUsersList());
          Navigator.of(mainContext).pop(true);
          return;
        }));
  }

  Widget body(BuildContext mainContext) {
    return SingleChildScrollView(
      child: Container(
        height: MediaQuery.of(context).size.height,
        padding: EdgeInsets.all(30),
        child: Form(
          key: formKey,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              selectImage(),
              SizedBox(
                height: 20,
              ),
              TextFormField(
                keyboardType: TextInputType.text,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Enter Title",
                  labelText: "Title",
                ),
                validator: (val) => Validator.isValidTitle(title),
                onChanged: (val) => title = val,
              ),
              SizedBox(
                height: 20.0,
              ),
              TextFormField(
                keyboardType: TextInputType.text,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Enter Description",
                  labelText: "Description",
                ),
                validator: (val) => Validator.isValidDetail(detail),
                onChanged: (val) => detail = val,
              ),
              SizedBox(
                height: 20.0,
              ),
              RaisedButton(
                color: Colors.tealAccent,
                onPressed: () {
                  addData(mainContext);
                },
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(80.0)),
                padding: const EdgeInsets.all(0.0),
                child: buttonUI(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget selectImage() {
    return GestureDetector(
      onTap: () {
        _showPicker(context);
      },
      child: CircleAvatar(
        radius: 55,
        backgroundColor: Color(0xffFDCF09),
        child: _image != null
            ? ClipRRect(
                borderRadius: BorderRadius.circular(50),
                child: Image.file(
                  _image,
                  width: 100,
                  height: 100,
                  fit: BoxFit.cover,
                ),
              )
            : Container(
                decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(50)),
                width: 100,
                height: 100,
                child: Icon(
                  Icons.camera_alt,
                  color: Colors.grey[800],
                ),
              ),
      ),
    );
  }

  Widget buttonUI() {
    return Ink(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.indigo, Colors.lightBlueAccent],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.all(Radius.circular(80.0)),
      ),
      child: Container(
        constraints: const BoxConstraints(minWidth: 88.0, minHeight: 40.0),
        // min sizes for Material buttons
        alignment: Alignment.center,
        child: const Text(
          'Add Data',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 15,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  void addData(BuildContext mainContext) {
    final Form = formKey.currentState;
    if (Form.validate()) {
      Form.save();

      if (_image != null) {
        uploadImage().whenComplete(() {
          print("downloadUrl: $downloadUrl");
          BlocProvider.of<FirebaseBloc>(mainContext)
              .add(fetchAddData(email, title, detail, downloadUrl));
        });
      } else {
        Scaffold.of(mainContext)
            .showSnackBar(SnackBar(content: Text("Select Image")));
      }
    }
  }

  void _showPicker(context) {
    showModalBottomSheet(
        context: context,
        builder: (BuildContext bc) {
          return SafeArea(
            child: Container(
              child: Wrap(
                children: <Widget>[
                  ListTile(
                      leading: Icon(Icons.photo_library),
                      title: Text('Photo Library'),
                      onTap: () {
                        _imgFromGallery();
                        Navigator.of(context).pop();
                      }),
                  ListTile(
                    leading: Icon(Icons.photo_camera),
                    title: Text('Camera'),
                    onTap: () {
                      _imgFromCamera();
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              ),
            ),
          );
        });
  }
}
