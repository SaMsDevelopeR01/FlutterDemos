class User {
  int id;
  String email;
  String password;
  String confirmPassword;
  String phoneNo;

  User({this.id, this.email, this.password, this.confirmPassword, this.phoneNo});

  factory User.fromJson(Map<String, dynamic> json) => new User(
        id: json["id"],
        email: json["email"],
        password: json["password"],
        confirmPassword: json["confirmPassword"],
        phoneNo: json["phoneNo"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "email": email,
        "password": password,
        "confirmPassword": confirmPassword,
        "phoneNo": phoneNo
      };
}
