import 'package:cryptocoin/bloc/crypto_bloc.dart';
import 'package:cryptocoin/bloc/crypto_event.dart';
import 'package:cryptocoin/bloc/crypto_state.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class TrendingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    BlocProvider.of<CryptoBloc>(context).add(ResetCryptoTrending());
    return Scaffold(
      appBar: AppBar(
        title: Text("Trendings"),
      ),
        body: BlocBuilder<CryptoBloc, CryptoState>(builder: (context, state) {
          print(state);
          if (state is TrendingEmpty) {
            BlocProvider.of<CryptoBloc>(context).add(FetchCryptoTrendig());
          }
          if (state is TrendingError) {
            return Center(
              child: Text('Failed to Fetch Data'),
            );
          }
          if (state is TrendingLoaded) {
            return  ListView.builder(
                itemCount: state.cryptoTrendigs.coins.length,
                itemBuilder: (BuildContext context, int index) {
                  return _getListItemUI(
                      state.cryptoTrendigs.coins[index].item.name,
                      state.cryptoTrendigs.coins[index].item.symbol,
                      state.cryptoTrendigs.coins[index].item.thumb,
                      state.cryptoTrendigs.coins[index].item.marketCapRank,
                      state.cryptoTrendigs.coins[index].item.score);
                });
          }
          return  Center(
            child: CircularProgressIndicator(),
          );
        })
    );
  }

  Widget _getListItemUI(String name, String symbol, String image,
      int marketcaprank, int score) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 7),
          child: ListTile(
              leading: CircleAvatar(
                child: Image.network(image),
              ),
              title: Text("${name}\t(${symbol})"),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 12.0),
                child: RichText(
                    text: TextSpan(children: [
                      TextSpan(
                          text: "MCR\t",
                          style:
                          TextStyle(color: Colors.grey[700], fontSize: 12.0)),
                      TextSpan(
                          text: "${marketcaprank}%",
                          style:
                          TextStyle(color: Colors.teal[300], fontSize: 12.0)),
                    ])),
              ),
              trailing: Padding(
                padding: const EdgeInsets.only(right: 10.0),
                child: RichText(
                    textAlign: TextAlign.center,
                    text: TextSpan(children: [
                      TextSpan(
                          text: "score\n",
                          style: TextStyle(color: Colors.black87)),
                      TextSpan(
                          text: "${score}\n",
                          style: TextStyle(
                            color: Colors.grey[700],
                          )),
                    ])),
              )),
        ),
        Divider(
          height: 5.0,
          color: Colors.grey[200],
        ),
      ],
    );
  }
}
