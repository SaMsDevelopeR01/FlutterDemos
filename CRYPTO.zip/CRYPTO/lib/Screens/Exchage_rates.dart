import 'package:cryptocoin/bloc/crypto_bloc.dart';
import 'package:cryptocoin/bloc/crypto_event.dart';
import 'package:cryptocoin/bloc/crypto_state.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class ExchageRatePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    BlocProvider.of<CryptoBloc>(context).add(ResetCryptoExchangeRate());
    final List<MaterialColor> _color = [Colors.red, Colors.indigo, Colors.blue];
    return Scaffold(
      appBar: AppBar(
        title: Text('Exchange Rates'),
      ),
      body: BlocBuilder<CryptoBloc, CryptoState>(builder: (context, state) {
        print(state);
        // if (state == null || state is CryptoEmpty) {
        //   BlocProvider.of<CryptoBloc>(context).add(FetchCryptoExchageRates());
        // }
        if (state is ExchangeRateEmpty) {
          BlocProvider.of<CryptoBloc>(context).add(FetchCryptoExchageRates());
        }
        if (state is ExchangeRateError) {
          return Center(
            child: Text('Failed to Fetch Data'),
          );
        }
        if (state is ExchangeRateLoaded) {
          return ListView.builder(
              itemCount: state.ExchangeRate.getArrayClasses().length,
              itemBuilder: (BuildContext context, int index) {
                final MaterialColor color = _color[index % _color.length];
                return _getListItemUI(
                  color,
                  state.ExchangeRate.getArrayClasses()[index].name,
                  state.ExchangeRate.getArrayClasses()[index].unit,
                  state.ExchangeRate.getArrayClasses()[index].value,
                  state.ExchangeRate.getArrayClasses()[index].type,
                );
              });
        }
        return Center(
          child: CircularProgressIndicator(),
        );
      }),
    );
  }

  Widget _getListItemUI(MaterialColor color, String name, String unit,
      double value, String type) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(3.0),
          child: ListTile(
              leading: CircleAvatar(
                backgroundColor: color,
                child: Text(name[0]),
              ),
              title: Text("${name}\t(${unit})"),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 11.0),
                child: RichText(
                    text: TextSpan(children: [
                  TextSpan(
                      text: "$type\t\t",
                      style:
                          TextStyle(color: Colors.grey[700], fontSize: 14.0)),
                  TextSpan(
                      text: "${value}%",
                      style:
                          TextStyle(color: Colors.teal[300], fontSize: 13.0)),
                ])),
              )),
        ),
        Divider(
          color: Colors.grey[200],
          height: 5.0,
        ),
      ],
    );
  }
}
