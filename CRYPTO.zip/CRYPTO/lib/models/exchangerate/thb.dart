import 'package:equatable/equatable.dart';

class Thb extends Equatable {
	final String name;
	final String unit;
	final double value;
	final String type;

	const Thb({
		this.name,
		this.unit,
		this.value,
		this.type,
	});

	@override
	String toString() {
		return 'Thb(name: $name, unit: $unit, value: $value, type: $type)';
	}

	factory Thb.fromJson(Map<String, dynamic> json) {
		return Thb(
			name: json['name'] as String,
			unit: json['unit'] as String,
			value: json['value'] as double,
			type: json['type'] as String,
		);
	}

	Map<String, dynamic> toJson() {
		return {
			'name': name,
			'unit': unit,
			'value': value,
			'type': type,
		};
	}

	Thb copyWith({
		String name,
		String unit,
		double value,
		String type,
	}) {
		return Thb(
			name: name ?? this.name,
			unit: unit ?? this.unit,
			value: value ?? this.value,
			type: type ?? this.type,
		);
	}

	@override
	List<Object> get props => [name, unit, value, type];
}
