import 'package:equatable/equatable.dart';

class Nok extends Equatable {
	final String name;
	final String unit;
	final double value;
	final String type;

	const Nok({
		this.name,
		this.unit,
		this.value,
		this.type,
	});

	@override
	String toString() {
		return 'Nok(name: $name, unit: $unit, value: $value, type: $type)';
	}

	factory Nok.fromJson(Map<String, dynamic> json) {
		return Nok(
			name: json['name'] as String,
			unit: json['unit'] as String,
			value: json['value'] as double,
			type: json['type'] as String,
		);
	}

	Map<String, dynamic> toJson() {
		return {
			'name': name,
			'unit': unit,
			'value': value,
			'type': type,
		};
	}

	Nok copyWith({
		String name,
		String unit,
		double value,
		String type,
	}) {
		return Nok(
			name: name ?? this.name,
			unit: unit ?? this.unit,
			value: value ?? this.value,
			type: type ?? this.type,
		);
	}

	@override
	List<Object> get props => [name, unit, value, type];
}
