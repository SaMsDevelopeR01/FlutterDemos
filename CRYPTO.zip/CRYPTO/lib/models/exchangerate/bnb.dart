import 'package:equatable/equatable.dart';

class Bnb extends Equatable {
	final String name;
	final String unit;
	final double value;
	final String type;

	const Bnb({
		this.name,
		this.unit,
		this.value,
		this.type,
	});

	@override
	String toString() {
		return 'Bnb(name: $name, unit: $unit, value: $value, type: $type)';
	}

	factory Bnb.fromJson(Map<String, dynamic> json) {
		return Bnb(
			name: json['name'] as String,
			unit: json['unit'] as String,
			value: json['value'] as double,
			type: json['type'] as String,
		);
	}

	Map<String, dynamic> toJson() {
		return {
			'name': name,
			'unit': unit,
			'value': value,
			'type': type,
		};
	}

	Bnb copyWith({
		String name,
		String unit,
		double value,
		String type,
	}) {
		return Bnb(
			name: name ?? this.name,
			unit: unit ?? this.unit,
			value: value ?? this.value,
			type: type ?? this.type,
		);
	}

	@override
	List<Object> get props => [name, unit, value, type];
}
