import 'package:equatable/equatable.dart';

class CryptoChart extends Equatable {
  final List<List<num>> prices;

  const CryptoChart({this.prices});

  @override
  String toString() => 'PriceList(prices: $prices)';

  factory CryptoChart.fromJson(Map<String, dynamic> json) {
    // print(json);
    var array = List<List<num>>();
    // print("JSON::");
    var prices = json['prices'] as List<dynamic>;
    print(prices);
    prices.forEach((e) {
      // if (e != null) {
      print("subObj::");
      print(e);
      // (e as List<num>)?.map((subObj) {
      array.add([e[0], e[1]]);
      // });
      // }
    });
    return CryptoChart(prices: array);
    // return PriceList(
    //   prices: json['prices'] as List<List<num>>,
    // );
  }

  Map<String, dynamic> toJson() {
    return {
      'prices': prices,
    };
  }

  CryptoChart copyWith({
    List<List<num>> prices,
  }) {
    return CryptoChart(
      prices: prices ?? this.prices,
    );
  }

  @override
  List<Object> get props => [prices];
}
