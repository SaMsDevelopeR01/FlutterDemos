import 'package:cryptocoin/models/crypto_chart_data.dart';
import 'package:cryptocoin/models/crypto_exchangelist_data.dart';
import 'package:cryptocoin/models/crypto_list_data.dart';
import 'package:cryptocoin/models/crypto_trendigs.dart';
import 'package:cryptocoin/models/exchangerate/exchange_rates.dart';
import 'package:meta/meta.dart';
import 'package:equatable/equatable.dart';

abstract class CryptoState extends Equatable {
  const CryptoState();

  @override
  List<Object> get props => [];
}

/*
***Price List State***
 */

class CryptoEmpty extends CryptoState {}

class CryptoLoading extends CryptoState {}

class CryptoLoaded extends CryptoState {
  final List<CryptoList> cryptoList;

  const CryptoLoaded({@required this.cryptoList}) : assert(cryptoList != null);

  @override
  List<Object> get props => [cryptoList];
}

class CryptoError extends CryptoState {}

/*
***Chart State***
 */

class ChartEmpty extends CryptoState {}

class ChartLoading extends CryptoState {}

class ChartLoaded extends CryptoState {
  final CryptoChart cryptoChart;

  const ChartLoaded({@required this.cryptoChart}) : assert(cryptoChart != null);

  @override
  List<Object> get props => [cryptoChart];
}

class ChartError extends CryptoState {}

/*
***Exchange Rate State***
 */

class ExchangeRateEmpty extends CryptoState {}

class ExchangeRateLoading extends CryptoState {}

class ExchangeRateLoaded extends CryptoState {
  final ExchangeRates ExchangeRate;

  const ExchangeRateLoaded({@required this.ExchangeRate})
      : assert(ExchangeRate != null);

  @override
  List<Object> get props => [ExchangeRate];
}

class ExchangeRateError extends CryptoState {}

/*
***Exchange Rate State***
 */

class ExchangeListEmpty extends CryptoState {}

class ExchangeListLoading extends CryptoState {}

class ExchangeListLoaded extends CryptoState {
  final List<CryptoExchangeList> cryptoExchangeList;

  const ExchangeListLoaded({@required this.cryptoExchangeList})
      : assert(cryptoExchangeList != null);

  @override
  List<Object> get props => [cryptoExchangeList];
}

class ExchangeListError extends CryptoState {}

/*
***Trendig***
 */

class TrendingEmpty extends CryptoState {}

class TrendingLoading extends CryptoState {}

class TrendingLoaded extends CryptoState {
  final CryptoTrendigs cryptoTrendigs;

  const TrendingLoaded({@required this.cryptoTrendigs})
      : assert(cryptoTrendigs != null);

  @override
  List<Object> get props => [cryptoTrendigs];
}

class TrendingError extends CryptoState {}
