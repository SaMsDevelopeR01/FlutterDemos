import 'package:cryptocoin/repository/crypto_api_client.dart';
import 'package:cryptocoin/repository/crypto_repository.dart';
import 'package:dynamic_theme/dynamic_theme.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'bloc/crypto_bloc.dart';
import 'homepage.dart';

class CryptoBlocObserer extends BlocObserver {
  @override
  void onEvent(Bloc bloc, Object event) {
    print(event);
    super.onEvent(bloc, event);
  }

  @override
  void onChange(Cubit cubit, Change change) {
    print(change);
    super.onChange(cubit, change);
  }

  @override
  void onTransition(Bloc bloc, Transition transition) {
    print(transition);
    super.onTransition(bloc, transition);
  }

  @override
  void onError(Cubit cubit, Object error, StackTrace stackTrace) {
    print(error);
    super.onError(cubit, error, stackTrace);
  }
}

void main() {
  Bloc.observer = CryptoBlocObserer();

  final CryptoRepository repository = CryptoRepository(
    cryptoApiClient: CryptoApiClient(
      httpClient: http.Client(),
    ),
  );

  runApp(MyApp(
    repository: repository,
  ));
}

class MyApp extends StatelessWidget {
  final CryptoRepository repository;

  MyApp({Key key, @required this.repository})
      : assert(repository != null),
        super(key: key);

  @override
  Widget build(BuildContext context) {
    return DynamicTheme(
        defaultBrightness: Brightness.light,
        data: (brightness) => new ThemeData(
              primarySwatch: Colors.lightBlue,
              brightness: brightness,
            ),
        themedWidgetBuilder: (context, theme) {
          return MaterialApp(
            theme: theme,
            debugShowCheckedModeBanner: false,
            title: 'Crypto Currency',
            home: Scaffold(
              appBar: AppBar(
                title: Text('Crypto Currency'),
                elevation: 0.0,
              ),
              body: BlocProvider(
                create: (context) => CryptoBloc(repository: repository),
                child: HomePage(),
              ),
            ),
          );
        });
  }
}
