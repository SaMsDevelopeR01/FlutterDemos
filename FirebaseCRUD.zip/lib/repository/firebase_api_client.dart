import 'dart:convert';
import 'package:firebasereg/bloc/firebase_event.dart';
import 'package:firebasereg/models/user.dart';
import 'package:http/http.dart' as http;
import 'package:meta/meta.dart';

import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseApiClient {
  final http.Client httpClient;
  CollectionReference users = FirebaseFirestore.instance.collection('users');

  FirebaseApiClient({
    @required this.httpClient,
  }) : assert(httpClient != null);

  Future<User> fetchRegister(String email, String password,
      String confirmPassword, String phno) async {
    print("IN REGISTRATION");
    var res = await users
        .doc(email)
        .set({"email": email, "password": password, "phone": phno});
    var data = await users.doc(email).get();
    print("user Registered::${data.data().toString()}");
    // final json = jsonDecode();
    return User(
        email: email,
        password: password,
        phno: phno,
        confirmPassword: password);
  }

  Future<User> fetchLogin(String email, String password) async {
    var res = await users
        .where("email", isEqualTo: email)
        .where("password", isEqualTo: password)
        .get();
    var data = res.docs[0];
    return User.fromJson(data.data());
  }

  Future<List<User>> fetchUsersList() async {
    List<User> arrayUsers = [];
    var res = await users.get();
    res.docs.forEach((element) {
      arrayUsers.add(User.fromJson(element.data()));
    });
    return arrayUsers;
  }

  Future<User> fetchUserDetail(String email) async {
    var res = await users.where("email", isEqualTo: email).get();
    var data = res.docs[0];
    print("User Detail::${data.data()}");
    return User.fromJson(data.data());
  }

  Future<bool> updateUserDetail(String email, String password,
      String confirmPassword, String phno) async {
    var res = await users
        .doc(email)
        .update({"email": email, "password": password, "phone": phno});
    var data = await users.doc(email).get();
    print("User Updated::${data.data()}");
    return data.data() != null;
  }

  Future<bool> deleteUserDetail(String email) async {
    var res = await users.doc(email).delete();

    var data = await users.doc(email).get();
    print("User Updated::${data.data()}");
    return data.data() != null;
  }
}
