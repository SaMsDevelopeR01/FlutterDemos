import 'package:dynamic_theme/dynamic_theme.dart';
import 'package:firebasereg/bloc/firebase_bloc.dart';
import 'package:firebasereg/bloc/firebase_event.dart';
import 'package:firebasereg/bloc/firebase_state.dart';
import 'package:firebasereg/registerpage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/homepage.dart';
import 'package:lottie/lottie.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with SingleTickerProviderStateMixin {
  Animation iconAnimation;
  AnimationController iconAnimationcontroller;
  String email, password;

  @override
  void initState() {
    super.initState();
    iconAnimationcontroller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 500));
    iconAnimation = CurvedAnimation(
        curve: Curves.fastOutSlowIn, parent: iconAnimationcontroller);

    iconAnimation.addListener(() {
      setState(() {});
    });
    iconAnimationcontroller.forward();
  }

  @override
  void dispose() {
    iconAnimationcontroller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext mainContext) {
    print("themes");
    print(DynamicTheme.of(context));
    print(DynamicTheme.of(mainContext));
    // BlocProvider.of<FirebaseBloc>(mainContext).add(ResetLoginData());
    return Scaffold(
      body: BlocBuilder<FirebaseBloc, FirebaseState>(builder: (c, state) {
        if (state is LoginEmpty) {
          return Container(
            child: body(context),
          );
        }

        if (state is LoginError) {
          return Center(
            child: Text('Failed to Fetch Data'),
          );
        }

        if (state is LoginLoaded) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            Navigator.of(mainContext).push(MaterialPageRoute(
                builder: (_) => BlocProvider.value(
                    value: BlocProvider.of<FirebaseBloc>(mainContext),
                    child: HomePage())));
          });
        }

        return Center(
          child: CircularProgressIndicator(),
        );
      }),
    );
  }

  Widget body(BuildContext mainContext) {
    return SingleChildScrollView(
      child: Container(
        height: MediaQuery.of(mainContext).size.height + 300,
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Image(
              image: AssetImage('assets/booster.png'),
            ),
            Lottie.network(
                'https://assets6.lottiefiles.com/private_files/lf30_mjuiybtp.json',
                height: 200),
            SizedBox(
              height: 20,
            ),
            TextFormField(
              onChanged: (val) => email = val,
              keyboardType: TextInputType.emailAddress,
              //validator: Validators.isValidEmail(email),
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                hintText: "Enter email",
                labelText: "Email",
              ),
            ),
            SizedBox(
              height: 20.0,
            ),
            TextFormField(
              onChanged: (val) => password = val,
              keyboardType: TextInputType.text,
              //validator: Validators.isValidPassword(password),
              obscureText: true,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                hintText: "Enter password",
                labelText: "Password",
              ),
            ),
            SizedBox(
              height: 20.0,
            ),
            ElevatedButton(
              onPressed: () {
                BlocProvider.of<FirebaseBloc>(mainContext)
                    .add(FetchLogin(email, password));
              },
              child: Container(
                constraints:
                    const BoxConstraints(minWidth: 88.0, minHeight: 40.0),
                // min sizes for Material buttons
                alignment: Alignment.center,
                child: const Text(
                  'Login',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 10.0,
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(mainContext).push(MaterialPageRoute(
                    builder: (_) => BlocProvider.value(
                        value: BlocProvider.of<FirebaseBloc>(mainContext),
                        child: RegisterPage())));
              },
              child: Container(
                constraints:
                    const BoxConstraints(minWidth: 88.0, minHeight: 40.0),
// min sizes for Material buttons
                alignment: Alignment.center,
                child: const Text(
                  'Register',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                      color: Colors.white),
                ),
              ),
            ),
            ElevatedButton(
                onPressed: () {
                  // DynamicTheme.of(context).setBrightness(Brightness.dark);

                  // Theme.of(context).brightness == Brightness.dark
                  // ? Brightness.light
                  // : Brightness.dark);
                },
                child: Text("Change Theme")),
            Slider(
              min: 0,
              max: 100,
              value: 10,
              label: "Hello",
              divisions: 5,
              onChanged: (double value) {},
            ),
            Expanded(
              child: Align(
                alignment: FractionalOffset.bottomCenter,
                child: Padding(
                    padding: EdgeInsets.only(bottom: 10.0),
                    child: Text(
                        "Pixel Ratio = ${MediaQuery.of(mainContext).devicePixelRatio}")),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
