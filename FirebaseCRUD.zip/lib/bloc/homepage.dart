import 'package:dynamic_theme/dynamic_theme.dart';
import 'package:firebasereg/Views/UserProfile/UserProfilePage.dart';
import 'package:firebasereg/bloc/firebase_bloc.dart';
import 'package:firebasereg/bloc/firebase_event.dart';
import 'package:firebasereg/bloc/firebase_state.dart';
import 'package:firebasereg/models/user.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:cool_alert/cool_alert.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext mainContext) {
    BlocProvider.of<FirebaseBloc>(mainContext).add(ResetUsersList());
    return Scaffold(
      appBar: AppBar(
        title: Text("Home"),
        actions: [
          IconButton(
              icon: Icon(Theme.of(mainContext).brightness == Brightness.dark
                  ? Icons.wb_sunny_sharp
                  : Icons.nights_stay_rounded),
              color: Theme.of(mainContext).brightness == Brightness.dark
                  ? Colors.black
                  : Colors.white,
              onPressed: () {
                print("Icon Tapped");
                DynamicTheme.of(mainContext).setBrightness(Brightness.dark);
                // Theme.of(mainContext).brightness == Brightness.dark
                //     ? Brightness.light
                //     : Brightness.dark);
              })
        ],
      ),
      body: BlocBuilder<FirebaseBloc, FirebaseState>(
        builder: (context, state) {
          if (state is UsersListEmpty) {
            BlocProvider.of<FirebaseBloc>(mainContext).add(FetchUsersList());
          }

          if (state is UsersListError) {
            return Center(
              child: Text('Failed to Users Data'),
            );
          }

          if (state is UsersListLoaded) {
            print("data loaded::${state.users.length}");
            return getUsersList(mainContext, state.users);
          }

          return Center(
            child: CircularProgressIndicator(),
          );
        },
      ),
    );
  }
}

Widget getUsersList(BuildContext context, List<User> arrayUsers) {
  return Container(
    child: ListView.builder(
        itemCount: arrayUsers.length,
        itemBuilder: (BuildContext _, int i) {
          var item = arrayUsers[i];

          return Dismissible(
              key: Key(item.email),
              onDismissed: (direction) {
                if (direction == DismissDirection.startToEnd) {}
              },
              background: Container(color: Colors.red),
              child: GestureDetector(
                  onTap: () async {
                    print("clicked");
                    var value =
                        await Navigator.of(context).push(MaterialPageRoute(
                            builder: (_) => BlocProvider.value(
                                  value: BlocProvider.of<FirebaseBloc>(context),
                                  child: UserProfilePage(email: item.email),
                                )));

                    print("RES UDPAED:$value");
                    if (value != null && value) {
                      //upadate success
                      CoolAlert.show(
                        context: context,
                        type: CoolAlertType.success,
                        text: "Profile updated successfully!",
                      );
                    }
                  },
                  child: ListTile(
                      title: Text(item.email), subtitle: Text(item.phno))));
        }),
  );
}
