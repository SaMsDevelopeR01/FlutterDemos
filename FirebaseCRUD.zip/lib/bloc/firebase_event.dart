import 'package:equatable/equatable.dart';

abstract class FirebaseEvent extends Equatable {
  const FirebaseEvent();
}

//Register
class ResetRegisterData extends FirebaseEvent {
  const ResetRegisterData();

  @override
  List<Object> get props => [];
}

class FetchRegister extends FirebaseEvent {
  final email;
  final password;
  final confirmPassword;
  final phNo;

  const FetchRegister(
      this.email, this.password, this.confirmPassword, this.phNo);

  @override
  List<Object> get props => [];
}

//Login
class ResetLoginData extends FirebaseEvent {
  const ResetLoginData();

  @override
  List<Object> get props => [];
}

class FetchLogin extends FirebaseEvent {
  final email;
  final password;

  const FetchLogin(this.email, this.password);

  @override
  List<Object> get props => [];
}

//UsersListing
class ResetUsersList extends FirebaseEvent {
  const ResetUsersList();

  @override
  List<Object> get props => [];
}

class FetchUsersList extends FirebaseEvent {
  const FetchUsersList();
  @override
  List<Object> get props => [];
}

//UserDetail
class ResetUserDetail extends FirebaseEvent {
  const ResetUserDetail();

  @override
  List<Object> get props => [];
}

class FetchUserDetail extends FirebaseEvent {
  final email;

  const FetchUserDetail(this.email);

  @override
  List<Object> get props => [];
}

//Updating User Data
class UpdateUserDetail extends FirebaseEvent {
  final email;
  final password;
  final confirmPassword;
  final phNo;

  const UpdateUserDetail(
      this.email, this.password, this.confirmPassword, this.phNo);

  @override
  List<Object> get props => [];
}
