import 'package:dynamic_theme/dynamic_theme.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebasereg/bloc/firebase_bloc.dart';

import 'package:firebasereg/repository/firebase_api_client.dart';
import 'package:firebasereg/repository/firebase_repository.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:splashscreen/splashscreen.dart';
import 'login/loginpage.dart';

class UserBlocObserer extends BlocObserver {
  @override
  void onEvent(Bloc bloc, Object event) {
    print(event);
    super.onEvent(bloc, event);
  }

  @override
  void onChange(Cubit cubit, Change change) {
    print(change);
    super.onChange(cubit, change);
  }

  @override
  void onTransition(Bloc bloc, Transition transition) {
    print(transition);
    super.onTransition(bloc, transition);
  }

  @override
  void onError(Cubit cubit, Object error, StackTrace stackTrace) {
    print(error);
    super.onError(cubit, error, stackTrace);
  }
}

void main() async {
  Bloc.observer = UserBlocObserer();
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  final FirebaseRepository repository = FirebaseRepository(
    firebaseApiClient: FirebaseApiClient(
      httpClient: http.Client(),
    ),
  );

  runApp(App(
    repository: repository,
  ));
}

class App extends StatelessWidget {
  final FirebaseRepository repository;

  App({Key key, @required this.repository})
      : assert(repository != null),
        super(key: key);
  @override
  Widget build(BuildContext mContext) {
    print("MAIN THEMES");
    print(DynamicTheme.of(mContext));
    return new DynamicTheme(
        defaultBrightness: Brightness.light,
        data: (brightness) => new ThemeData(
              primarySwatch: Colors.blue,
              brightness: brightness,
            ),
        themedWidgetBuilder: (context, theme) {
          return new DynamicTheme(
              defaultBrightness: Brightness.light,
              data: (brightness) => new ThemeData(
                    primarySwatch: Colors.blue,
                    brightness: brightness,
                  ),
              themedWidgetBuilder: (cContext, theme) {
                print(DynamicTheme.of(cContext));

                return new MaterialApp(
                    title: 'Flutter Fire',
                    theme: theme,
                    debugShowCheckedModeBanner: false,
                    home: _MyAppState(repository: repository));
              });
        });
  }
}

class _MyAppState extends StatelessWidget {
  final FirebaseRepository repository;

  _MyAppState({Key key, @required this.repository})
      : assert(repository != null),
        super(key: key);
  @override
  Widget build(BuildContext mainContext) {
    return new SplashScreen(
        seconds: 4,
        navigateAfterSeconds: new AfterSplash(repository: repository),
        title: new Text("SaM's DeV",
            style: Theme.of(mainContext).textTheme.bodyText1),
        imageBackground: new NetworkImage('https://i.imgur.com/TyCSG9A.png'),
        backgroundColor: Theme.of(mainContext).backgroundColor,
        styleTextUnderTheLoader: new TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20.0,
            color: Theme.of(mainContext).secondaryHeaderColor),
        loadingText: new Text("SaM's DeV"),
        onClick: () => print("Flutter Egypt"),
        loaderColor: Theme.of(mainContext).accentColor);
  }
}

class AfterSplash extends StatelessWidget {
  final FirebaseRepository repository;

  AfterSplash({Key key, @required this.repository})
      : assert(repository != null),
        super(key: key);
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: BlocProvider(
        create: (_) => FirebaseBloc(repository: repository),
        child: LoginPage(),
      ),
    );
  }
}
