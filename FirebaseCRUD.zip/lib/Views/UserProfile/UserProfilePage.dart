import 'package:firebasereg/bloc/firebase_bloc.dart';
import 'package:firebasereg/bloc/firebase_event.dart';
import 'package:firebasereg/bloc/firebase_state.dart';
import 'package:firebasereg/models/user.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class UserProfilePage extends StatefulWidget {
  final email;

  const UserProfilePage({Key key, this.email}) : super(key: key);

  @override
  _UserProfileState createState() => _UserProfileState(email);
}

class _UserProfileState extends State<UserProfilePage>
    with SingleTickerProviderStateMixin {
  final selectedEmail;
  Animation iconAnimation;
  AnimationController iconAnimationcontroller;
  String email, password, confirmPassword, phNo;

  _UserProfileState(this.selectedEmail);

//continuee....
  @override
  void initState() {
    super.initState();
    iconAnimationcontroller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 500));
    iconAnimation = CurvedAnimation(
        curve: Curves.fastOutSlowIn, parent: iconAnimationcontroller);

    iconAnimation.addListener(() {
      setState(() {});
    });
    iconAnimationcontroller.forward();
  }

  @override
  void dispose() {
    iconAnimationcontroller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext mainContext) {
    BlocProvider.of<FirebaseBloc>(mainContext).add(ResetUserDetail());
    return Scaffold(
      appBar: AppBar(
        title: Text('User Detail'),
      ),
      body: BlocBuilder<FirebaseBloc, FirebaseState>(builder: (context, state) {
        if (state is UserDetailEmpty || state is LoginEmpty) {
          BlocProvider.of<FirebaseBloc>(mainContext)
              .add(FetchUserDetail(selectedEmail));
        }
        if (state is UserDetailError) {
          return Center(
            child: Text('Failed to Fetch Data'),
          );
        }
        if (state is UserDetailLoaded) {
          var currentUserDetail = state.user;
          // setState(() {
          email = currentUserDetail.email;
          phNo = currentUserDetail.phno;
          password = currentUserDetail.password;
          confirmPassword = currentUserDetail.password;
          // });
          return Container(
            child: body(context, currentUserDetail),
          );
        }
        if (state is UserDetailUpdated) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            BlocProvider.of<FirebaseBloc>(mainContext).add(ResetUsersList());
            Navigator.pop(mainContext, true);
          });
        }
        return Center(
          child: CircularProgressIndicator(),
        );
      }),
    );
  }

  Widget body(BuildContext mainContext, User user) {
    return SingleChildScrollView(
      child: Container(
        height: MediaQuery.of(context).size.height,
        padding: EdgeInsets.all(16),
        child: Form(
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Padding(padding: const EdgeInsets.only(top: 15.0)),
              FlutterLogo(
                size: iconAnimation.value * 100,
              ),
              SizedBox(
                height: 25,
              ),
              TextFormField(
                onChanged: (val) => setState(() {
                  this.email = val;
                }),
                initialValue: user.email,
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Enter email",
                  labelText: "Email",
                ),
              ),
              SizedBox(
                height: 20.0,
              ),
              TextFormField(
                onChanged: (val) => password = val,
                initialValue: user.password,
                keyboardType: TextInputType.text,
                obscureText: true,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Enter password",
                  labelText: "Password",
                ),
              ),
              SizedBox(
                height: 20.0,
              ),
              TextFormField(
                onChanged: (val) => confirmPassword = val,
                initialValue: user.password,
                keyboardType: TextInputType.text,
                obscureText: true,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Enter Confirm password",
                  labelText: "Confirm Password",
                ),
              ),
              SizedBox(
                height: 20.0,
              ),
              TextFormField(
                onChanged: (val) => phNo = val,
                keyboardType: TextInputType.phone,
                initialValue: user.phno,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Enter Phone No.",
                  labelText: "Phone No",
                ),
              ),
              SizedBox(
                height: 20.0,
              ),
              ElevatedButton(
                onPressed: () {
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    print([
                      this.email,
                      this.password,
                      this.confirmPassword,
                      this.phNo
                    ]);
                    BlocProvider.of<FirebaseBloc>(mainContext).add(
                        UpdateUserDetail(this.email, this.password,
                            this.confirmPassword, this.phNo));
                  });
                },
                child: InkWell(
                  child: Container(
                    constraints:
                        const BoxConstraints(minWidth: 88.0, minHeight: 38.0),
                    // min sizes for Material buttons
                    alignment: Alignment.center,
                    child: const Text(
                      'Update Data',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: Colors.black,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
