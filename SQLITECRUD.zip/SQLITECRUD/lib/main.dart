import 'dart:async';
import 'package:crudwithsqflite/data/bloc/blocprovider.dart';
import 'package:crudwithsqflite/data/bloc/userbloc.dart';
import 'package:crudwithsqflite/home/homepage.dart';
import 'package:crudwithsqflite/home/notebloc.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'Login/loginpage.dart';
import 'home/noteblocprovider.dart';

void main() => runApp(MyPage());

class MyPage extends StatefulWidget {
  @override
  _MyPageState createState() => _MyPageState();
}

class _MyPageState extends State<MyPage> {
  String finalEmail;

  @override
  void initState() {
    super.initState();
    getvalidationdata().whenComplete(() async {
      // Get.to(finalEmail == null
      //     ? BlocProvider(child: LoginPage(), bloc: UserBloc())
      //     : NoteBlocProvider(child: HomePage(), bloc: NotesBloc()));
    });
  }

  Future getvalidationdata() async {
    final SharedPreferences sharedPreferences =
        await SharedPreferences.getInstance();
    var obtainedEmail = sharedPreferences.getString('email');
    setState(() {
      finalEmail = obtainedEmail;
    });
  }

  @override
  Widget build(BuildContext context) {
    print("*** Building The App ***");

    return GetMaterialApp(
        debugShowCheckedModeBanner: false,
        //navigatorKey: ,
        home: finalEmail == null
            ? BlocProvider(child: LoginPage(), bloc: UserBloc())
            : NoteBlocProvider(child: HomePage(email: finalEmail,), bloc: NotesBloc()));
  }
}
