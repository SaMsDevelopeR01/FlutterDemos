import 'dart:async';
import 'package:crudwithsqflite/models/users.dart';
import 'package:crudwithsqflite/utils/network_util.dart';

class RestData {
  NetworkUtil _netUtil = NetworkUtil();
  static final BASEURL = "";
  static final LOGINURL = BASEURL + "/";

  Future<User> login(String email, String password) async {
    return Future.value(User(email: email, password: password));
  }
}
