import 'dart:io';
import 'dart:async';
import 'package:crudwithsqflite/models/note.dart';
import 'package:crudwithsqflite/models/users.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DBProvider {
  // Create a singleton
  DBProvider._();

  //static DBProvider _dbProvider;
  static Database _database;

  final String tableUser = "User";
  final String ColumnEmail = "email";
  final String ColumnPasswordName = "password";
  final String ColumnConfirmPasswordName = "confirmpassword";
  final String ColumnPhnoName = "phno";

  final String tableNote = "Note";
  final String ColumnID = "id";
  final String ColumnTitle = "title";
  final String ColumnDesc = "detail";
  final String ColumnPicture = "picture";
  final String ColumnNoteEmail= "email";

  static final DBProvider db = DBProvider._();

  Future<Database> get database async {
    if (_database != null) {
      return _database;
    }

    _database = await initDB();
    return _database;
  }

  initDB() async {
    // Get the location of our apps directory. This is where files for our app, and only our app, are stored.
    // Files in this directory are deleted when the app is deleted.
    Directory documentsDir = await getApplicationDocumentsDirectory();
    String path = join(documentsDir.path, 'app.db');

    return await openDatabase(path, version: 1, onOpen: (db) async {},
        onCreate: (Database db, int version) async {
      print('path : $path');
      // Create the User table
      db.execute('''CREATE TABLE User(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,email TEXT,password TEXT,confirmpassword TEXT,phno TEXT)''').then(
          (value) => db
              .execute('''CREATE TABLE Note(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,email TEXT,title TEXT,detail TEXT,picture TEXT)''').then(
                  (value) => print("TABLES CREATED")));
    });
  }

  /*
	 * User Table
	 */
  newUser(User user) async {
    final db = await database;
    var res = await db.insert('user', user.toJson());
    return res;
  }

  getUsers() async {
    final db = await database;
    var res = await db.query('user');
    List<User> users =
        res.isNotEmpty ? res.map((user) => User.fromJson(user)).toList() : [];
    print(users.toList());
    return users;
  }

  getUser(int id) async {
    final db = await database;
    var res = await db.query('user', where: 'email = ?', whereArgs: [id]);
    return res.isNotEmpty ? User.fromJson(res.first) : null;
  }

  Future<User> loginUser(String email, String password) async {
    final db = await database;
    var res = await db.query('user', where: "email = ? and password=?", whereArgs: [email, password]);
    //if (res.length > 0) {
      print(res);
      print(res.length);
      return Future.value(User.fromJson(res.first));
    //}
 //return null;
  }

  updateUser(User user) async {
    final db = await database;
    var res = await db
        .update('user', user.toJson(), where: 'id = ?', whereArgs: [user.id]);
    print("User Updated");
    return res;
  }

  deleteUser(int id) async {
    final db = await database;
    db.delete('user', where: 'id = ?', whereArgs: [id]);
    print("User Deleted");
  }

  /*
	 * Note Table
	 */
  newNote(Note note) async {
    final db = await database;
    var res = await db.insert('note', note.toJson());
    return res;
  }

  getNotes(String email) async {
    final db = await database;
    var res = await db.query('note', where: 'email =?', whereArgs: [email]);
    List<Note> notes =
        res.isNotEmpty ? res.map((note) => Note.fromJson(note)).toList() : [];

    return notes;
  }

  getNote(int id) async {
    final db = await database;
    var res = await db.query('note', where: 'id = ?', whereArgs: [id]);
    return res.isNotEmpty ? Note.fromJson(res.first) : null;
  }

  updateNote(Note note) async {
    final db = await database;
    var res = await db
        .update('note', note.toJson(), where: 'id = ?', whereArgs: [note.id]);
    return res;
  }

  deleteNote(int id) async {
    final db = await database;
    db.delete('note', where: 'id = ?', whereArgs: [id]);
  }
}
