import 'dart:async';

import 'package:crudwithsqflite/models/users.dart';
import '../database.dart';
import 'blocprovider.dart';

class ViewUserBloc implements BlocBase {
  final _saveUserController = StreamController<User>.broadcast();

  StreamSink<User> get inSaveUser => _saveUserController.sink;

  final _deleteUserController = StreamController<int>.broadcast();

  StreamSink<int> get inDeleteUser => _deleteUserController.sink;

  // This bool StreamController will be used to ensure we don't do anything
  // else until a note is actually deleted from the database.
  final _userDeletedController = StreamController<bool>.broadcast();

  StreamSink<bool> get _inDeleted => _userDeletedController.sink;

  Stream<bool> get deleted => _userDeletedController.stream;

  ViewUserBloc() {
    // Listen for changes to the stream, and execute a function when a change is made
    _saveUserController.stream.listen(_handleUserNote);
    _deleteUserController.stream.listen(_handleDeleteUser);
  }

  @override
  void dispose() {
    _saveUserController.close();
    _deleteUserController.close();
    _userDeletedController.close();
  }

  void _handleUserNote(User user) async {
    await DBProvider.db.updateUser(user);
  }

  void _handleDeleteUser(int id) async {
    await DBProvider.db.deleteUser(id);

    // Set this to true in order to ensure a note is deleted
    // before doing anything else
    _inDeleted.add(true);
  }
}
