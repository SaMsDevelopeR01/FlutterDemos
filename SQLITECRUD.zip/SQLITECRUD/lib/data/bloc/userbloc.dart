import 'dart:async';
import 'package:crudwithsqflite/Login/loginpage.dart';
import 'package:crudwithsqflite/data/database.dart';
import 'package:crudwithsqflite/models/users.dart';
import 'package:flutter/material.dart';
import 'blocprovider.dart';

class UserBloc implements BlocBase {
  // Create a broadcast controller that allows this stream to be listened
  // to multiple times. This is the primary, if not only, type of stream you'll be using.
  final _userController = StreamController<List<User>>.broadcast();
  final _loginController = StreamController<List<User>>.broadcast();

  // Input stream. We add our users to the stream using this variable.
  StreamSink<List<User>> get _inUsers => _userController.sink;

  StreamSink<List<User>> get _inloginUsers => _loginController.sink;

  // Output stream. This one will be used within our pages to display the users.
  Stream<List<User>> get users => _userController.stream;

  Stream<List<User>> get login => _loginController.stream;

  // Input stream for adding new users. We'll call this from our pages.
  final _addUserController = StreamController<User>.broadcast();

  StreamSink<User> get inAddUser => _addUserController.sink;

  UserBloc() {
    // Retrieve all the users on initialization
    getUsers();
    // Listens for changes to the addNoteController and calls _handleAddNote on change
    _addUserController.stream.listen(_handleAddNote);
  }

  // All stream controllers you create should be closed within this function
  @override
  void dispose() {
    // _userController.close();
    // _addUserController.close();
  }

  void getUsers() async {
    // Retrieve all the user from the database
    List<User> users = await DBProvider.db.getUsers();
    // Add all of the users to the stream so we can grab them later from our pages
    _inUsers.add(users);
  }

  Future<User> loginUser(email, password) {
   return Future.value(DBProvider.db.loginUser(email, password));
  }

  void _handleAddNote(User user) async {
    // Create the note in the database
    await DBProvider.db.newUser(user);

    // Retrieve all the notes again after one is added.
    // This allows our pages to update properly and display the
    // newly added note.
    getUsers();
  }
}
