import 'package:crudwithsqflite/Login/loginpage.dart';
import 'package:crudwithsqflite/data/bloc/blocprovider.dart';
import 'package:crudwithsqflite/data/bloc/userbloc.dart';
import 'package:crudwithsqflite/home/homepage.dart';
import 'package:crudwithsqflite/home/notebloc.dart';
import 'package:crudwithsqflite/home/noteblocprovider.dart';
import 'package:crudwithsqflite/models/users.dart';
import 'package:crudwithsqflite/register/registerbloc.dart';
import 'package:flutter/material.dart';

class RegisterPage extends StatefulWidget {
  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage>
    with SingleTickerProviderStateMixin {
  Animation iconAnimation;
  AnimationController iconAnimationcontroller;
  final bloc = Bloc();
  UserBloc userBloc;
  String email, password, confirmPassword, phno;
  var formkey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    iconAnimationcontroller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 500));
    iconAnimation = CurvedAnimation(
        curve: Curves.fastOutSlowIn, parent: iconAnimationcontroller);

    iconAnimation.addListener(() {
      setState(() {});
    });
    iconAnimationcontroller.forward();

    userBloc = BlocProvider.of<UserBloc>(context);
  }

  void _addUser(BuildContext context) async {
    print("hii");
    final form = formkey.currentState;
    setState(() {
        form.save();
        User user = User(
            email: email,
            password: password,
            confirmPassword: confirmPassword,
            phno: phno);
        userBloc.inAddUser.add(user);
    });
    Navigator.of(context).push(MaterialPageRoute(
        builder: (context) =>
            NoteBlocProvider(child: HomePage(email: email), bloc: NotesBloc())));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Regester'),
      ),
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          padding: EdgeInsets.all(16),
          child: Form(
            key: formkey,
            child: Column(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Padding(padding: const EdgeInsets.only(top: 15.0)),
                FlutterLogo(
                  size: iconAnimation.value * 100,
                ),
                SizedBox(
                  height: 25,
                ),
                StreamBuilder<String>(
                  stream: bloc.email,
                  builder: (context, snapshot) => TextFormField(
                    onChanged: bloc.emailChanged,
                    onSaved: (val) => email = val,
                    keyboardType: TextInputType.emailAddress,
                    decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: "Enter email",
                        labelText: "Email",
                        errorText: snapshot.error),
                  ),
                ),
                SizedBox(
                  height: 20.0,
                ),
                StreamBuilder<String>(
                  stream: bloc.password,
                  builder: (context, snapshot) => TextFormField(
                    onChanged: bloc.passwordChanged,
                    onSaved: (val) => password = val,
                    keyboardType: TextInputType.text,
                    obscureText: true,
                    decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: "Enter password",
                        labelText: "Password",
                        errorText: snapshot.error),
                  ),
                ),
                SizedBox(
                  height: 20.0,
                ),
                StreamBuilder<String>(
                  stream: bloc.confirmpassword,
                  builder: (context, snapshot) => TextFormField(
                    onChanged: bloc.confirmpasswordChanged,
                    onSaved: (val) => confirmPassword = val,
                    keyboardType: TextInputType.text,
                    obscureText: true,
                    decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: "Enter Confirm password",
                        labelText: "Confirm Password",
                        errorText: snapshot.error),
                  ),
                ),
                SizedBox(
                  height: 20.0,
                ),
                StreamBuilder<String>(
                  builder: (context, snapshot) => TextFormField(
                    onChanged: bloc.phnoChanged,
                    onSaved: (val) => phno = val,
                    keyboardType: TextInputType.phone,
                    obscureText: true,
                    decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: "Enter Phone No.",
                        labelText: "Phone No",
                        errorText: snapshot.error),
                  ),
                ),
                SizedBox(
                  height: 20.0,
                ),
                StreamBuilder<bool>(
                  stream: bloc.submitCheck,
                  builder: (context, snapshot) => RaisedButton(
                    onPressed:
                        snapshot.hasData ? () => _addUser(context) : null,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(80.0)),
                    padding: const EdgeInsets.all(0.0),
                    child: Ink(
                      decoration:snapshot.hasData ? const BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.indigo, Colors.lightBlueAccent],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(80.0)),
                      ): null,
                      child: Container(
                        constraints: const BoxConstraints(
                            minWidth: 88.0, minHeight: 38.0),
                        // min sizes for Material buttons
                        alignment: Alignment.center,
                        child: const Text(
                          'Register',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
