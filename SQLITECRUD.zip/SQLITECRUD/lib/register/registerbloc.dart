import 'dart:async';
import 'package:crudwithsqflite/register/regvalidator.dart';
import 'package:rxdart/rxdart.dart';

class Bloc extends Object with Validators implements BaseBloc {
  final _emailController = BehaviorSubject<String>();
  final _passwordController = BehaviorSubject<String>();
  final _confirmpasswordController = BehaviorSubject<String>();
  final _phnoController = BehaviorSubject<String>();

  Function(String) get emailChanged => _emailController.sink.add;

  Function(String) get passwordChanged => _passwordController.sink.add;

  Function(String) get confirmpasswordChanged =>
      _confirmpasswordController.sink.add;

  Function(String) get phnoChanged => _phnoController.sink.add;

  Stream<String> get email => _emailController.stream.transform(emailValidator);

  Stream<String> get password =>
      _passwordController.stream.transform(passwordValidator);

  // Stream<String> get phno => _phnoController.stream.transform(phnoValidator);

  Stream<bool> get submitCheck => Rx.combineLatest3(
      email, password, confirmpassword, (e, p, c) => (0 == p.compareTo(c)));

  Stream<String> get confirmpassword => _confirmpasswordController.stream
          .transform(passwordValidator)
          .doOnData((String c) {
        if (0 != _passwordController.value.compareTo(c)) {
          _confirmpasswordController.addError("No Match");
        }
      });

  @override
  void dispose() {
    _emailController?.close();
    _passwordController?.close();
    _confirmpasswordController?.close();
    _phnoController?.close();
  }
}

abstract class BaseBloc {
  void dispose();
}
