import 'dart:async';

mixin Validators {
  var emailValidator =
      StreamTransformer<String, String>.fromHandlers(handleData: (email, sink) {
    bool emailValid = RegExp(r'^.+@[a-zA-Z]+\.{1}[a-zA-Z]+(\.{0,1}[a-zA-Z]+)$')
        .hasMatch(email);
    if (emailValid) {
      sink.add(email);
    } else {
      sink.addError("Email is not valid");
    }
  });

  var passwordValidator = StreamTransformer<String, String>.fromHandlers(
      handleData: (password, sink) {
    bool passwordValid = RegExp(
            r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,14}$')
        .hasMatch(password);
    if (passwordValid) {
      sink.add(password);
    } else {
      sink.addError("Password is not Valid");
    }
  });

// var phnoValidator = StreamTransformer<String,String>.fromHandlers(
//     handleData: (phno, sink) {
//       if(phno.length==10){
//         sink.add(phno);
//       }
//       else{
//         sink.addError("Mobile Number must be of 10 digit");
//       }
//     }
// );

}
