import 'package:crudwithsqflite/data/database.dart';
import 'package:crudwithsqflite/models/users.dart';

abstract class LoginPageContract {
  void onLoginSuccess(User user);
  void onLoginError(String error);
}

class LoginPagePresenter {
  LoginPageContract _view;
  DBProvider db = DBProvider.db;
  LoginPagePresenter(this._view);

  doLogin(String email, String password) {
    db
        .loginUser(email, password)
        .then((user) => _view.onLoginSuccess(user))
        .catchError((onError) => _view.onLoginError(onError.toString()));
  }
}
