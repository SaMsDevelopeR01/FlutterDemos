import 'package:crudwithsqflite/data/bloc/blocprovider.dart';
import 'package:crudwithsqflite/data/bloc/userbloc.dart';
import 'package:crudwithsqflite/data/database.dart';
import 'package:crudwithsqflite/home/homepage.dart';
import 'package:crudwithsqflite/home/notebloc.dart';
import 'package:crudwithsqflite/home/noteblocprovider.dart';
import 'package:crudwithsqflite/models/users.dart';
import 'package:crudwithsqflite/register/registerpage.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'login_presenter.dart';
import 'loginbloc.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with SingleTickerProviderStateMixin implements LoginPageContract{
  Animation iconAnimation;
  AnimationController iconAnimationcontroller;
  final bloc = Bloc();
  UserBloc userBloc;
  String email, password;
  var formkey = GlobalKey<FormState>();
  var scaffoldkey = GlobalKey<ScaffoldState>();
  final _emailcontroller = TextEditingController();
  final _passwordcontroller = TextEditingController();

  LoginPagePresenter _presenter;

  _LoginPageState() {
    _presenter = new LoginPagePresenter(this);
  }
  changeThePage(BuildContext context) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    await sharedPreferences.setString('email', _emailcontroller.text);
    final form = formkey.currentState;
    setState(() {
      form.save();
      _presenter.doLogin(email, password);
      //userBloc.loginUser(email, password);
      //   Navigator.of(context).push(MaterialPageRoute(
      //       builder: (context) =>
      //           NoteBlocProvider(child: HomePage(), bloc: NotesBloc())));
    });
  }

  @override
  void initState() {
    super.initState();
    iconAnimationcontroller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 500));
    iconAnimation = CurvedAnimation(
        curve: Curves.fastOutSlowIn, parent: iconAnimationcontroller);

    iconAnimation.addListener(() {
      setState(() {});
    });
    iconAnimationcontroller.forward();
    userBloc = BlocProvider.of<UserBloc>(context);
  }

  @override
  void dispose() {
    iconAnimationcontroller.dispose();
    super.dispose();
  }

  _showSnackBar() {
    scaffoldkey.currentState.showSnackBar(SnackBar(content: Text("Incorrect UserId & Password",style: TextStyle(fontWeight: FontWeight.bold),),backgroundColor: Colors.red,));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldkey,
      // backgroundColor: Colors.greenAccent,
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          padding: EdgeInsets.all(16),
          child: Form(
            key: formkey,
            child: Column(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                FlutterLogo(
                  size: iconAnimation.value * 100,
                ),
                SizedBox(
                  height: 20,
                ),
                StreamBuilder<String>(
                  stream: bloc.email,
                  builder: (context, snapshot) => TextFormField(
                    onSaved: (val) => email = val,
                    onChanged: bloc.emailChanged,
                    controller: _emailcontroller,
                    keyboardType: TextInputType.emailAddress,
                    decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: "Enter email",
                        labelText: "Email",
                        errorText: snapshot.error),
                  ),
                ),
                SizedBox(
                  height: 20.0,
                ),
                StreamBuilder<String>(
                  stream: bloc.password,
                  builder: (context, snapshot) => TextFormField(
                    onSaved: (val) => password = val,
                    onChanged: bloc.passwordChanged,
                    controller: _passwordcontroller,
                    keyboardType: TextInputType.text,
                    obscureText: true,
                    decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: "Enter password",
                        labelText: "Password",
                        errorText: snapshot.error),
                  ),
                ),
                SizedBox(
                  height: 20.0,
                ),
                StreamBuilder<bool>(
                  stream: bloc.submitCheck,
                  builder: (context, snapshot) => RaisedButton(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(80.0)),
                    padding: const EdgeInsets.all(0.0),
                    child: Ink(
                      decoration: snapshot.hasData
                          ? const BoxDecoration(
                              gradient: LinearGradient(
                                colors: [Colors.indigo, Colors.lightBlueAccent],
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                              ),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(80.0)),
                            )
                          : null,
                      child: Container(
                        constraints: const BoxConstraints(
                            minWidth: 88.0, minHeight: 40.0),
                        // min sizes for Material buttons
                        alignment: Alignment.center,
                        child: const Text(
                          'Login',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    onPressed:
                        snapshot.hasData ? () => changeThePage(context) : null,
                  ),
                ),
                SizedBox(
                  height: 10.0,
                ),
                RaisedButton(
                  color: Colors.tealAccent,
                  onPressed: () {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => BlocProvider(
                            child: RegisterPage(), bloc: UserBloc())));
                  },
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(80.0)),
                  padding: const EdgeInsets.all(0.0),
                  child: Ink(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.indigo, Colors.lightBlueAccent],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(80.0)),
                    ),
                    child: Container(
                      constraints:
                          const BoxConstraints(minWidth: 88.0, minHeight: 40.0),
                      // min sizes for Material buttons
                      alignment: Alignment.center,
                      child: const Text(
                        'Register',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                            color: Colors.white),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void onLoginError(String error) {
    _showSnackBar();
  }

  @override
  void onLoginSuccess(User user) {

    Navigator.of(context).push(MaterialPageRoute(
        builder: (context) =>
            NoteBlocProvider(child: HomePage(email: email), bloc: NotesBloc())));
  }
}
