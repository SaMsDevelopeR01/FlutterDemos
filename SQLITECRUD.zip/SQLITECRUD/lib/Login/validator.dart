import 'dart:async';

mixin Validators {
  var emailValidator =
      StreamTransformer<String, String>.fromHandlers(handleData: (email, sink) {
    bool emailValid = RegExp(r'^.+@[a-zA-Z]+\.{1}[a-zA-Z]+(\.{0,1}[a-zA-Z]+)$')
        .hasMatch(email);
    if (!emailValid) {
      sink.addError("Email is not valid");
    } else if (email == null) {
      sink.addError("please! Enter Email");
    } else {
      sink.add(email);
    }
  });

  var passwordValidator = StreamTransformer<String, String>.fromHandlers(
      handleData: (password, sink) {
    bool passwordValid = RegExp(
            r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,14}$')
        .hasMatch(password);
    if (!passwordValid) {
      sink.addError("Password is not Valid");
    } else if (password == null) {
      sink.addError("Please! Enter Password");
    } else {
      sink.add(password);
    }
  });
  var phnoValidator = StreamTransformer<String, String>.fromHandlers(
      handleData: (phno, sink) {
        if (phno.length != 10) {
          sink.addError("Mobile Number must be of 10 digit");
        } else if (phno == null) {
          sink.add(phno);
        } else {
          sink.add(phno);
        }
      });
}
