import 'package:flutter/material.dart';

abstract class BlocBase {
  void dispose();
}

class NoteBlocProvider<T extends BlocBase> extends StatefulWidget {
  NoteBlocProvider({
    Key key,
    @required this.child,
    @required this.bloc,
  }) : super(key: key);

  final T bloc;
  final Widget child;

  @override
  _NoteBlocProviderState<T> createState() => _NoteBlocProviderState<T>();

  static T of<T extends BlocBase>(BuildContext context) {
    final type = _typeOf<NoteBlocProvider<T>>();
    NoteBlocProvider<T> provider =
        context.findAncestorWidgetOfExactType<NoteBlocProvider<T>>();
    return provider.bloc;
  }

  static Type _typeOf<T>() => T;
}

class _NoteBlocProviderState<T> extends State<NoteBlocProvider<BlocBase>> {
  @override
  void dispose() {
    widget.bloc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return widget.child;
  }
}
