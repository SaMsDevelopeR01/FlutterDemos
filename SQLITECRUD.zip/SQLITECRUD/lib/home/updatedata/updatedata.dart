import 'dart:io';
import 'package:crudwithsqflite/home/notebloc.dart';
import 'package:crudwithsqflite/home/noteblocprovider.dart';
import 'package:crudwithsqflite/models/note.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'Updatedatabloc.dart';
import '../homepage.dart';

class UpdateData extends StatefulWidget {
  final id;
  final title;
  final detail;
  final image;
  final email;

  const UpdateData(
      {Key key, this.id, this.title, this.detail, this.image, this.email})
      : super(key: key);

  @override
  _UpdateDataState createState() =>
      _UpdateDataState(id, title, detail, image, email);

}

class _UpdateDataState extends State<UpdateData> {
  final id;
  final email;
  var title;
  var detail;
  var image;

  File _image;
  final bloc = Bloc();
  NotesBloc notesBloc;
  var formkey = GlobalKey<FormState>();

  _UpdateDataState(this.id, this.title, this.detail, this.image, this.email);

  @override
  void initState() {
    super.initState();
    notesBloc = NoteBlocProvider.of(context);
  }

  _imgFromCamera() async {
    File image = await ImagePicker.pickImage(
        source: ImageSource.camera, imageQuality: 50);
    Directory documentDirectory = await getApplicationDocumentsDirectory();
    var path = documentDirectory.path;

    var uniqueImageName = path +
        '/' +
        'image_' +
        DateTime.now().millisecondsSinceEpoch.toString() +
        '.png';

    final File newImage = await image.copy(uniqueImageName);
    //String base64Encoded = base64Encode(newImage.readAsBytesSync());
    //bloc.selectImage(base64Encoded);

    bloc.selectImage(uniqueImageName);

    setState(() {
      _image = newImage;
    });
  }

  _imgFromGallery() async {
    File image = await ImagePicker.pickImage(
        source: ImageSource.gallery, imageQuality: 50);
    Directory documentDirectory = await getApplicationDocumentsDirectory();
    var path = documentDirectory.path;

    var uniqueImageName = path +
        '/' +
        'image_' +
        DateTime.now().millisecondsSinceEpoch.toString() +
        '.png';
    final File newImage = await image.copy(uniqueImageName);

    bloc.selectImage(newImage);

    setState(() {
      _image = newImage;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Update Data"),
      ),
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          padding: EdgeInsets.all(30),
          child: Form(
            key: formkey,
            child: Column(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: () {
                    _showPicker(context);
                  },
                  child: CircleAvatar(
                    radius: 55,
                    // backgroundImage: fetchImageFromPath(image),
                    backgroundColor: Color(0xffFDCF09),
                    child: fetchImageFromPath(image) != null
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(50),
                            child: Image.file(
                              File(image),
                              width: 100,
                              height: 100,
                              fit: BoxFit.cover,
                            ),
                          )
                        : Container(
                            decoration: BoxDecoration(
                                color: Colors.grey[200],
                                borderRadius: BorderRadius.circular(50)),
                            width: 100,
                            height: 100,
                            child: Icon(
                              Icons.camera_alt,
                              color: Colors.grey[800],
                            ),
                          ),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                StreamBuilder<String>(
                  stream: bloc.title,
                  builder: (context, snapshot) => TextFormField(
                    onChanged: bloc.titleChanged,
                    initialValue: title,
                    onSaved: (val) => title = val,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: "Enter Title",
                        labelText: "Title",
                        errorText: snapshot.error),
                  ),
                ),
                SizedBox(
                  height: 20.0,
                ),
                StreamBuilder<String>(
                  stream: bloc.detail,
                  builder: (context, snapshot) => TextFormField(
                    onChanged: bloc.detailChanged,
                    initialValue: detail,
                    onSaved: (val) => detail = val,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: "Enter Description",
                        labelText: "Description",
                        errorText: snapshot.error),
                  ),
                ),
                SizedBox(
                  height: 20.0,
                ),
                StreamBuilder<bool>(
                  stream: bloc.submitCheck,
                  builder: (context, snapshot) => RaisedButton(
                    color: Colors.tealAccent,
                    onPressed: () => updateData(context),
                    //bloc.submit(context),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(80.0)),
                    padding: const EdgeInsets.all(0.0),
                    child: Ink(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.indigo, Colors.lightBlueAccent],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(80.0)),
                      ),
                      child: Container(
                        constraints: const BoxConstraints(
                            minWidth: 88.0, minHeight: 40.0),
                        // min sizes for Material buttons
                        alignment: Alignment.center,
                        child: const Text(
                          'Update',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  updateData(BuildContext context) async {
    final form = formkey.currentState;
    setState(() {
      form.save();
      Note note = Note(id: id,email: email, title: title, detail: detail, picture: image);
      print('Update Data: ${note.toJson()}');
      notesBloc.inUpdateNote.add(note);
    });

    Navigator.of(context).push(MaterialPageRoute(
        builder: (context) =>
            NoteBlocProvider(child: HomePage(email: email,), bloc: NotesBloc())));
  }

  void _showPicker(context) {
    showModalBottomSheet(
        context: context,
        builder: (BuildContext bc) {
          return SafeArea(
            child: Container(
              child: Wrap(
                children: <Widget>[
                  ListTile(
                      leading: Icon(Icons.photo_library),
                      title: Text('Photo Library'),
                      onTap: () {
                        _imgFromGallery();
                        Navigator.of(context).pop();
                      }),
                  ListTile(
                    leading: Icon(Icons.photo_camera),
                    title: Text('Camera'),
                    onTap: () {
                      _imgFromCamera();
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              ),
            ),
          );
        });
  }

  Widget fetchImageFromPath(String imagePath) {
    File imageFile = File(imagePath);
    var image = Image.file(imageFile);
    return image;
  }
}
