import 'dart:async';

mixin Validators {
  var titleValidator =
      StreamTransformer<String, String>.fromHandlers(handleData: (title, sink) {
    if (title.length <= 25 && title.length >= 5) {
      sink.add(title);
    } else {
      sink.addError("Title length should Contain 5 to 25 Character.");
    }
  });

  var detailValidator = StreamTransformer<String, String>.fromHandlers(
      handleData: (detail, sink) {
    if (detail.length <= 50) {
      sink.add(detail);
    } else {
      sink.addError("Detail length should Contain Maximun 50 Character.");
    }
  });
}
