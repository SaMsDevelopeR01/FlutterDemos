import 'dart:async';
import 'package:crudwithsqflite/data/database.dart';
import 'package:crudwithsqflite/home/notebloc.dart';
import 'package:crudwithsqflite/home/noteblocprovider.dart';
import 'package:crudwithsqflite/home/updatedata/updatevalidator.dart';
import 'package:crudwithsqflite/models/note.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:rxdart/rxdart.dart';
import '../homepage.dart';

class Bloc extends Object with Validators implements BaseBloc {
  final _idController = BehaviorSubject<int>();
  final _titleController = BehaviorSubject<String>();
  final _detailController = BehaviorSubject<String>();
  final _imageController = BehaviorSubject<String>();
  final _emailController = BehaviorSubject<String>();

  Function(String) get titleChanged => _titleController.sink.add;

  Function(String) get detailChanged => _detailController.sink.add;

  Function(String) get imageChanged => _imageController.sink.add;

  //Another way
  // StreamSink<String> get emailChanged => _emailController.sink;
  //StreamSink<String> get passwordChanged => _passwordController.sink;

  Stream<String> get title => _titleController.stream.transform(titleValidator);

  Stream<String> get detail =>
      _detailController.stream.transform(detailValidator);

  Stream<bool> get submitCheck =>
      Rx.combineLatest2(title, detail, (e, p) => true);

  submit(BuildContext context) async {
    Note note = Note(
        id: _idController.value,
        email: _emailController.value,
        title: _titleController.value,
        detail: _detailController.value,
        picture: _imageController.value);

    print('Update Data Bloc: ${note.toJson()}');

    NotesBloc notesBloc = NoteBlocProvider.of(context);
    notesBloc.inUpdateNote.add(note);
    //notesBloc.getNotes();

    Navigator.of(context).push(MaterialPageRoute(
        builder: (context) => NoteBlocProvider(
            child: HomePage(
              email: _emailController.value,
            ),
            bloc: notesBloc)));
  }

  selectID(id) {
    _idController.sink.add(id);
  }

  selectupdateemail(email) {
    _emailController.sink.add(email);
  }

  selectImage(newImage) {
    _imageController.sink.add(newImage);
  }

  @override
  void dispose() {
    _titleController?.close();
    _detailController?.close();
    _idController?.close();
    _imageController?.close();
  }
}

abstract class BaseBloc {
  void dispose();
}
