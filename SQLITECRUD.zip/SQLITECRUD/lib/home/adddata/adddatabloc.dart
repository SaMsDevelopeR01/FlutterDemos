import 'dart:async';
import 'dart:typed_data';
import 'package:crudwithsqflite/home/notebloc.dart';
import 'package:crudwithsqflite/home/noteblocprovider.dart';
import 'package:crudwithsqflite/models/note.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:rxdart/rxdart.dart';
import '../homepage.dart';
import 'homevalidator.dart';

class Bloc extends Object with Validators implements BaseBloc {
  final _idController = BehaviorSubject<int>();
  final _titleController = BehaviorSubject<String>();
  final _detailController = BehaviorSubject<String>();
  final _imageController = BehaviorSubject<String>();
  final _emailController = BehaviorSubject<String>();

  Function(String) get titleChanged => _titleController.sink.add;

  Function(String) get detailChanged => _detailController.sink.add;

  Function(String) get imageChanged => _imageController.sink.add;

  //Another way
  // StreamSink<String> get emailChanged => _emailController.sink;
  //StreamSink<String> get passwordChanged => _passwordController.sink;

  Stream<String> get title => _titleController.stream.transform(titleValidator);

  Stream<String> get detail => _detailController.stream.transform(detailValidator);

  Stream<String> get image => _imageController.stream.transform(imageValidator);

  Stream<bool> get submitCheck => Rx.combineLatest3(title, detail, image, (e, p, i) => true);

  submit(BuildContext context) async {
    Note note = Note(
        id: _idController.value,
        email: _emailController.value,
        title: _titleController.value,
        detail: _detailController.value,
        picture: _imageController.value);
    NotesBloc notesBloc = NoteBlocProvider.of(context);
    notesBloc.inAddNote.add(note);
    //print("insert: ${note.toJson()}");
    //("emailcontrollerbloc: ${_emailController.value}");

    Navigator.of(context).push(MaterialPageRoute(
        builder: (context) =>
            NoteBlocProvider(child: HomePage(email: _emailController.value,), bloc: notesBloc)));
  }

  selectImage(newImage) {
    _imageController.sink.add(newImage);
  }
  selectemail(newEmail) {
    _emailController.sink.add(newEmail);
    //print('select email: $newEmail');
  }

  @override
  void dispose() {
    _titleController?.close();
    _detailController?.close();
    _idController?.close();
    _imageController?.close();
  }
}

abstract class BaseBloc {
  void dispose();
}
