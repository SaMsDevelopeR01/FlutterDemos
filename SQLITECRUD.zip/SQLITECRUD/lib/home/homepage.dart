import 'dart:io';
import 'package:crudwithsqflite/Login/loginpage.dart';
import 'package:crudwithsqflite/data/bloc/blocprovider.dart';
import 'package:crudwithsqflite/data/bloc/userbloc.dart';
import 'package:crudwithsqflite/data/database.dart';
import 'package:crudwithsqflite/home/updatedata/Updatedatabloc.dart';
import 'package:crudwithsqflite/home/adddata/adddata.dart';
import 'package:crudwithsqflite/home/notebloc.dart';
import 'package:crudwithsqflite/home/noteblocprovider.dart';
import 'package:crudwithsqflite/home/updatedata/updatedata.dart';
import 'package:crudwithsqflite/models/note.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomePage extends StatelessWidget {
  final email;

  const HomePage({Key key, this.email}) : super(key: key);
  @override
  Widget build(BuildContext context) {

    print("*** Object Called ***");

    return Scaffold(
      appBar: AppBar(
          automaticallyImplyLeading: false,
          title: Text(
            "Home",
            style: TextStyle(),
          ),
          backgroundColor: Colors.lightBlueAccent,
          actions: <Widget>[
            FlatButton(
              minWidth: 5.0,
              onPressed: () {
                showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        content: Text("Are you sure you want to Logout?"),
                        actions: <Widget>[
                          FlatButton(
                            child: Text(
                              "No",
                              style: TextStyle(color: Colors.black),
                            ),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          ),
                          FlatButton(
                            child: Text(
                              "Yes",
                              style: TextStyle(color: Colors.red),
                            ),
                            onPressed: () async {
                              final SharedPreferences sharedPreferences =
                                  await SharedPreferences.getInstance();
                              sharedPreferences.remove('email');
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (context) => BlocProvider(
                                      child: LoginPage(), bloc: UserBloc())));
                              // Navigator.of(context).pop();
                            },
                          ),
                        ],
                      );
                    });
              },
              child: Icon(
                Icons.logout,
                color: Colors.white,
              ),
            ),
          ]),
      body: NoteList(email: email),
    );
  }
}

class NoteList extends StatefulWidget {

  final email;
  const NoteList({Key key, this.email}) : super(key: key);

  @override

  _NoteListState createState() => _NoteListState(email);
}

class _NoteListState extends State<NoteList> {
  final email;
  NotesBloc _notesBloc;
  final bloc = Bloc();
  final updateBloc =Bloc();
  var data = List<Note>();
  int count;
  var pic;
  _NoteListState(this.email);

  @override
  void initState() {
    super.initState();
    updateBloc.selectupdateemail(email);
    _notesBloc = NoteBlocProvider.of<NotesBloc>(context);
    _notesBloc.getNotes(email);
    _notesBloc.notes.first.then((res) => {
          setState(() {
            data = res;
            // res.forEach((element) {
            //   print('Home Page: ${element.toJson()}');
            //
            // });
          })
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Flexible(
              child: getNoteListView()),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Container(
              child: Align(
                alignment: Alignment.bottomLeft,
                child: Text(
                  'Total: ${data.length}',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: Colors.blue,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {

          Navigator.of(context).push(MaterialPageRoute(
              builder: (context) =>
                  NoteBlocProvider(child: AddData(email: email,), bloc: _notesBloc)));
        },
        child: Icon(Icons.add),
      ),
    );
  }

  ListView getNoteListView() {
    TextStyle titleStyle = Theme.of(context).textTheme.subhead;
    return ListView.builder(
        itemCount: data.length == null
            ? Center(
                child: Text(
                "No Data Found",
                style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                ),
              ))
            : data.length,
        itemBuilder: (BuildContext context, int position) {
          return Column(
            children: [
              Dismissible(
                key: Key(data[position].toString()),
                child: InkWell(
                  onTap: () {
                    print("${data[position]} clicked");
                  },
                  child: ListTile(
                    leading: CircleAvatar(
                        backgroundColor: Colors.yellow,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(50.0),
                          child: fetchImageFromPath(data[position].picture),
                        )),
                    title: Text(
                      this.data[position].title,
                      style: titleStyle,
                    ),
                    subtitle: Text(this.data[position].detail),
                  ),
                ),
                secondaryBackground: slideLeftBackground(),
                background: slideRightBackground(),
                confirmDismiss: (direction) async {
                  if (direction == DismissDirection.endToStart) {
                    final bool res = await showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            content: Text(
                                "Are you sure you want to delete '${data[position].title}' ?"),
                            actions: <Widget>[
                              FlatButton(
                                child: Text(
                                  "Cancel",
                                  style: TextStyle(color: Colors.black),
                                ),
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                              ),
                              FlatButton(
                                child: Text(
                                  "Delete",
                                  style: TextStyle(color: Colors.red),
                                ),
                                onPressed: () {
                                  DBProvider.db.deleteNote(data[position].id);
                                  setState(() {
                                    data.removeAt(position);
                                  });
                                  Navigator.of(context).pop();
                                },
                              ),
                            ],
                          );
                        });
                    return res;
                  } else {
                    final bool res = await showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            content: Text(
                                "Are you sure you want to edit '${data[position].title}' ?"),
                            actions: <Widget>[
                              FlatButton(
                                child: Text(
                                  "Cancel",
                                  style: TextStyle(color: Colors.black),
                                ),
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                              ),
                              FlatButton(
                                child: Text(
                                  "Edit",
                                  style: TextStyle(color: Colors.green),
                                ),
                                onPressed: () async {

                                  await Navigator.of(context).push(
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              NoteBlocProvider(
                                                  child: UpdateData(
                                                    id: data[position].id,
                                                    title: data[position].title,
                                                    detail:
                                                        data[position].detail,
                                                    image:
                                                        data[position].picture,
                                                    email: email,
                                                  ),
                                                  bloc: _notesBloc)));
                                  Navigator.of(context).pop();
                                },
                              ),
                            ],
                          );
                        });
                    return res;
                  }
                },
              ),
              Divider(
                height: 2.0,
              ),
            ],
          );
        });
  }

  Widget slideLeftBackground() {
    return Container(
      color: Colors.red,
      child: Align(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            Icon(
              Icons.delete,
              color: Colors.white,
            ),
            Text(
              " Delete",
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
              textAlign: TextAlign.right,
            ),
            SizedBox(
              width: 20,
            ),
          ],
        ),
        alignment: Alignment.centerRight,
      ),
    );
  }

  Widget slideRightBackground() {
    return Container(
      color: Colors.green,
      child: Align(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            SizedBox(
              width: 20,
            ),
            Icon(
              Icons.edit,
              color: Colors.white,
            ),
            Text(
              " Edit",
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
              textAlign: TextAlign.left,
            ),
          ],
        ),
        alignment: Alignment.centerLeft,
      ),
    );
  }

  Widget fetchImageFromPath(String imagePath) {
    File imageFile = File(imagePath);
    var image = Image.file(
      imageFile,
      fit: BoxFit.cover,
      height: 100,
      width: 100,
    );
    return image;
  }
}
