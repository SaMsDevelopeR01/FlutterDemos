import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'bloc/firebase_bloc.dart';
import 'bloc/firebase_event.dart';
import 'bloc/firebase_state.dart';
import 'homepage.dart';
import 'models/note.dart';

class UpdatePage extends StatefulWidget {
  final email;
  final id;

  const UpdatePage({Key key, this.email, this.id}) : super(key: key);

  @override
  _UpdatePageState createState() => _UpdatePageState(email, id);
}

class _UpdatePageState extends State<UpdatePage> {
  final formKey = GlobalKey<FormState>();
  final selectedEmail;
  final selectedId;
  String id, email, title, detail, picture;
  File _image;
  File image;
  String downloadUrl;
  String url;

  _UpdatePageState(this.selectedEmail, this.selectedId);

  @override
  void initState() {
    super.initState();
  }

  _imgFromCamera() async {
    image = await ImagePicker.pickImage(
        source: ImageSource.camera, imageQuality: 50);
    if (image != null) {
      setState(() {
        _image = image;
      });
    }
  }

  Future uploadImage() async {
    final _firebaseStorage = FirebaseStorage.instance;
    await Permission.photos.request();
    var permissionStatus = await Permission.photos.status;
    print("permissionStatus:$permissionStatus");
    //if (permissionStatus.isGranted) {
    var file = File(image.path);
    print("hiii");
    //Upload to Firebase
    var snapshot =
        await _firebaseStorage.ref().child('images/imageName').putFile(file);
    picture = await snapshot.ref.getDownloadURL();

    print("funcdownloadUrl:$downloadUrl");
    //}
  }

  _imgFromGallery() async {
    image = await ImagePicker.pickImage(
        source: ImageSource.gallery, imageQuality: 50);
    if (image != null) {
      setState(() {
        _image = image;
      });
    }
  }

  @override
  Widget build(BuildContext mainContext) {
    BlocProvider.of<FirebaseBloc>(mainContext).add(ResetUserDetail());
    return Scaffold(
      appBar: AppBar(
        title: Text("Update Data"),
      ),
      body: BlocBuilder<FirebaseBloc, FirebaseState>(
          builder: (mainContext, state) {
        print(state);
        if (state is UserDetailEmpty || state is LoginEmpty) {
          BlocProvider.of<FirebaseBloc>(mainContext)
              .add(FetchUserDetail(selectedId));
        }

        if (state is UserDetailError) {
          return Center(
            child: Text('Failed to Fetch Data'),
          );
        }

        if (state is UserDetailLoaded) {
          var currentUserDetail = state.user;
          // setState(() {

          id = currentUserDetail.id;
          email = currentUserDetail.email;
          title = currentUserDetail.title;
          detail = currentUserDetail.detail;
          picture = currentUserDetail.picture;
          //File imageFile = File(picture);
          // _image = imageFile;
          // });
          return Container(
            child: body(context, currentUserDetail),
          );
        }
        if (state is UserDetailUpdated) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            BlocProvider.of<FirebaseBloc>(mainContext).add(ResetUsersList());
            Navigator.pop(mainContext);
            // Navigator.of(mainContext).push(MaterialPageRoute(
            //     builder: (_) => BlocProvider.value(
            //         value: BlocProvider.of<FirebaseBloc>(mainContext),
            //         child: HomePage(
            //           email: email,
            //         ))));
          });
        }

        return Center(
          child: CircularProgressIndicator(),
        );
      }),
    );
  }

  Widget body(BuildContext mainContext, Note note) {
    return SingleChildScrollView(
      child: Container(
        height: MediaQuery.of(context).size.height,
        padding: EdgeInsets.all(30),
        child: Form(
          key: formKey,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () {
                  _showPicker(context);
                },
                child: CircleAvatar(
                  radius: 55,
                  backgroundColor: Color(0xffFDCF09),
                  child: _image != null
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(50),
                          child: Image.file(
                            _image,
                            width: 100,
                            height: 100,
                            fit: BoxFit.cover,
                          ),
                        )
                      : ClipRRect(
                          borderRadius: BorderRadius.circular(50),
                          child: FadeInImage(
                            image: NetworkImage(picture),
                            placeholder:
                                AssetImage("assets/images/placeholder.png"),
                            width: 100,
                            height: 100,
                            fit: BoxFit.cover,
                          ),
                        ),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              TextFormField(
                keyboardType: TextInputType.text,
                initialValue: note.title,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Enter Title",
                  labelText: "Title",
                ),
                validator: (val) {
                  if (val.isEmpty) {
                    return 'Please Enter Title';
                  } else if (val.length < 4 || val.length > 12) {
                    return 'Title length should be more then 4';
                  }
                  return null;
                },
                onChanged: (val) => title = val,
              ),
              SizedBox(
                height: 20.0,
              ),
              TextFormField(
                keyboardType: TextInputType.text,
                initialValue: note.detail,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Enter Description",
                  labelText: "Description",
                ),
                validator: (val) {
                  if (val.isEmpty) {
                    return 'Please Enter Description';
                  } else if (val.length > 25) {
                    return 'Description length must be less then 25';
                  }
                  return null;
                },
                onChanged: (val) => detail = val,
              ),
              SizedBox(
                height: 20.0,
              ),
              RaisedButton(
                color: Colors.tealAccent,
                onPressed: () {
                  final Form = formKey.currentState;
                  if (Form.validate()) {
                    Form.save();
                    WidgetsBinding.instance.addPostFrameCallback((_) {
                      uploadImage().whenComplete(() {
                        print("id: $id");
                        print("email: $email");
                        BlocProvider.of<FirebaseBloc>(mainContext).add(
                            UpdateUserDetail(
                                id, email, title, detail, picture));
                      });
                    });
                  }
                },
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(80.0)),
                padding: const EdgeInsets.all(0.0),
                child: Ink(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.indigo, Colors.lightBlueAccent],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(80.0)),
                  ),
                  child: Container(
                    constraints:
                        const BoxConstraints(minWidth: 88.0, minHeight: 40.0),
                    // min sizes for Material buttons
                    alignment: Alignment.center,
                    child: const Text(
                      'Update Data',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showPicker(context) {
    showModalBottomSheet(
        context: context,
        builder: (BuildContext bc) {
          return SafeArea(
            child: Container(
              child: Wrap(
                children: <Widget>[
                  ListTile(
                      leading: Icon(Icons.photo_library),
                      title: Text('Photo Library'),
                      onTap: () {
                        _imgFromGallery();
                        Navigator.of(context).pop();
                      }),
                  ListTile(
                    leading: Icon(Icons.photo_camera),
                    title: Text('Camera'),
                    onTap: () {
                      _imgFromCamera();
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              ),
            ),
          );
        });
  }
}
