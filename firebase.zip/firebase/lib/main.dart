import 'package:firebase_core/firebase_core.dart';
import 'package:firebasereg/bloc/firebase_bloc.dart';
import 'package:firebasereg/homepage.dart';
import 'package:firebasereg/repository/firebase_api_client.dart';
import 'package:firebasereg/repository/firebase_repository.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'loginpage.dart';

class CryptoBlocObserer extends BlocObserver {
  @override
  void onEvent(Bloc bloc, Object event) {
    print(event);
    super.onEvent(bloc, event);
  }

  @override
  void onChange(Cubit cubit, Change change) {
    print(change);
    super.onChange(cubit, change);
  }

  @override
  void onTransition(Bloc bloc, Transition transition) {
    print(transition);
    super.onTransition(bloc, transition);
  }

  @override
  void onError(Cubit cubit, Object error, StackTrace stackTrace) {
    print(error);
    super.onError(cubit, error, stackTrace);
  }
}

void main() async {
  Bloc.observer = CryptoBlocObserer();
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  final FirebaseRepository repository = FirebaseRepository(
    firebaseApiClient: FirebaseApiClient(
      httpClient: http.Client(),
    ),
  );

  runApp(MyApp(
    repository: repository,
  ));
}

class MyApp extends StatefulWidget {
  final FirebaseRepository repository;

  MyApp({Key key, @required this.repository})
      : assert(repository != null),
        super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  String finalEmail;

  @override
  void initState() {
    super.initState();
    getvalidationdata().whenComplete(() async {});
  }

  Future getvalidationdata() async {
    final SharedPreferences sharedPreferences =
        await SharedPreferences.getInstance();
    var obtainedEmail = sharedPreferences.getString('emailId');
    setState(() {
      finalEmail = obtainedEmail;
    });

  }

  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: BlocProvider(
          create: (context) => FirebaseBloc(repository: widget.repository),
          child: finalEmail == null
              ? LoginPage()
              : HomePage(
                  email: finalEmail,
                ),
        ),
      ),
    );
  }
}
