import 'dart:async';
import 'package:firebasereg/models/note.dart';
import 'package:firebasereg/models/user.dart';
import 'package:firebasereg/repository/firebase_api_client.dart';
import 'package:meta/meta.dart';

class FirebaseRepository {
  final FirebaseApiClient firebaseApiClient;

  FirebaseRepository({@required this.firebaseApiClient})
      : assert(firebaseApiClient != null);

  Future<User> fetchRegister(String email, String password,
      String confirmPassword, String phno) async {
    return await firebaseApiClient.fetchRegister(
        email, password, confirmPassword, phno);
  }

  Future<User> fetchLogin(String email, String password) async {
    return await firebaseApiClient.fetchLogin(email, password);
  }

  Future<Note> fetchAddData(
      String email, String title, String detail, String picture) async {
    return await firebaseApiClient.fetchAddData(email, title, detail, picture);
  }

  Future<List<Note>> fetchData(String email) async {
    return await firebaseApiClient.fetchData(email);
  }

  Future<Note> fetchUserDetail(String id) async {
    return await firebaseApiClient.fetchUserDetail(id);
  }

  Future<bool> updateUserDetail(String id, String email, String title,
      String detail, String picture) async {
    return await firebaseApiClient.updateUserDetail(
        id, email, title, detail, picture);
  }

  Future<bool> deleteUserDetail(String email) async {
    return await firebaseApiClient.deleteUserDetail(email);
  }
}
