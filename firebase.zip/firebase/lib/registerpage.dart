import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'bloc/firebase_bloc.dart';
import 'bloc/firebase_event.dart';
import 'bloc/firebase_state.dart';
import 'homepage.dart';

class RegisterPage extends StatefulWidget {
  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage>
    with SingleTickerProviderStateMixin {
  Animation iconAnimation;
  AnimationController iconAnimationcontroller;
  final _emailcontroller = TextEditingController();
  final formKey = GlobalKey<FormState>();
  String email, password, confirmPassword, phNo;

  @override
  void initState() {
    super.initState();
    iconAnimationcontroller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 500));
    iconAnimation = CurvedAnimation(
        curve: Curves.fastOutSlowIn, parent: iconAnimationcontroller);

    iconAnimation.addListener(() {
      setState(() {});
    });
    iconAnimationcontroller.forward();
  }

  @override
  void dispose() {
    iconAnimationcontroller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext mainContext) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Register'),
      ),
      body: BlocBuilder<FirebaseBloc, FirebaseState>(
          builder: (mainContext, state) {
        if (state is RegisterEmpty || state is LoginEmpty) {
          return Container(
            child: body(mainContext),
          );
        }

        if (state is RegisterError) {
          return Center(
            child: Text('Failed to Fetch Data'),
          );
        }

        if (state is RegisterLoaded) {
          print("Registered::${state.register.email}");
          WidgetsBinding.instance.addPostFrameCallback((_) {
            Navigator.of(mainContext).push(MaterialPageRoute(
                builder: (_) => BlocProvider.value(
                    value: BlocProvider.of<FirebaseBloc>(mainContext),
                    child: HomePage(
                      email: email,
                    ))));
          });
        }

        return Center(
          child: CircularProgressIndicator(),
        );
      }),
    );
  }

  Widget body(BuildContext mainContext) {
    return SingleChildScrollView(
      child: Container(
        height: MediaQuery.of(context).size.height,
        padding: EdgeInsets.all(16),
        child: Form(
          key: formKey,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Padding(padding: const EdgeInsets.only(top: 15.0)),
              FlutterLogo(
                size: iconAnimation.value * 100,
              ),
              SizedBox(
                height: 25,
              ),
              TextFormField(
                keyboardType: TextInputType.emailAddress,
                controller: _emailcontroller,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Enter email",
                  labelText: "Email",
                ),
                validator: (val) {
                  if (val.isEmpty) {
                    return 'Please Enter Email';
                  } else if (!RegExp(
                          r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                      .hasMatch(val)) {
                    return 'Enter Valid Email';
                  }
                  return null;
                },
                onChanged: (val) => email = val,
              ),
              SizedBox(
                height: 20.0,
              ),
              TextFormField(
                keyboardType: TextInputType.text,
                obscureText: true,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Enter password",
                  labelText: "Password",
                ),
                validator: (val) {
                  if (val.isEmpty) {
                    return 'Please Enter Password';
                  } else if (!RegExp(
                          r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,14}$')
                      .hasMatch(val)) {
                    return 'Enter Valid Password';
                  } else {
                    return null;
                  }
                },
                onChanged: (val) => password = val,
              ),
              SizedBox(
                height: 20.0,
              ),
              TextFormField(
                keyboardType: TextInputType.text,
                obscureText: true,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Enter Confirm password",
                  labelText: "Confirm Password",
                ),
                validator: (val) {
                  if (val.isEmpty) {
                    return 'Please Enter Confirm Password';
                  } else if (val != password) {
                    return 'Not Match';
                  } else if (!RegExp(
                          r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,14}$')
                      .hasMatch(val)) {
                    return 'Enter Valid Confirm Password';
                  } else {
                    return null;
                  }
                },
                onChanged: (val) => confirmPassword = val,
              ),
              SizedBox(
                height: 20.0,
              ),
              TextFormField(
                keyboardType: TextInputType.phone,
                obscureText: true,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Enter Phone No.",
                  labelText: "Phone No",
                ),
                validator: (val) {
                  if (val.length < 0 || val.length == 0 || val.length == 10) {
                    return null;
                  } else {
                    return 'Enter Valid Phone No.';
                  }
                },
                onChanged: (val) => phNo = val,
              ),
              SizedBox(
                height: 20.0,
              ),
              RaisedButton(
                onPressed: () {
                  final Form = formKey.currentState;
                  if (Form.validate()) {
                    Form.save();
                    WidgetsBinding.instance.addPostFrameCallback((_) {
                      print([
                        this.email,
                        this.password,
                        this.confirmPassword,
                        this.phNo
                      ]);
                      BlocProvider.of<FirebaseBloc>(mainContext).add(
                          FetchRegister(this.email, this.password,
                              this.confirmPassword, this.phNo));
                    });
                  }
                },
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(80.0)),
                padding: const EdgeInsets.all(0.0),
                child: Ink(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.indigo, Colors.lightBlueAccent],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(80.0)),
                  ),
                  child: Container(
                    constraints:
                        const BoxConstraints(minWidth: 88.0, minHeight: 38.0),
                    // min sizes for Material buttons
                    alignment: Alignment.center,
                    child: const Text(
                      'Register',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: Colors.black,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
