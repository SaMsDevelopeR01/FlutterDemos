import 'package:firebasereg/bloc/firebase_bloc.dart';
import 'package:firebasereg/bloc/firebase_event.dart';
import 'package:firebasereg/bloc/firebase_state.dart';
import 'package:firebasereg/registerpage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'homepage.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with SingleTickerProviderStateMixin {
  Animation iconAnimation;
  AnimationController iconAnimationcontroller;
  final _emailcontroller = TextEditingController();
  final formKey = GlobalKey<FormState>();
  var scaffoldkey = GlobalKey<ScaffoldState>();
  String email, password;

  @override
  void initState() {
    super.initState();
    iconAnimationcontroller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 500));
    iconAnimation = CurvedAnimation(
        curve: Curves.fastOutSlowIn, parent: iconAnimationcontroller);

    iconAnimation.addListener(() {
      setState(() {});
    });
    iconAnimationcontroller.forward();
  }

  @override
  void dispose() {
    iconAnimationcontroller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext mainContext) {
    return Scaffold(
      key: scaffoldkey,
      body: BlocBuilder<FirebaseBloc, FirebaseState>(
          builder: (mainContext, state) {
        //print(state);
        if (state is LoginEmpty) {
          return Container(
            child: body(mainContext),
          );
        }

        if (state is LoginError) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            scaffoldkey.currentState.showSnackBar(SnackBar(
              content: Text(
                "Invalid User",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              backgroundColor: Colors.red,
            ));
          });
          return Container(
            child: body(mainContext),
          );
        }

        if (state is LoginLoaded) {

          WidgetsBinding.instance.addPostFrameCallback((_) {
            Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => BlocProvider.value(
                    value: BlocProvider.of<FirebaseBloc>(context),
                    child: HomePage(
                      email: email,
                    ))));
          });
        }

        return Center(
          child: CircularProgressIndicator(),
        );
      }),
    );
  }

  Widget body(BuildContext mainContext) {
    return SingleChildScrollView(
      child: Container(
        height: MediaQuery.of(context).size.height,
        padding: EdgeInsets.all(16),
        child: Form(
          key: formKey,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              FlutterLogo(
                size: iconAnimation.value * 100,
              ),
              SizedBox(
                height: 20,
              ),
              TextFormField(
                keyboardType: TextInputType.emailAddress,
                controller: _emailcontroller,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Enter email",
                  labelText: "Email",
                ),
                validator: (val) {
                  if (val.isEmpty) {
                    return 'Please Enter Email';
                  } else if (!RegExp(
                          r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                      .hasMatch(val)) {
                    return 'Enter Valid Email';
                  }
                  return null;
                },
                onChanged: (val) => email = val,
              ),
              SizedBox(
                height: 20.0,
              ),
              TextFormField(
                obscureText: true,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Enter password",
                  labelText: "Password",
                ),
                keyboardType: TextInputType.text,
                validator: (val) {
                  if (val.isEmpty) {
                    return 'Please Enter Password';
                  } else if (!RegExp(
                          r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,14}$')
                      .hasMatch(val)) {
                    return 'Enter Valid Password';
                  } else {
                    return null;
                  }
                },
                onChanged: (val) => password = val,
              ),
              SizedBox(
                height: 20.0,
              ),
              RaisedButton(
                onPressed: () async {
                  print("finalEmail:$email");
                  final Form = formKey.currentState;
                  if (Form.validate()) {
                    Form.save();
                    print("Form:$email");
                    SharedPreferences sharedPreferences =
                    await SharedPreferences.getInstance();
                  await sharedPreferences.setString('emailId', email);
                    BlocProvider.of<FirebaseBloc>(mainContext)
                        .add(FetchLogin(email, password));
                  }
                },
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(80.0)),
                padding: const EdgeInsets.all(0.0),
                child: Ink(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.indigo, Colors.lightBlueAccent],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(80.0)),
                  ),
                  child: Container(
                    constraints:
                        const BoxConstraints(minWidth: 88.0, minHeight: 40.0),
                    // min sizes for Material buttons
                    alignment: Alignment.center,
                    child: const Text(
                      'Login',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 10.0,
              ),
              RaisedButton(
                onPressed: () {
                  Navigator.of(mainContext).push(MaterialPageRoute(
                      builder: (_) => BlocProvider.value(
                          value: BlocProvider.of<FirebaseBloc>(context),
                          child: RegisterPage())));
                },
                color: Colors.tealAccent,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(80.0)),
                padding: const EdgeInsets.all(0.0),
                child: Ink(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.indigo, Colors.lightBlueAccent],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(80.0)),
                  ),
                  child: Container(
                    constraints:
                        const BoxConstraints(minWidth: 88.0, minHeight: 40.0),
// min sizes for Material buttons
                    alignment: Alignment.center,
                    child: const Text(
                      'Register',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: Colors.white),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
