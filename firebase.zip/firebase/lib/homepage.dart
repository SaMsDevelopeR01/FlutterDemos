import 'dart:io';
import 'package:cool_alert/cool_alert.dart';
import 'package:firebasereg/loginpage.dart';
import 'package:firebasereg/update.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'AddData.dart';
import 'bloc/firebase_bloc.dart';
import 'bloc/firebase_event.dart';
import 'bloc/firebase_state.dart';
import 'models/note.dart';

class HomePage extends StatefulWidget {
  final email;

  const HomePage({Key key, this.email}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState(email);
}

class _HomePageState extends State<HomePage> {
  final email;

  _HomePageState(this.email);

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    print("IniTTTTTTT");
  }
  @override
  Widget build(BuildContext mainContext) {
    return Scaffold(
      appBar: AppBar(
          title: Text("Home"), actions: <Widget>[
        FlatButton(
          minWidth: 5.0,
          onPressed: () {
            showDialog(
                context: mainContext,
                builder: (BuildContext context) {
                  return AlertDialog(
                    content: Text("Are you sure you want to Logout?"),
                    actions: <Widget>[
                      FlatButton(
                        child: Text(
                          "No",
                          style: TextStyle(color: Colors.black),
                        ),
                        onPressed: () {
                          Navigator.of(mainContext).pop();
                        },
                      ),
                      FlatButton(
                        child: Text(
                          "Yes",
                          style: TextStyle(color: Colors.red),
                        ),
                        onPressed: () async {
                          final SharedPreferences sharedPreferences =
                              await SharedPreferences.getInstance();
                          sharedPreferences.remove('emailId');
                          Navigator.of(mainContext).push(MaterialPageRoute(
                              builder: (_) => BlocProvider.value(
                                  value: BlocProvider.of<FirebaseBloc>(
                                      mainContext),
                                  child: LoginPage())));
                          BlocProvider.of<FirebaseBloc>(mainContext)
                              .add(ResetLoginData());
                        },
                      ),
                    ],
                  );
                });
          },
          child: Icon(
            Icons.logout,
            color: Colors.white,
          ),
        ),
      ]),
      body: NoteList(
        email: widget.email,
      ),
    );
  }
}

class NoteList extends StatefulWidget {
  final email;

  const NoteList({Key key, this.email}) : super(key: key);

  @override
  _NoteListState createState() => _NoteListState(email);
}

class _NoteListState extends State<NoteList> {
  final email;
  Note note;

  _NoteListState(this.email);

  @override
  Widget build(BuildContext mainContext) {
    print("reset User Email: $email");
    BlocProvider.of<FirebaseBloc>(mainContext).add(ResetUsersList());
    return Scaffold(
      body: BlocBuilder<FirebaseBloc, FirebaseState>(builder: (context, state) {
        print("state Email: $email");

        if (state is DataEmpty) {

          print("DataEmptyemail: $email");
          BlocProvider.of<FirebaseBloc>(mainContext).add(fetchData(email));
        }

        if (state is DataError) {
          return Center(
            child: Text('Failed to Users Data'),
          );
        }

        if (state is DataLoaded) {
          print("DataLoadedemail: $email");
          return Container(
              child: Column(
            children: [
              Flexible(child: getNoteListView(mainContext, state.Data)),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Container(
                  child: Align(
                    alignment: Alignment.bottomLeft,
                    child: Text(
                      'Total: ${state.Data.length}',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        color: Colors.blue,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ));
        }

        if (state is UserDetailDelete) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            BlocProvider.of<FirebaseBloc>(mainContext).add(ResetUsersList());
          });
        }

        return Center(
          child: CircularProgressIndicator(),
        );
      }),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(mainContext).push(MaterialPageRoute(
              builder: (_) => BlocProvider.value(
                  value: BlocProvider.of<FirebaseBloc>(mainContext),
                  child: AddData(
                    email: email,
                  ))));
        },
        child: Icon(Icons.add),
      ),
    );
  }

  ListView getNoteListView(BuildContext mainContext, List<Note> arrayNotes) {
    print(arrayNotes);
    TextStyle titleStyle = Theme.of(context).textTheme.subhead;
    return ListView.builder(
        itemCount: arrayNotes.length == null
            ? Center(
                child: Text(
                "No Data Found",
                style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                ),
              ))
            : arrayNotes.length,
        itemBuilder: (BuildContext context, int position) {
          return Column(
            children: [
              Dismissible(
                key: Key(arrayNotes[position].toString()),
                child: InkWell(
                  onTap: () {
                    print("${arrayNotes[position]} clicked");
                  },
                  child: ListTile(
                    leading: CircleAvatar(
                        backgroundColor: Colors.yellow,
                        child: ClipRRect(
                            borderRadius: BorderRadius.circular(50.0),
                            child: Image.network(
                              arrayNotes[position].picture,
                              fit: BoxFit.cover,
                              height: 100,
                              width: 100,
                            ))),
                    title: Text(
                      arrayNotes[position].title,
                      style: titleStyle,
                    ),
                    subtitle: Text(arrayNotes[position].detail),
                  ),
                ),
                secondaryBackground: slideLeftBackground(),
                background: slideRightBackground(),
                confirmDismiss: (direction) async {
                  if (direction == DismissDirection.endToStart) {
                    final bool res = await showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            content: Text(
                                "Are you sure you want to delete '${arrayNotes[position].title}' ?"),
                            actions: <Widget>[
                              FlatButton(
                                child: Text(
                                  "Cancel",
                                  style: TextStyle(color: Colors.black),
                                ),
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                              ),
                              FlatButton(
                                child: Text(
                                  "Delete",
                                  style: TextStyle(color: Colors.red),
                                ),
                                onPressed: () {
                                  BlocProvider.of<FirebaseBloc>(mainContext)
                                      .add(DeleteUserDetail(
                                          arrayNotes[position].id));
                                  // setState(() {
                                  //arrayNotes.removeAt(position);
                                  //});
                                  Navigator.of(context).pop();
                                },
                              ),
                            ],
                          );
                        });
                    return res;
                  } else {
                    final bool res = await showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            content: Text(
                                "Are you sure you want to edit '${arrayNotes[position].title}' ?"),
                            actions: <Widget>[
                              FlatButton(
                                child: Text(
                                  "Cancel",
                                  style: TextStyle(color: Colors.black),
                                ),
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                              ),
                              FlatButton(
                                child: Text(
                                  "Edit",
                                  style: TextStyle(color: Colors.green),
                                ),
                                onPressed: () async {
                                  var value = await Navigator.of(mainContext)
                                      .push(MaterialPageRoute(
                                          builder: (_) => BlocProvider.value(
                                                value: BlocProvider.of<
                                                    FirebaseBloc>(mainContext),
                                                child: UpdatePage(
                                                  email: email,
                                                  id: arrayNotes[position].id,
                                                ),
                                              )));
                                  Navigator.of(context).pop();
                                  print("RES UDPAED:$value");
                                  if (value != null && value) {
                                    //upadate success
                                    CoolAlert.show(
                                      context: context,
                                      type: CoolAlertType.success,
                                      text: "Profile updated successfully!",
                                    );
                                  }
                                },
                              ),
                            ],
                          );
                        });
                    return res;
                  }
                },
              ),
              Divider(
                height: 2.0,
              ),
            ],
          );
        });
  }

  Widget slideLeftBackground() {
    return Container(
      color: Colors.red,
      child: Align(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            Icon(
              Icons.delete,
              color: Colors.white,
            ),
            Text(
              " Delete",
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
              textAlign: TextAlign.right,
            ),
            SizedBox(
              width: 20,
            ),
          ],
        ),
        alignment: Alignment.centerRight,
      ),
    );
  }

  Widget slideRightBackground() {
    return Container(
      color: Colors.green,
      child: Align(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            SizedBox(
              width: 20,
            ),
            Icon(
              Icons.edit,
              color: Colors.white,
            ),
            Text(
              " Edit",
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
              textAlign: TextAlign.left,
            ),
          ],
        ),
        alignment: Alignment.centerLeft,
      ),
    );
  }

  Widget fetchImageFromPath(String imagePath) {
    print("Imagepath:$imagePath");
    File imageFile = File(imagePath);
    var image = Image.file(
      imageFile,
      fit: BoxFit.cover,
      height: 100,
      width: 100,
    );
    return image;
  }
}
