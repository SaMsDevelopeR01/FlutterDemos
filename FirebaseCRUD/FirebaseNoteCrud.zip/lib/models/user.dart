class User {
  int id;
  String email;
  String password;
  String confirmPassword;
  String phno;

  User({this.id, this.email, this.password, this.confirmPassword, this.phno});

  factory User.fromJson(Map<String, dynamic> json) => new User(
        id: json["id"],
        email: json["email"],
        password: json["password"],
        confirmPassword: json["confirmpassword"],
        phno: json["phno"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "email": email,
        "password": password,
        "confirmPassword": confirmPassword,
        "phno": phno
      };
}
