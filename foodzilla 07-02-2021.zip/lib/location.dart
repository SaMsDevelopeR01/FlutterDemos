import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class LocationWidget extends StatefulWidget {
  @override
  _LocationWidgetState createState() => _LocationWidgetState();
}

class _LocationWidgetState extends State<LocationWidget> {
  final List<String> items = <String>['1', '2', '3'];
  String selectedItem = '1';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Container(
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image(
                image: AssetImage("assets/img/background.png"),
                fit: BoxFit.fill,
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.max,
                children: [
                  Expanded(
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      child: Image(
                        image: AssetImage("assets/img/top.png"),
                        fit: BoxFit.contain,
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisSize: MainAxisSize.max,
                        // mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          SizedBox(
                            height: 30,
                          ),
                          Text(
                            "Select Your Location",
                            style: TextStyle(
                              color: Color(0xFF191E2F),
                              fontSize: 28,
                              fontFamily: 'Rubik',
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Text(
                              "Switch on your location to stay in tune with " +
                                  "\nwhat’s happening in your area",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Color(0xFF8E93A7),
                                fontSize: 16,
                                fontFamily: 'Rubik',
                                fontWeight: FontWeight.w400,
                              )),
                          SizedBox(
                            height: 40,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: 20,
                              ),
                              Text("Your Zone",
                                  textAlign: TextAlign.start,
                                  style: TextStyle(
                                    color: Color(0xFF8E93A7),
                                    fontSize: 17,
                                    fontFamily: 'Rubik',
                                    fontWeight: FontWeight.w400,
                                  )),
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          SizedBox(
                            width: MediaQuery.of(context).size.width - 40,
                            child: DropdownButton<String>(
                              isExpanded: true,
                              underline: Container(
                                height: 2,
                                color: Color(0xFFE2E2E2),
                              ),
                              value: selectedItem,
                              onChanged: (value) =>
                                  setState(() => selectedItem = value),
                              selectedItemBuilder: (BuildContext context) {
                                return items.map<Widget>((String item) {
                                  return Text(item);
                                }).toList();
                              },
                              items: items.map((String item) {
                                return DropdownMenuItem<String>(
                                  child: Text('Log $item'),
                                  value: item,
                                );
                              }).toList(),
                            ),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: 20,
                              ),
                              Text("Your Area",
                                  textAlign: TextAlign.start,
                                  style: TextStyle(
                                    color: Color(0xFF8E93A7),
                                    fontSize: 17,
                                    fontFamily: 'Rubik',
                                    fontWeight: FontWeight.w400,
                                  )),
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          SizedBox(
                            width: MediaQuery.of(context).size.width - 40,
                            child: DropdownButton<String>(
                              isExpanded: true,
                              underline: Container(
                                height: 2,
                                color: Color(0xFFE2E2E2),
                              ),
                              value: selectedItem,
                              onChanged: (value) =>
                                  setState(() => selectedItem = value),
                              selectedItemBuilder: (BuildContext context) {
                                return items.map<Widget>((String item) {
                                  return Text(item);
                                }).toList();
                              },
                              items: items.map((String item) {
                                return DropdownMenuItem<String>(
                                  child: Text('Log $item'),
                                  value: item,
                                );
                              }).toList(),
                            ),
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.only(top: 35.0, bottom: 10.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  width: MediaQuery.of(context).size.width - 40,
                                  decoration: BoxDecoration(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(100)),
                                  ),
                                  child: FlatButton(
                                    padding: EdgeInsets.symmetric(vertical: 20),
                                    onPressed: () {},
                                    color: Theme.of(context).accentColor,
                                    shape: StadiumBorder(),
                                    child: Text(
                                      "Submit",
                                      style: TextStyle(
                                          fontFamily: 'Rubik',
                                          color: Color(0xFFFCFCFC),
                                          fontWeight: FontWeight.w600,
                                          fontSize: 18),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              Align(
                alignment: Alignment.topLeft,
                child: IconButton(
                  icon: Icon(
                    Icons.arrow_back_ios_outlined,
                  ),
                  onPressed: () {
                    print("dksjhfsdkjlfhdsjk");
                    Navigator.of(context).pop();
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
