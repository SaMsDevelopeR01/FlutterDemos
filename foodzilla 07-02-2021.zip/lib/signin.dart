import 'package:country_code_picker/country_code_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

import 'numbersignIn.dart';

class SignInWidget extends StatefulWidget {
  @override
  _SignInWidgetState createState() => _SignInWidgetState();
}

class _SignInWidgetState extends State<SignInWidget> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Container(
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image(
                image: AssetImage("assets/img/background.png"),
                fit: BoxFit.fill,
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.max,
                children: [
                  Expanded(
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      child: Image(
                        image: AssetImage("assets/img/top.png"),
                        fit: BoxFit.fill,
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisSize: MainAxisSize.max,
                        // mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(13.0),
                                child: Text(
                                    "Get your favorite food" +
                                        "\nWith app name",
                                    textAlign: TextAlign.start,
                                    style: TextStyle(
                                      color: Color(0xFF191E2F),
                                      fontSize: 24,
                                      fontFamily: 'Rubik',
                                      fontWeight: FontWeight.w700,
                                    )),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Row(
                            children: [
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 20),
                                child: Container(
                                  height: 50,
                                  width: MediaQuery.of(context).size.width - 40,
                                  decoration: new BoxDecoration(
                                      color: Color(0xFFE2E2E2)),
                                  child: Padding(
                                    padding: const EdgeInsets.only(bottom: 2),
                                    child: Container(
                                      decoration: new BoxDecoration(
                                          color: Color(0xFFFCFBFC)),
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                            flex: 5,
                                            child: CountryCodePicker(
                                              flagWidth: 30,
                                              onChanged: print,
                                              // Initial selection and favorite can be one of code ('IT') OR dial_code('+39')
                                              initialSelection: 'In',
                                              favorite: ['+91', 'IN'],
                                              // optional. Shows only country name and flag
                                              showCountryOnly: true,
                                              // optional. Shows only country name and flag when popup is closed.
                                              showOnlyCountryWhenClosed: false,
                                              // optional. aligns the flag and the Text left
                                              alignLeft: true,
                                            ),
                                          ),
                                          Expanded(
                                            flex: 14,
                                            child: TextField(
                                              keyboardType: TextInputType.phone,
                                              decoration: InputDecoration(
                                                  border: InputBorder.none),
                                              onChanged: (value) {
                                                // this.phoneNo=value;
                                                print(value);
                                              },
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 40,
                          ),
                          Text("Or connect with social media",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Color(0xFF8E93A7),
                                fontSize: 14,
                                fontFamily: 'Rubik',
                                fontWeight: FontWeight.w400,
                              )),
                          SizedBox(
                            height: 30,
                          ),
                          Container(
                            width: MediaQuery.of(context).size.width - 30,
                            decoration: BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(100)),
                            ),
                            child: FlatButton(
                                onPressed: () {
                                  Navigator.of(context).push(MaterialPageRoute(
                                      builder: (_) => NumberSignIn()));
                                },
                                padding: EdgeInsets.symmetric(vertical: 20),
                                color: Color(0xFFDB4437),
                                shape: StadiumBorder(),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Image(
                                      height: 20,
                                      width: 20,
                                      image:
                                          AssetImage("assets/img/goggle.png"),
                                    ),
                                    SizedBox(
                                      width: 40,
                                    ),
                                    Text(
                                      "Continue with Goggle",
                                      style: TextStyle(
                                          fontFamily: 'Rubik',
                                          color: Color(0xFFFCFCFC),
                                          fontWeight: FontWeight.w600,
                                          fontSize: 17),
                                    ),
                                  ],
                                )),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: Container(
                              width: MediaQuery.of(context).size.width - 30,
                              decoration: BoxDecoration(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(100)),
                              ),
                              child: FlatButton(
                                  onPressed: () {},
                                  padding: EdgeInsets.symmetric(vertical: 20),
                                  color: Color(0xFF4A66AC),
                                  shape: StadiumBorder(),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Image(
                                        height: 28,
                                        width: 14,
                                        image: AssetImage(
                                            "assets/img/facebook.png"),
                                      ),
                                      SizedBox(
                                        width: 40,
                                      ),
                                      Text(
                                        "Continue with Facebook",
                                        style: TextStyle(
                                            fontFamily: 'Rubik',
                                            color: Color(0xFFFCFCFC),
                                            fontWeight: FontWeight.w600,
                                            fontSize: 17),
                                      ),
                                    ],
                                  )),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
