import 'package:country_code_picker/country_code_picker.dart';
import 'package:flutter/material.dart';
import 'package:foodzilla/verification.dart';

class NumberSignIn extends StatefulWidget {
  @override
  _NumberSignInState createState() => _NumberSignInState();
}

class _NumberSignInState extends State<NumberSignIn> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      floatingActionButton: Padding(
        padding: const EdgeInsets.all(13.0),
        child: SizedBox(
          height: 70,
          width: 70,
          child: FloatingActionButton(
            child: Icon(
              Icons.navigate_next_outlined,
              size: 45,
            ),
            onPressed: () {
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => VerificationWidget()));
            },
            backgroundColor: Theme.of(context).accentColor,
          ),
        ),
      ),
      body: SafeArea(
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image(
              image: AssetImage("assets/img/background.png"),
              fit: BoxFit.fill,
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 10,
                ),
                Align(
                  alignment: Alignment.topLeft,
                  child: IconButton(
                    icon: Icon(
                      Icons.arrow_back_ios_outlined,
                    ),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                ),
                SizedBox(
                  height: 60,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 25),
                  child: Text("Enter your mobile number",
                      textAlign: TextAlign.start,
                      style: TextStyle(
                        color: Color(0xFF191E2F),
                        fontSize: 26,
                        fontFamily: 'Rubik',
                        fontWeight: FontWeight.w500,
                      )),
                ),
                SizedBox(
                  height: 40,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 25),
                  child: Text("Mobile Number",
                      textAlign: TextAlign.start,
                      style: TextStyle(
                        color: Color(0xFF8E93A7),
                        fontSize: 16,
                        fontFamily: 'Rubik',
                        fontWeight: FontWeight.w400,
                      )),
                ),
                SizedBox(
                  height: 15,
                ),
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Container(
                        height: 50,
                        width: MediaQuery.of(context).size.width - 40,
                        decoration: new BoxDecoration(color: Color(0xFFE2E2E2)),
                        child: Padding(
                          padding: const EdgeInsets.only(bottom: 1),
                          child: Container(
                            decoration:
                                new BoxDecoration(color: Color(0xFFFCFBFC)),
                            child: Row(
                              children: <Widget>[
                                Expanded(
                                   flex: 5,
                                  child: CountryCodePicker(
                                    flagWidth: 30,
                                    onChanged: print,
                                    // Initial selection and favorite can be one of code ('IT') OR dial_code('+39')
                                    initialSelection: 'In',
                                    favorite: ['+91', 'IN'],
                                    // optional. Shows only country name and flag
                                    showCountryOnly: true,
                                    // optional. Shows only country name and flag when popup is closed.
                                    showOnlyCountryWhenClosed: false,
                                    // optional. aligns the flag and the Text left
                                    alignLeft: true,
                                  ),
                                ),
                                Expanded(
flex: 14,
                                  child: TextField(
                                    keyboardType: TextInputType.phone,
                                    decoration: InputDecoration(
                                        border: InputBorder.none),
                                    onChanged: (value) {
                                      // this.phoneNo=value;
                                      print(value);
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
