import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebasereg/models/note.dart';
import 'package:firebasereg/models/user.dart';
import 'package:http/http.dart' as http;
import 'package:meta/meta.dart';

class FirebaseApiClient {
  final http.Client httpClient;
  CollectionReference users = FirebaseFirestore.instance.collection('users');

  FirebaseApiClient({
    @required this.httpClient,
  }) : assert(httpClient != null);

  Future<User> fetchRegister(String email, String password,
      String confirmPassword, String phno) async {
    print("IN REGISTRATION");
    var res =
        await users.add({"email": email, "password": password, "phone": phno});
    var data = await res.get();
    print(res.toString());
    print(data.data().toString());
    // final json = jsonDecode();
    return User(
        email: email,
        password: password,
        phno: phno,
        confirmPassword: password);
  }

  Future<User> fetchLogin(String email, String password) async {
    print("IN fetchLogin");
    var res = await users
        .where("email", isEqualTo: email)
        .where("password", isEqualTo: password)
        .get();
    print("data count::${res.docs.length}");
    var data = res.docs[0];
    print(data.data());
    // final json = jsonDecode();
    return User.fromJson(data.data());
  }

  Future<Note> fetchAddData(
      String email, String title, String detail, String picture) async {
    print("IN REGISTRATION");
    var res = await users.add(
        {"email": email, "title": title, "detail": detail, "picture": picture});
    var data = await res.get();
    print(res.toString());
    print(data.data().toString());
    return Note(email: email, title: title, detail: detail, picture: picture);
  }
}
