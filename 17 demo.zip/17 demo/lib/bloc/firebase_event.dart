import 'package:equatable/equatable.dart';

abstract class FirebaseEvent extends Equatable {
  const FirebaseEvent();
}

//Register
class FetchRegister extends FirebaseEvent {
  final email;
  final password;
  final confirmPassword;
  final phNo;

  const FetchRegister(
      this.email, this.password, this.confirmPassword, this.phNo);

  @override
  List<Object> get props => [];
}

//Login
class FetchLogin extends FirebaseEvent {
  final email;
  final password;

  const FetchLogin(this.email, this.password);

  @override
  List<Object> get props => [];
}

//Add Data
class fetchAddData extends FirebaseEvent {
  final email;
  final title;
  final detail;
  final picture;

  const fetchAddData(
      this.email, this.title, this.detail, this.picture);

  @override
  List<Object> get props => [];
}
