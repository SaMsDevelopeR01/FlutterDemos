import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'AddData.dart';
import 'bloc/firebase_bloc.dart';

class HomePage extends StatelessWidget {
  final email;

  const HomePage({Key key, this.email}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Home"),
      ),
      body: NoteList(email: email,),
    );
  }
}

class NoteList extends StatefulWidget {
  final email;

  const NoteList({Key key, this.email}) : super(key: key);
  @override
  _NoteListState createState() => _NoteListState(email);
}

class _NoteListState extends State<NoteList> {
  final email;

  _NoteListState(this.email);
  @override
  Widget build(BuildContext mainContext) {
    return Scaffold(
      body: Container(),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(mainContext).push(MaterialPageRoute(
              builder: (_) => BlocProvider.value(
                  value: BlocProvider.of<FirebaseBloc>(mainContext),
                  child: AddData(email: email,))));
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
