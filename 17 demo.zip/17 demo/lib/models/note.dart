class Note {
  int id;
  String email;
  String title;
  String detail;
  String picture;

  Note({this.id, this.email, this.title, this.detail, this.picture});

  factory Note.fromJson(Map<String, dynamic> json) => new Note(
        id: json["id"],
        email: json["email"],
        title: json["title"],
        detail: json["detail"],
        picture: json["picture"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "email": email,
        "title": title,
        "detail": detail,
        "picture": picture,
      };
}
