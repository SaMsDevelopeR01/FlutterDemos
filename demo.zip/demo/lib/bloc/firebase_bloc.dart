import 'package:firebasereg/bloc/firebase_event.dart';
import 'package:firebasereg/bloc/firebase_state.dart';
import 'package:firebasereg/models/user.dart';
import 'package:firebasereg/repository/firebase_repository.dart';
import 'package:meta/meta.dart';
import 'package:bloc/bloc.dart';


class FirebaseBloc extends Bloc<FirebaseEvent, FirebaseState> {
  final FirebaseRepository repository;

  FirebaseBloc({@required this.repository})
      : assert(repository != null),
        super(LoginEmpty());

  @override
  FirebaseState get initialState => LoginEmpty();

  @override
  Stream<FirebaseState> mapEventToState(FirebaseEvent event) async* {

    if (event is FetchRegister) {
      yield RegisterLoading();
      try {
       // final List<User> Register = (await repository.fetchRegister(event.email,event.password,event.confirmPassword,event.phNo));
        //yield RegisterLoaded(Register: Register);
      } catch (e) {
        print(e);
        yield RegisterError();
      }
    }
    if (event is FetchLogin) {
      yield LoginLoading();
      try {
        //final List<User> Login = (await repository.fetchLogin(event.email,event.password));
        //yield LoginLoaded(Login: Login);
      } catch (e) {
        print(e);
        yield LoginError();
      }
    }
  }
}
