import 'package:firebasereg/models/user.dart';
import 'package:meta/meta.dart';
import 'package:equatable/equatable.dart';

abstract class FirebaseState extends Equatable {
  const FirebaseState();

  @override
  List<Object> get props => [];
}

/*
***Register State***
 */

class RegisterEmpty extends FirebaseState {}

class RegisterLoading extends FirebaseState {}

class RegisterLoaded extends FirebaseState {
  final List<User> Register;

  const RegisterLoaded({@required this.Register}) : assert(Register != null);

  @override
  List<Object> get props => [];
}

class RegisterError extends FirebaseState {}
/*
***Login State***
 */

class LoginEmpty extends FirebaseState {}

class LoginLoading extends FirebaseState {}

class LoginLoaded extends FirebaseState {
  final List<User> Login;

  const LoginLoaded({@required this.Login}) : assert(Login != null);

  @override
  List<Object> get props => [];
}

class LoginError extends FirebaseState {}
