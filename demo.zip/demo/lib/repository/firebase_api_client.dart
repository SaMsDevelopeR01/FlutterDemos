import 'dart:convert';
import 'package:firebasereg/models/user.dart';
import 'package:http/http.dart' as http;
import 'package:meta/meta.dart';

class FirebaseApiClient {
  final http.Client httpClient;

  FirebaseApiClient({
    @required this.httpClient,
  }) : assert(httpClient != null);

  Future<User> fetchRegister(String email, String password,
      String confirmPassword, String phno) async {
    // final url = 'https://api.coingecko.com/api/v3/coins/markets?vs_currency=eth&order=market_cap_desc&per_page=100&page=1&sparkline=false';
    //  final response = await this.httpClient.get(url);
    //
    //  if (response.statusCode != 200) {
    //    throw new Exception('error getting data');
    //  }
    //  final json = jsonDecode(response.body);
    //  return User.fromJson(json);
  }

  Future<User> fetchLogin(String email, String password) async {
    //print("${paramCoin} and ${paramDuration}");
    //final url = "https://api.coingecko.com/api/v3/coins/bitcoin/market_chart?vs_currency=" + paramCoin + "&days=" + paramDuration + "";
    // final response = await this.httpClient.get(url);
    //
    // if (response.statusCode != 200) {
    //   throw new Exception('error getting data');
    // }
    // final json = jsonDecode(response.body);
    // return User.fromJson(json);
  }
}
