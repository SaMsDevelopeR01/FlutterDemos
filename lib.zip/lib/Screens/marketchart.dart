import 'dart:math';
import 'package:cryptocoin/bloc/crypto_bloc.dart';
import 'package:cryptocoin/bloc/crypto_event.dart';
import 'package:cryptocoin/bloc/crypto_state.dart';
import 'package:cryptocoin/models/crypto_chart_data.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fl_chart/fl_chart.dart';

class ChartPage extends StatefulWidget {
  final id;

  const ChartPage({Key key, this.id}) : super(key: key);
  @override
  _ChartPageState createState() => _ChartPageState(id);
}

class _ChartPageState extends State<ChartPage> {
  final id;
  String duration='1';
  List<Color> gradientColors = [
    const Color(0xff23b6e6),
    const Color(0xff02d39a),
  ];

  bool showAvg = false;

  _ChartPageState(this.id);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Market Chart'),
      ),
      body: BlocBuilder<CryptoBloc, CryptoState>(builder: (context, state) {
        print(state);
        print(state);
        if (state == null || state is CryptoEmpty ) {
          BlocProvider.of<CryptoBloc>(context).add(FetchCryptoChart(id,duration));
        }
        if (state is ChartEmpty) {
          BlocProvider.of<CryptoBloc>(context).add(FetchCryptoChart(id,duration));
        }
        if (state is ChartError) {
          return Center(
            child: Text('No chart data found'),
          );
        }
        if (state is ChartLoaded) {
          var cryptoChart = state.cryptoChart;
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 30),
                child: AspectRatio(
                  aspectRatio: 2 / 1,
                  child: Container(
                    child: LineChart(
                      mainData(cryptoChart),
                    ),
                  ),
                ),
              ),
              Divider(
                height: 5.0,
                color: Colors.grey[200],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  FlatButton(
                      onPressed: (){
                        duration= '1';
                        BlocProvider.of<CryptoBloc>(context).add(FetchCryptoChart(id,duration));
                      },
                      color: Colors.blue,
                      textColor: Colors.white,
                      disabledColor: Colors.blue[50],
                      disabledTextColor: Colors.blue,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5.0)),
                      child: Text("24H")
                  ),
                  FlatButton(
                      onPressed: (){
                        duration ='7';
                        BlocProvider.of<CryptoBloc>(context).add(FetchCryptoChart(id,duration));
                      },
                      color: Colors.lightBlue,
                      textColor: Colors.white,
                      disabledColor: Colors.blue[50],
                      disabledTextColor: Colors.blue,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5.0)),
                      child: Text("Week")
                  ),
                  FlatButton(onPressed: (){
                    duration = '30';
                    BlocProvider.of<CryptoBloc>(context).add(FetchCryptoChart(id,duration));
                  },
                      color: Colors.lightBlue,
                      textColor: Colors.white,
                      disabledColor: Colors.blue[50],
                      disabledTextColor: Colors.blue,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5.0)),
                      child: Text("Month")
                  ),
                ],
              ),
              Divider(
                height: 5.0,
                color: Colors.grey[200],
              ),
            ],
          );
        }
        return Center(
          child: CircularProgressIndicator(),
        );
      }),
    );
  }

  LineChartData mainData(CryptoChart cryptoChart) {
    var data = cryptoChart.prices;

    print([
      "cryptoChart.prices",
      data.map((obj) => FlSpot(obj[0].toDouble(), obj[1].toDouble()))
    ]);

    var barData = data
        .asMap()
        .map((inx, obj) =>
            MapEntry(inx, FlSpot(inx.toDouble(), obj[1].toDouble())))
        .values
        .toList();

    var maxX = barData.map<int>((e) => e.x.toInt()).reduce(max);
    var maxY = barData.map<int>((e) => e.y.toInt()).reduce(max);
    print(["barData", barData.map((obj) => obj.x)]);

    return LineChartData(
      gridData: FlGridData(
        show: false,
        drawVerticalLine: true,
        getDrawingHorizontalLine: (value) {
          return FlLine(
            color: const Color(0xff37434d),
            strokeWidth: 1,
          );
        },
        getDrawingVerticalLine: (value) {
          return FlLine(
            color: const Color(0xff37434d),
            strokeWidth: 1,
          );
        },
      ),
      titlesData: FlTitlesData(
        show: false,
      ),
      borderData: FlBorderData(
          show: true,
          border: Border.all(color: const Color(0xff37434d), width: 0)),
      minX: 0,
      maxX: maxX.toDouble(),
      minY: 0,
      maxY: maxY.toDouble(),
      lineBarsData: [
        LineChartBarData(
          spots: barData,
          isCurved: true,
          colors: gradientColors,
          barWidth: 1,
          isStrokeCapRound: true,
          dotData: FlDotData(
            show: false,
          ),
          belowBarData: BarAreaData(
            show: true,
            colors:
                gradientColors.map((color) => color.withOpacity(0.3)).toList(),
          ),
        ),
      ],
    );
  }
}
