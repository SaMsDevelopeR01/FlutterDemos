import 'package:cryptocoin/bloc/crypto_bloc.dart';
import 'package:cryptocoin/bloc/crypto_event.dart';
import 'package:cryptocoin/bloc/crypto_state.dart';
import 'package:cryptocoin/repository/crypto_repository.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'marketchart.dart';

class ListPrice extends StatelessWidget {
  final repository;

  const ListPrice({Key key, this.repository}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Crypto Price List'),
      ),
      body: BlocBuilder<CryptoBloc, CryptoState>(builder: (context, state) {
        if (state is CryptoEmpty || state is ChartLoaded) {
          BlocProvider.of<CryptoBloc>(context).add(FetchCryptoList());
        }
        if (state is CryptoError) {
          return Center(
            child: Text('Failed to Fetch Data'),
          );
        }
        if (state is CryptoLoaded) {
          var arraySymbol = ["btc", "eth", "xtz", "trx", "atom", "algo"];
          var priceLits = state.cryptoList;
          priceLits = priceLits
              .where((obj) => arraySymbol.contains(obj.symbol))
              .toList();
          return ListView.builder(
              itemCount: priceLits.length == null
                  ? Center(
                      child: CircularProgressIndicator(),
                    )
                  : priceLits.length,
              itemBuilder: (BuildContext context, int index) {
                return _getListItemUI(
                    context,
                    priceLits[index].id,
                    priceLits[index].image,
                    priceLits[index].name,
                    priceLits[index].currentPrice,
                    priceLits[index].marketCapChangePercentage24h,
                    priceLits[index].symbol);
              });
        }
        return Center(
          child: CircularProgressIndicator(),
        );
      }),
    );
  }

  Widget _getListItemUI(BuildContext context, String id, String image,
      String name, String price, String percentageChange, String symbol) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(0.0),
          child: GestureDetector(
            onTap: () {
              print(symbol);
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => BlocProvider.value(
                      value:BlocProvider.of<CryptoBloc>(context),
                      child: ChartPage(
                        id: symbol,))));
            },
            child: ListTile(
              leading: CircleAvatar(
                child: Image.network(image),
              ),
              title: Text(name),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 12.0),
                child: _getSubTitle(price, percentageChange),
              ),
              trailing: Padding(
                padding: const EdgeInsets.only(right: 10.0),
                child: Text(symbol.toUpperCase()),
              ),
            ),
          ),
        ),
        Divider(
          color: Colors.grey[200],
          height: 5.0,
        ),
      ],
    );
  }

  Widget _getSubTitle(String price, String percentageChage) {
    TextSpan priceTextWidget = TextSpan(
        text: "\$${(double.parse(price)).toStringAsFixed(4)}\t",
        style: TextStyle(color: Colors.grey[700], fontSize: 13.0));
    String percentageChangetext =
        " ${(double.parse(percentageChage)).toStringAsFixed(2)}%";
    TextSpan percentageChangeTextWidget;
    if (double.parse(percentageChage) > 0) {
      percentageChangeTextWidget = TextSpan(
          text: percentageChangetext,
          style: TextStyle(color: Colors.teal[700], fontSize: 12.0));
    } else {
      percentageChangeTextWidget = TextSpan(
          text: percentageChangetext,
          style: TextStyle(color: Colors.red[800], fontSize: 12.0));
    }
    return RichText(
        text:
            TextSpan(children: [priceTextWidget, percentageChangeTextWidget]));
  }
}
