import 'package:cryptocoin/bloc/crypto_bloc.dart';
import 'package:cryptocoin/bloc/crypto_event.dart';
import 'package:cryptocoin/bloc/crypto_state.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class ListExchangePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Exchange List'),
      ),
        body: BlocBuilder<CryptoBloc, CryptoState>(builder: (context, state) {
      if (state == null || state is CryptoEmpty) {
        BlocProvider.of<CryptoBloc>(context).add(FetchCryptoExchageList());
      }
      if (state is ExchangeListEmpty) {
        BlocProvider.of<CryptoBloc>(context).add(FetchCryptoExchageList());
      }
      if (state is ExchangeListError) {
        return Center(
          child: Text('Failed to Fetch Data'),
        );
      }
      if (state is ExchangeListLoaded) {
        return ListView.builder(
            itemCount: state.cryptoExchangeList.length,
            itemBuilder: (BuildContext context, int index) {
              return _getListItemUI(
                  state.cryptoExchangeList[index].image,
                  state.cryptoExchangeList[index].name,
                  state.cryptoExchangeList[index].country,
                  state.cryptoExchangeList[index].yearEstablished,
                  state.cryptoExchangeList[index].trustScoreRank);
            });
      }
      return Center(
        child: CircularProgressIndicator(),
      );
    }));
  }

  Widget _getListItemUI(
      String image, String name, String country, int year, int rank) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 3),
          child: ListTile(
              leading: CircleAvatar(
                child: Image.network(image),
              ),
              title: Text("$name"),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 4.0),
                child: RichText(
                    text: TextSpan(children: [
                  TextSpan(
                      text: "$country\n",
                      style: TextStyle(color: Colors.grey[700])),
                  TextSpan(
                      text: "$year\n",
                      style: TextStyle(color: Colors.grey, height: 1.6)),
                ])),
              ),
              // isThreeLine: true,
              trailing: Padding(
                padding: const EdgeInsets.only(right: 10.0),
                child: RichText(
                    textAlign: TextAlign.center,
                    text: TextSpan(children: [
                      TextSpan(
                          text: "Rank\n",
                          style: TextStyle(color: Colors.black87)),
                      TextSpan(
                          text: "$rank\n",
                          style: TextStyle(
                            color: Colors.grey[700],
                          )),
                    ])),
              )),
        ),
        Divider(
          height: 5.0,
          color: Colors.grey[200],
        ),
      ],
    );
  }
}
