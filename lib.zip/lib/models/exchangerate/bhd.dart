import 'package:equatable/equatable.dart';

class Bhd extends Equatable {
	final String name;
	final String unit;
	final double value;
	final String type;

	const Bhd({
		this.name,
		this.unit,
		this.value,
		this.type,
	});

	@override
	String toString() {
		return 'Bhd(name: $name, unit: $unit, value: $value, type: $type)';
	}

	factory Bhd.fromJson(Map<String, dynamic> json) {
		return Bhd(
			name: json['name'] as String,
			unit: json['unit'] as String,
			value: json['value'] as double,
			type: json['type'] as String,
		);
	}

	Map<String, dynamic> toJson() {
		return {
			'name': name,
			'unit': unit,
			'value': value,
			'type': type,
		};
	}

	Bhd copyWith({
		String name,
		String unit,
		double value,
		String type,
	}) {
		return Bhd(
			name: name ?? this.name,
			unit: unit ?? this.unit,
			value: value ?? this.value,
			type: type ?? this.type,
		);
	}

	@override
	List<Object> get props => [name, unit, value, type];
}
