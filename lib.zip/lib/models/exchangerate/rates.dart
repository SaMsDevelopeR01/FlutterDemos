import 'package:equatable/equatable.dart';

import "aed.dart";
import "ars.dart";
import "aud.dart";
import "bch.dart";
import "bdt.dart";
import "bhd.dart";
import "bits.dart";
import "bmd.dart";
import "bnb.dart";
import "brl.dart";
import "btc.dart";
import "cad.dart";
import "chf.dart";
import "clp.dart";
import "cny.dart";
import "czk.dart";
import "dkk.dart";
import "dot.dart";
import "eos.dart";
import "eth.dart";
import "eur.dart";
import "gbp.dart";
import "hkd.dart";
import "huf.dart";
import "idr.dart";
import "ils.dart";
import "inr.dart";
import "jpy.dart";
import "krw.dart";
import "kwd.dart";
import "link.dart";
import "lkr.dart";
import "ltc.dart";
import "mmk.dart";
import "mxn.dart";
import "myr.dart";
import "ngn.dart";
import "nok.dart";
import "nzd.dart";
import "php.dart";
import "pkr.dart";
import "pln.dart";
import "rub.dart";
import "sar.dart";
import "sats.dart";
import "sek.dart";
import "sgd.dart";
import "thb.dart";
import "try.dart";
import "twd.dart";
import "uah.dart";
import "usd.dart";
import "vef.dart";
import "vnd.dart";
import "xag.dart";
import "xau.dart";
import "xdr.dart";
import "xlm.dart";
import "xrp.dart";
import "yfi.dart";
import "zar.dart";

class Rates extends Equatable {
  final Btc btc;
  final Eth eth;
  final Ltc ltc;
  final Bch bch;
  final Bnb bnb;
  final Eos eos;
  final Xrp xrp;
  final Xlm xlm;
  final Link link;
  final Dot dot;
  final Yfi yfi;
  final Usd usd;
  final Aed aed;
  final Ars ars;
  final Aud aud;
  final Bdt bdt;
  final Bhd bhd;
  final Bmd bmd;
  final Brl brl;
  final Cad cad;
  final Chf chf;
  final Clp clp;
  final Cny cny;
  final Czk czk;
  final Dkk dkk;
  final Eur eur;
  final Gbp gbp;
  final Hkd hkd;
  final Huf huf;
  final Idr idr;
  final Ils ils;
  final Inr inr;
  final Jpy jpy;
  final Krw krw;
  final Kwd kwd;
  final Lkr lkr;
  final Mmk mmk;
  final Mxn mxn;
  final Myr myr;
  final Ngn ngn;
  final Nok nok;
  final Nzd nzd;
  final Php php;
  final Pkr pkr;
  final Pln pln;
  final Rub rub;
  final Sar sar;
  final Sek sek;
  final Sgd sgd;
  final Thb thb;
  final TryC tryC;
  final Twd twd;
  final Uah uah;
  final Vef vef;
  final Vnd vnd;
  final Zar zar;
  final Xdr xdr;
  final Xag xag;
  final Xau xau;
  final Bits bits;
  final Sats sats;

  const Rates({
    this.btc,
    this.eth,
    this.ltc,
    this.bch,
    this.bnb,
    this.eos,
    this.xrp,
    this.xlm,
    this.link,
    this.dot,
    this.yfi,
    this.usd,
    this.aed,
    this.ars,
    this.aud,
    this.bdt,
    this.bhd,
    this.bmd,
    this.brl,
    this.cad,
    this.chf,
    this.clp,
    this.cny,
    this.czk,
    this.dkk,
    this.eur,
    this.gbp,
    this.hkd,
    this.huf,
    this.idr,
    this.ils,
    this.inr,
    this.jpy,
    this.krw,
    this.kwd,
    this.lkr,
    this.mmk,
    this.mxn,
    this.myr,
    this.ngn,
    this.nok,
    this.nzd,
    this.php,
    this.pkr,
    this.pln,
    this.rub,
    this.sar,
    this.sek,
    this.sgd,
    this.thb,
    this.tryC,
    this.twd,
    this.uah,
    this.vef,
    this.vnd,
    this.zar,
    this.xdr,
    this.xag,
    this.xau,
    this.bits,
    this.sats,
  });

  @override
  String toString() {
    return 'Rates(btc: $btc, eth: $eth, ltc: $ltc, bch: $bch, bnb: $bnb, eos: $eos, xrp: $xrp, xlm: $xlm, link: $link, dot: $dot, yfi: $yfi, usd: $usd, aed: $aed, ars: $ars, aud: $aud, bdt: $bdt, bhd: $bhd, bmd: $bmd, brl: $brl, cad: $cad, chf: $chf, clp: $clp, cny: $cny, czk: $czk, dkk: $dkk, eur: $eur, gbp: $gbp, hkd: $hkd, huf: $huf, idr: $idr, ils: $ils, inr: $inr, jpy: $jpy, krw: $krw, kwd: $kwd, lkr: $lkr, mmk: $mmk, mxn: $mxn, myr: $myr, ngn: $ngn, nok: $nok, nzd: $nzd, php: $php, pkr: $pkr, pln: $pln, rub: $rub, sar: $sar, sek: $sek, sgd: $sgd, thb: $thb, tryC: $tryC, twd: $twd, uah: $uah, vef: $vef, vnd: $vnd, zar: $zar, xdr: $xdr, xag: $xag, xau: $xau, bits: $bits, sats: $sats)';
  }

  factory Rates.fromJson(Map<String, dynamic> json) {
    return Rates(
      btc: json['btc'] == null
          ? null
          : Btc.fromJson(json['btc'] as Map<String, dynamic>),
      eth: json['eth'] == null
          ? null
          : Eth.fromJson(json['eth'] as Map<String, dynamic>),
      ltc: json['ltc'] == null
          ? null
          : Ltc.fromJson(json['ltc'] as Map<String, dynamic>),
      bch: json['bch'] == null
          ? null
          : Bch.fromJson(json['bch'] as Map<String, dynamic>),
      bnb: json['bnb'] == null
          ? null
          : Bnb.fromJson(json['bnb'] as Map<String, dynamic>),
      eos: json['eos'] == null
          ? null
          : Eos.fromJson(json['eos'] as Map<String, dynamic>),
      xrp: json['xrp'] == null
          ? null
          : Xrp.fromJson(json['xrp'] as Map<String, dynamic>),
      xlm: json['xlm'] == null
          ? null
          : Xlm.fromJson(json['xlm'] as Map<String, dynamic>),
      link: json['link'] == null
          ? null
          : Link.fromJson(json['link'] as Map<String, dynamic>),
      dot: json['dot'] == null
          ? null
          : Dot.fromJson(json['dot'] as Map<String, dynamic>),
      yfi: json['yfi'] == null
          ? null
          : Yfi.fromJson(json['yfi'] as Map<String, dynamic>),
      usd: json['usd'] == null
          ? null
          : Usd.fromJson(json['usd'] as Map<String, dynamic>),
      aed: json['aed'] == null
          ? null
          : Aed.fromJson(json['aed'] as Map<String, dynamic>),
      ars: json['ars'] == null
          ? null
          : Ars.fromJson(json['ars'] as Map<String, dynamic>),
      aud: json['aud'] == null
          ? null
          : Aud.fromJson(json['aud'] as Map<String, dynamic>),
      bdt: json['bdt'] == null
          ? null
          : Bdt.fromJson(json['bdt'] as Map<String, dynamic>),
      bhd: json['bhd'] == null
          ? null
          : Bhd.fromJson(json['bhd'] as Map<String, dynamic>),
      bmd: json['bmd'] == null
          ? null
          : Bmd.fromJson(json['bmd'] as Map<String, dynamic>),
      brl: json['brl'] == null
          ? null
          : Brl.fromJson(json['brl'] as Map<String, dynamic>),
      cad: json['cad'] == null
          ? null
          : Cad.fromJson(json['cad'] as Map<String, dynamic>),
      chf: json['chf'] == null
          ? null
          : Chf.fromJson(json['chf'] as Map<String, dynamic>),
      clp: json['clp'] == null
          ? null
          : Clp.fromJson(json['clp'] as Map<String, dynamic>),
      cny: json['cny'] == null
          ? null
          : Cny.fromJson(json['cny'] as Map<String, dynamic>),
      czk: json['czk'] == null
          ? null
          : Czk.fromJson(json['czk'] as Map<String, dynamic>),
      dkk: json['dkk'] == null
          ? null
          : Dkk.fromJson(json['dkk'] as Map<String, dynamic>),
      eur: json['eur'] == null
          ? null
          : Eur.fromJson(json['eur'] as Map<String, dynamic>),
      gbp: json['gbp'] == null
          ? null
          : Gbp.fromJson(json['gbp'] as Map<String, dynamic>),
      hkd: json['hkd'] == null
          ? null
          : Hkd.fromJson(json['hkd'] as Map<String, dynamic>),
      huf: json['huf'] == null
          ? null
          : Huf.fromJson(json['huf'] as Map<String, dynamic>),
      idr: json['idr'] == null
          ? null
          : Idr.fromJson(json['idr'] as Map<String, dynamic>),
      ils: json['ils'] == null
          ? null
          : Ils.fromJson(json['ils'] as Map<String, dynamic>),
      inr: json['inr'] == null
          ? null
          : Inr.fromJson(json['inr'] as Map<String, dynamic>),
      jpy: json['jpy'] == null
          ? null
          : Jpy.fromJson(json['jpy'] as Map<String, dynamic>),
      krw: json['krw'] == null
          ? null
          : Krw.fromJson(json['krw'] as Map<String, dynamic>),
      kwd: json['kwd'] == null
          ? null
          : Kwd.fromJson(json['kwd'] as Map<String, dynamic>),
      lkr: json['lkr'] == null
          ? null
          : Lkr.fromJson(json['lkr'] as Map<String, dynamic>),
      mmk: json['mmk'] == null
          ? null
          : Mmk.fromJson(json['mmk'] as Map<String, dynamic>),
      mxn: json['mxn'] == null
          ? null
          : Mxn.fromJson(json['mxn'] as Map<String, dynamic>),
      myr: json['myr'] == null
          ? null
          : Myr.fromJson(json['myr'] as Map<String, dynamic>),
      ngn: json['ngn'] == null
          ? null
          : Ngn.fromJson(json['ngn'] as Map<String, dynamic>),
      nok: json['nok'] == null
          ? null
          : Nok.fromJson(json['nok'] as Map<String, dynamic>),
      nzd: json['nzd'] == null
          ? null
          : Nzd.fromJson(json['nzd'] as Map<String, dynamic>),
      php: json['php'] == null
          ? null
          : Php.fromJson(json['php'] as Map<String, dynamic>),
      pkr: json['pkr'] == null
          ? null
          : Pkr.fromJson(json['pkr'] as Map<String, dynamic>),
      pln: json['pln'] == null
          ? null
          : Pln.fromJson(json['pln'] as Map<String, dynamic>),
      rub: json['rub'] == null
          ? null
          : Rub.fromJson(json['rub'] as Map<String, dynamic>),
      sar: json['sar'] == null
          ? null
          : Sar.fromJson(json['sar'] as Map<String, dynamic>),
      sek: json['sek'] == null
          ? null
          : Sek.fromJson(json['sek'] as Map<String, dynamic>),
      sgd: json['sgd'] == null
          ? null
          : Sgd.fromJson(json['sgd'] as Map<String, dynamic>),
      thb: json['thb'] == null
          ? null
          : Thb.fromJson(json['thb'] as Map<String, dynamic>),
      tryC: json['tryC'] == null
          ? null
          : TryC.fromJson(json['tryC'] as Map<String, dynamic>),
      twd: json['twd'] == null
          ? null
          : Twd.fromJson(json['twd'] as Map<String, dynamic>),
      uah: json['uah'] == null
          ? null
          : Uah.fromJson(json['uah'] as Map<String, dynamic>),
      vef: json['vef'] == null
          ? null
          : Vef.fromJson(json['vef'] as Map<String, dynamic>),
      vnd: json['vnd'] == null
          ? null
          : Vnd.fromJson(json['vnd'] as Map<String, dynamic>),
      zar: json['zar'] == null
          ? null
          : Zar.fromJson(json['zar'] as Map<String, dynamic>),
      xdr: json['xdr'] == null
          ? null
          : Xdr.fromJson(json['xdr'] as Map<String, dynamic>),
      xag: json['xag'] == null
          ? null
          : Xag.fromJson(json['xag'] as Map<String, dynamic>),
      xau: json['xau'] == null
          ? null
          : Xau.fromJson(json['xau'] as Map<String, dynamic>),
      bits: json['bits'] == null
          ? null
          : Bits.fromJson(json['bits'] as Map<String, dynamic>),
      sats: json['sats'] == null
          ? null
          : Sats.fromJson(json['sats'] as Map<String, dynamic>),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'btc': btc?.toJson(),
      'eth': eth?.toJson(),
      'ltc': ltc?.toJson(),
      'bch': bch?.toJson(),
      'bnb': bnb?.toJson(),
      'eos': eos?.toJson(),
      'xrp': xrp?.toJson(),
      'xlm': xlm?.toJson(),
      'link': link?.toJson(),
      'dot': dot?.toJson(),
      'yfi': yfi?.toJson(),
      'usd': usd?.toJson(),
      'aed': aed?.toJson(),
      'ars': ars?.toJson(),
      'aud': aud?.toJson(),
      'bdt': bdt?.toJson(),
      'bhd': bhd?.toJson(),
      'bmd': bmd?.toJson(),
      'brl': brl?.toJson(),
      'cad': cad?.toJson(),
      'chf': chf?.toJson(),
      'clp': clp?.toJson(),
      'cny': cny?.toJson(),
      'czk': czk?.toJson(),
      'dkk': dkk?.toJson(),
      'eur': eur?.toJson(),
      'gbp': gbp?.toJson(),
      'hkd': hkd?.toJson(),
      'huf': huf?.toJson(),
      'idr': idr?.toJson(),
      'ils': ils?.toJson(),
      'inr': inr?.toJson(),
      'jpy': jpy?.toJson(),
      'krw': krw?.toJson(),
      'kwd': kwd?.toJson(),
      'lkr': lkr?.toJson(),
      'mmk': mmk?.toJson(),
      'mxn': mxn?.toJson(),
      'myr': myr?.toJson(),
      'ngn': ngn?.toJson(),
      'nok': nok?.toJson(),
      'nzd': nzd?.toJson(),
      'php': php?.toJson(),
      'pkr': pkr?.toJson(),
      'pln': pln?.toJson(),
      'rub': rub?.toJson(),
      'sar': sar?.toJson(),
      'sek': sek?.toJson(),
      'sgd': sgd?.toJson(),
      'thb': thb?.toJson(),
      'tryC': tryC?.toJson(),
      'twd': twd?.toJson(),
      'uah': uah?.toJson(),
      'vef': vef?.toJson(),
      'vnd': vnd?.toJson(),
      'zar': zar?.toJson(),
      'xdr': xdr?.toJson(),
      'xag': xag?.toJson(),
      'xau': xau?.toJson(),
      'bits': bits?.toJson(),
      'sats': sats?.toJson(),
    };
  }

  Rates copyWith({
    Btc btc,
    Eth eth,
    Ltc ltc,
    Bch bch,
    Bnb bnb,
    Eos eos,
    Xrp xrp,
    Xlm xlm,
    Link link,
    Dot dot,
    Yfi yfi,
    Usd usd,
    Aed aed,
    Ars ars,
    Aud aud,
    Bdt bdt,
    Bhd bhd,
    Bmd bmd,
    Brl brl,
    Cad cad,
    Chf chf,
    Clp clp,
    Cny cny,
    Czk czk,
    Dkk dkk,
    Eur eur,
    Gbp gbp,
    Hkd hkd,
    Huf huf,
    Idr idr,
    Ils ils,
    Inr inr,
    Jpy jpy,
    Krw krw,
    Kwd kwd,
    Lkr lkr,
    Mmk mmk,
    Mxn mxn,
    Myr myr,
    Ngn ngn,
    Nok nok,
    Nzd nzd,
    Php php,
    Pkr pkr,
    Pln pln,
    Rub rub,
    Sar sar,
    Sek sek,
    Sgd sgd,
    Thb thb,
    TryC tryC,
    Twd twd,
    Uah uah,
    Vef vef,
    Vnd vnd,
    Zar zar,
    Xdr xdr,
    Xag xag,
    Xau xau,
    Bits bits,
    Sats sats,
  }) {
    return Rates(
      btc: btc ?? this.btc,
      eth: eth ?? this.eth,
      ltc: ltc ?? this.ltc,
      bch: bch ?? this.bch,
      bnb: bnb ?? this.bnb,
      eos: eos ?? this.eos,
      xrp: xrp ?? this.xrp,
      xlm: xlm ?? this.xlm,
      link: link ?? this.link,
      dot: dot ?? this.dot,
      yfi: yfi ?? this.yfi,
      usd: usd ?? this.usd,
      aed: aed ?? this.aed,
      ars: ars ?? this.ars,
      aud: aud ?? this.aud,
      bdt: bdt ?? this.bdt,
      bhd: bhd ?? this.bhd,
      bmd: bmd ?? this.bmd,
      brl: brl ?? this.brl,
      cad: cad ?? this.cad,
      chf: chf ?? this.chf,
      clp: clp ?? this.clp,
      cny: cny ?? this.cny,
      czk: czk ?? this.czk,
      dkk: dkk ?? this.dkk,
      eur: eur ?? this.eur,
      gbp: gbp ?? this.gbp,
      hkd: hkd ?? this.hkd,
      huf: huf ?? this.huf,
      idr: idr ?? this.idr,
      ils: ils ?? this.ils,
      inr: inr ?? this.inr,
      jpy: jpy ?? this.jpy,
      krw: krw ?? this.krw,
      kwd: kwd ?? this.kwd,
      lkr: lkr ?? this.lkr,
      mmk: mmk ?? this.mmk,
      mxn: mxn ?? this.mxn,
      myr: myr ?? this.myr,
      ngn: ngn ?? this.ngn,
      nok: nok ?? this.nok,
      nzd: nzd ?? this.nzd,
      php: php ?? this.php,
      pkr: pkr ?? this.pkr,
      pln: pln ?? this.pln,
      rub: rub ?? this.rub,
      sar: sar ?? this.sar,
      sek: sek ?? this.sek,
      sgd: sgd ?? this.sgd,
      thb: thb ?? this.thb,
      tryC: tryC ?? this.tryC,
      twd: twd ?? this.twd,
      uah: uah ?? this.uah,
      vef: vef ?? this.vef,
      vnd: vnd ?? this.vnd,
      zar: zar ?? this.zar,
      xdr: xdr ?? this.xdr,
      xag: xag ?? this.xag,
      xau: xau ?? this.xau,
      bits: bits ?? this.bits,
      sats: sats ?? this.sats,
    );
  }

  @override
  List<Object> get props {
    return [
      btc,
      eth,
      ltc,
      bch,
      bnb,
      eos,
      xrp,
      xlm,
      link,
      dot,
      yfi,
      usd,
      aed,
      ars,
      aud,
      bdt,
      bhd,
      bmd,
      brl,
      cad,
      chf,
      clp,
      cny,
      czk,
      dkk,
      eur,
      gbp,
      hkd,
      huf,
      idr,
      ils,
      inr,
      jpy,
      krw,
      kwd,
      lkr,
      mmk,
      mxn,
      myr,
      ngn,
      nok,
      nzd,
      php,
      pkr,
      pln,
      rub,
      sar,
      sek,
      sgd,
      thb,
      tryC,
      twd,
      uah,
      vef,
      vnd,
      zar,
      xdr,
      xag,
      xau,
      bits,
      sats,
    ];
  }
}
