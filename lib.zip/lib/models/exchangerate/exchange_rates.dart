import 'package:equatable/equatable.dart';

import "rates.dart";

class ExchangeRates extends Equatable {
	final Rates rates;

	const ExchangeRates({this.rates});

	@override
	String toString() => 'ExchangeRates(rates: $rates)';

	factory ExchangeRates.fromJson(Map<String, dynamic> json) {
		return ExchangeRates(
			rates: json['rates'] == null
					? null
					: Rates.fromJson(json['rates'] as Map<String, dynamic>),
		);
	}

	Map<String, dynamic> toJson() {
		return {
			'rates': rates?.toJson(),
		};
	}

	ExchangeRates copyWith({
		Rates rates,
	}) {
		return ExchangeRates(
			rates: rates ?? this.rates,
		);
	}

	List<dynamic> getArrayClasses(){
		var array = List<dynamic>();
		array.add((rates.btc));
		array.add((rates.eth));
		array.add((rates.ltc));
		array.add((rates.bch));
		array.add((rates.bnb));
		array.add((rates.eos));
		array.add((rates.xrp));
		array.add((rates.xlm));
		array.add((rates.link));
		array.add((rates.dot));
		array.add((rates.yfi));
		array.add((rates.usd));
		array.add((rates.aed));
		array.add((rates.ars));
		array.add((rates.aud));
		array.add((rates.bdt));
		array.add((rates.bhd));
		array.add((rates.bmd));
		array.add((rates.brl));
		array.add((rates.cad));
		array.add((rates.chf));
		array.add((rates.clp));
		array.add((rates.cny));
		array.add((rates.czk));
		array.add((rates.dkk));
		array.add((rates.eur));
		array.add((rates.gbp));
		array.add((rates.hkd));
		array.add((rates.huf));
		array.add((rates.idr));
		array.add((rates.ils));
		array.add((rates.inr));
		array.add((rates.jpy));
		array.add((rates.krw));
		array.add((rates.kwd));
		array.add((rates.lkr));
		array.add((rates.mmk));
		array.add((rates.mxn));
		array.add((rates.myr));
		array.add((rates.ngn));
		array.add((rates.nok));
		array.add((rates.nzd));
		array.add((rates.php));
		array.add((rates.pkr));
		array.add((rates.pln));
		array.add((rates.rub));
		array.add((rates.sar));
		array.add((rates.sek));
		array.add((rates.sgd));
		array.add((rates.thb));
		array.add((rates.tryC));
		array.add((rates.twd));
		array.add((rates.uah));
		array.add((rates.vef));
		array.add((rates.vnd));
		array.add((rates.zar));
		array.add((rates.xdr));
		array.add((rates.xag));
		array.add((rates.xau));
		array.add((rates.bits));
		array.add((rates.sats));
		return array;
	}

	@override
	List<Object> get props => [rates];
}
