/// coins : [{"item":{"id":"pancakeswap-token","name":"PancakeSwap","symbol":"CAKE","market_cap_rank":69,"thumb":"https://assets.coingecko.com/coins/images/12632/thumb/IMG_0440.PNG?1602654093","large":"https://assets.coingecko.com/coins/images/12632/large/IMG_0440.PNG?1602654093","score":0}},{"item":{"id":"unistake","name":"Unistake","symbol":"UNISTAKE","market_cap_rank":430,"thumb":"https://assets.coingecko.com/coins/images/12813/thumb/unistake.png?1612346684","large":"https://assets.coingecko.com/coins/images/12813/large/unistake.png?1612346684","score":1}},{"item":{"id":"1inch","name":"1inch","symbol":"1INCH","market_cap_rank":85,"thumb":"https://assets.coingecko.com/coins/images/13469/thumb/1inch-token.png?1608803028","large":"https://assets.coingecko.com/coins/images/13469/large/1inch-token.png?1608803028","score":2}},{"item":{"id":"matic-network","name":"Polygon","symbol":"MATIC","market_cap_rank":78,"thumb":"https://assets.coingecko.com/coins/images/4713/thumb/matic___polygon.jpg?1612939050","large":"https://assets.coingecko.com/coins/images/4713/large/matic___polygon.jpg?1612939050","score":3}},{"item":{"id":"binancecoin","name":"Binance Coin","symbol":"BNB","market_cap_rank":7,"thumb":"https://assets.coingecko.com/coins/images/825/thumb/binance-coin-logo.png?1547034615","large":"https://assets.coingecko.com/coins/images/825/large/binance-coin-logo.png?1547034615","score":4}},{"item":{"id":"decentr","name":"Decentr","symbol":"DEC","market_cap_rank":400,"thumb":"https://assets.coingecko.com/coins/images/11816/thumb/Decentr.png?1594637985","large":"https://assets.coingecko.com/coins/images/11816/large/Decentr.png?1594637985","score":5}},{"item":{"id":"safepal","name":"SafePal","symbol":"SFP","market_cap_rank":113,"thumb":"https://assets.coingecko.com/coins/images/13905/thumb/z_u91wou_400x400.jpg?1612798329","large":"https://assets.coingecko.com/coins/images/13905/large/z_u91wou_400x400.jpg?1612798329","score":6}}]
/// exchanges : []

class CryptoTrendigs {
  List<Coins> _coins;

  //List<dynamic> _exchanges;

  List<Coins> get coins => _coins;

  //List<dynamic> get exchanges => _exchanges;

  CryptoTrendigs({List<Coins> coins, List<dynamic> exchanges}) {
    _coins = coins;
    // _exchanges = exchanges;
  }

  CryptoTrendigs.fromJson(dynamic json) {
    if (json["coins"] != null) {
      _coins = [];
      json["coins"].forEach((v) {
        _coins.add(Coins.fromJson(v));
      });
    }
    // if (json["exchanges"] != null) {
    //   _exchanges = [];
    //   json["exchanges"].forEach((v) {
    //     _exchanges.add(dynamic.fromJson(v));
    //   });
    // }
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    if (_coins != null) {
      map["coins"] = _coins.map((v) => v.toJson()).toList();
    }
    // if (_exchanges != null) {
    //   map["exchanges"] = _exchanges.map((v) => v.toJson()).toList();
    // }
    return map;
  }
}

/// item : {"id":"pancakeswap-token","name":"PancakeSwap","symbol":"CAKE","market_cap_rank":69,"thumb":"https://assets.coingecko.com/coins/images/12632/thumb/IMG_0440.PNG?1602654093","large":"https://assets.coingecko.com/coins/images/12632/large/IMG_0440.PNG?1602654093","score":0}

class Coins {
  Item _item;

  Item get item => _item;

  Coins({Item item}) {
    _item = item;
  }

  Coins.fromJson(dynamic json) {
    _item = json["item"] != null ? Item.fromJson(json["item"]) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    if (_item != null) {
      map["item"] = _item.toJson();
    }
    return map;
  }
}

/// id : "pancakeswap-token"
/// name : "PancakeSwap"
/// symbol : "CAKE"
/// market_cap_rank : 69
/// thumb : "https://assets.coingecko.com/coins/images/12632/thumb/IMG_0440.PNG?1602654093"
/// large : "https://assets.coingecko.com/coins/images/12632/large/IMG_0440.PNG?1602654093"
/// score : 0

class Item {
  String _id;
  String _name;
  String _symbol;
  int _marketCapRank;
  String _thumb;
  String _large;
  int _score;

  String get id => _id;

  String get name => _name;

  String get symbol => _symbol;

  int get marketCapRank => _marketCapRank;

  String get thumb => _thumb;

  String get large => _large;

  int get score => _score;

  Item(
      {String id,
      String name,
      String symbol,
      int marketCapRank,
      String thumb,
      String large,
      int score}) {
    _id = id;
    _name = name;
    _symbol = symbol;
    _marketCapRank = marketCapRank;
    _thumb = thumb;
    _large = large;
    _score = score;
  }

  Item.fromJson(dynamic json) {
    _id = json["id"];
    _name = json["name"];
    _symbol = json["symbol"];
    _marketCapRank = json["market_cap_rank"];
    _thumb = json["thumb"];
    _large = json["large"];
    _score = json["score"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["id"] = _id;
    map["name"] = _name;
    map["symbol"] = _symbol;
    map["market_cap_rank"] = _marketCapRank;
    map["thumb"] = _thumb;
    map["large"] = _large;
    map["score"] = _score;
    return map;
  }
}
