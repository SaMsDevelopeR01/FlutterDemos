/// rates : {"btc":{"name":"Bitcoin","unit":"BTC","value":1.0,"type":"crypto"},"eth":{"name":"Ether","unit":"ETH","value":25.795,"type":"crypto"},"ltc":{"name":"Litecoin","unit":"LTC","value":244.696,"type":"crypto"},"bch":{"name":"Bitcoin Cash","unit":"BCH","value":89.576,"type":"crypto"},"bnb":{"name":"Binance Coin","unit":"BNB","value":359.671,"type":"crypto"},"eos":{"name":"EOS","unit":"EOS","value":10791.627,"type":"crypto"},"xrp":{"name":"XRP","unit":"XRP","value":95739.869,"type":"crypto"},"xlm":{"name":"Lumens","unit":"XLM","value":114018.228,"type":"crypto"},"link":{"name":"Chainlink","unit":"LINK","value":1689.181,"type":"crypto"},"dot":{"name":"Polkadot","unit":"DOT","value":1963.319,"type":"crypto"},"yfi":{"name":"Yearn.finance","unit":"YFI","value":1.246,"type":"crypto"},"usd":{"name":"US Dollar","unit":"$","value":46587.191,"type":"fiat"},"aed":{"name":"United Arab Emirates Dirham","unit":"DH","value":171115.265,"type":"fiat"},"ars":{"name":"Argentine Peso","unit":"$","value":4112134.89,"type":"fiat"},"aud":{"name":"Australian Dollar","unit":"A$","value":60201.925,"type":"fiat"},"bdt":{"name":"Bangladeshi Taka","unit":"৳","value":3947239.061,"type":"fiat"},"bhd":{"name":"Bahraini Dinar","unit":"BD","value":17564.861,"type":"fiat"},"bmd":{"name":"Bermudian Dollar","unit":"$","value":46587.191,"type":"fiat"},"brl":{"name":"Brazil Real","unit":"R$","value":250558.259,"type":"fiat"},"cad":{"name":"Canadian Dollar","unit":"CA$","value":59158.325,"type":"fiat"},"chf":{"name":"Swiss Franc","unit":"Fr.","value":41543.615,"type":"fiat"},"clp":{"name":"Chilean Peso","unit":"CLP$","value":34227689.245,"type":"fiat"},"cny":{"name":"Chinese Yuan","unit":"¥","value":299937.653,"type":"fiat"},"czk":{"name":"Czech Koruna","unit":"Kč","value":989237.074,"type":"fiat"},"dkk":{"name":"Danish Krone","unit":"kr.","value":285779.806,"type":"fiat"},"eur":{"name":"Euro","unit":"€","value":38425.72,"type":"fiat"},"gbp":{"name":"British Pound Sterling","unit":"£","value":33722.324,"type":"fiat"},"hkd":{"name":"Hong Kong Dollar","unit":"HK$","value":361166.267,"type":"fiat"},"huf":{"name":"Hungarian Forint","unit":"Ft","value":13767446.714,"type":"fiat"},"idr":{"name":"Indonesian Rupiah","unit":"Rp","value":651723745.359,"type":"fiat"},"ils":{"name":"Israeli New Shekel","unit":"₪","value":151618.013,"type":"fiat"},"inr":{"name":"Indian Rupee","unit":"₹","value":3393993.339,"type":"fiat"},"jpy":{"name":"Japanese Yen","unit":"¥","value":4872437.849,"type":"fiat"},"krw":{"name":"South Korean Won","unit":"₩","value":51569192.38,"type":"fiat"},"kwd":{"name":"Kuwaiti Dinar","unit":"KD","value":14084.146,"type":"fiat"},"lkr":{"name":"Sri Lankan Rupee","unit":"Rs","value":9111048.391,"type":"fiat"},"mmk":{"name":"Burmese Kyat","unit":"K","value":65511755.919,"type":"fiat"},"mxn":{"name":"Mexican Peso","unit":"MX$","value":935453.094,"type":"fiat"},"myr":{"name":"Malaysian Ringgit","unit":"RM","value":188282.132,"type":"fiat"},"ngn":{"name":"Nigerian Naira","unit":"₦","value":18699087.752,"type":"fiat"},"nok":{"name":"Norwegian Krone","unit":"kr","value":393090.093,"type":"fiat"},"nzd":{"name":"New Zealand Dollar","unit":"NZ$","value":64452.586,"type":"fiat"},"php":{"name":"Philippine Peso","unit":"₱","value":2237968.204,"type":"fiat"},"pkr":{"name":"Pakistani Rupee","unit":"₨","value":7449482.631,"type":"fiat"},"pln":{"name":"Polish Zloty","unit":"zł","value":172003.636,"type":"fiat"},"rub":{"name":"Russian Ruble","unit":"₽","value":3445751.708,"type":"fiat"},"sar":{"name":"Saudi Riyal","unit":"SR","value":174755.308,"type":"fiat"},"sek":{"name":"Swedish Krona","unit":"kr","value":387481.554,"type":"fiat"},"sgd":{"name":"Singapore Dollar","unit":"S$","value":61783.932,"type":"fiat"},"thb":{"name":"Thai Baht","unit":"฿","value":1393422.885,"type":"fiat"},"try":{"name":"Turkish Lira","unit":"₺","value":329969.62,"type":"fiat"},"twd":{"name":"New Taiwan Dollar","unit":"NT$","value":1304431.148,"type":"fiat"},"uah":{"name":"Ukrainian hryvnia","unit":"₴","value":1289402.865,"type":"fiat"},"vef":{"name":"Venezuelan bolívar fuerte","unit":"Bs.F","value":4664.775,"type":"fiat"},"vnd":{"name":"Vietnamese đồng","unit":"₫","value":1070575513.496,"type":"fiat"},"zar":{"name":"South African Rand","unit":"R","value":686250.289,"type":"fiat"},"xdr":{"name":"IMF Special Drawing Rights","unit":"XDR","value":32372.414,"type":"fiat"},"xag":{"name":"Silver - Troy Ounce","unit":"XAG","value":1703.372,"type":"commodity"},"xau":{"name":"Gold - Troy Ounce","unit":"XAU","value":25.264,"type":"commodity"},"bits":{"name":"Bits","unit":"μBTC","value":1000000.0,"type":"crypto"},"sats":{"name":"Satoshi","unit":"sats","value":100000000.0,"type":"crypto"}}

class CryptoExchangeRate {
  Rates _rates;

  Rates get rates => _rates;

  CryptoExchangeRate({Rates rates}) {
    _rates = rates;
  }

  CryptoExchangeRate.fromJson(dynamic json) {
    print("jason[rate]: ${json['rates']}");
    _rates = json["rates"] != null ? Rates.fromJson(json["rates"]) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    if (_rates != null) {
      map["rates"] = _rates.toJson();
    }
    return map;
  }
}

/// btc : {"name":"Bitcoin","unit":"BTC","value":1.0,"type":"crypto"}
/// eth : {"name":"Ether","unit":"ETH","value":25.795,"type":"crypto"}
/// ltc : {"name":"Litecoin","unit":"LTC","value":244.696,"type":"crypto"}
/// bch : {"name":"Bitcoin Cash","unit":"BCH","value":89.576,"type":"crypto"}
/// bnb : {"name":"Binance Coin","unit":"BNB","value":359.671,"type":"crypto"}
/// eos : {"name":"EOS","unit":"EOS","value":10791.627,"type":"crypto"}
/// xrp : {"name":"XRP","unit":"XRP","value":95739.869,"type":"crypto"}
/// xlm : {"name":"Lumens","unit":"XLM","value":114018.228,"type":"crypto"}
/// link : {"name":"Chainlink","unit":"LINK","value":1689.181,"type":"crypto"}
/// dot : {"name":"Polkadot","unit":"DOT","value":1963.319,"type":"crypto"}
/// yfi : {"name":"Yearn.finance","unit":"YFI","value":1.246,"type":"crypto"}
/// usd : {"name":"US Dollar","unit":"$","value":46587.191,"type":"fiat"}
/// aed : {"name":"United Arab Emirates Dirham","unit":"DH","value":171115.265,"type":"fiat"}
/// ars : {"name":"Argentine Peso","unit":"$","value":4112134.89,"type":"fiat"}
/// aud : {"name":"Australian Dollar","unit":"A$","value":60201.925,"type":"fiat"}
/// bdt : {"name":"Bangladeshi Taka","unit":"৳","value":3947239.061,"type":"fiat"}
/// bhd : {"name":"Bahraini Dinar","unit":"BD","value":17564.861,"type":"fiat"}
/// bmd : {"name":"Bermudian Dollar","unit":"$","value":46587.191,"type":"fiat"}
/// brl : {"name":"Brazil Real","unit":"R$","value":250558.259,"type":"fiat"}
/// cad : {"name":"Canadian Dollar","unit":"CA$","value":59158.325,"type":"fiat"}
/// chf : {"name":"Swiss Franc","unit":"Fr.","value":41543.615,"type":"fiat"}
/// clp : {"name":"Chilean Peso","unit":"CLP$","value":34227689.245,"type":"fiat"}
/// cny : {"name":"Chinese Yuan","unit":"¥","value":299937.653,"type":"fiat"}
/// czk : {"name":"Czech Koruna","unit":"Kč","value":989237.074,"type":"fiat"}
/// dkk : {"name":"Danish Krone","unit":"kr.","value":285779.806,"type":"fiat"}
/// eur : {"name":"Euro","unit":"€","value":38425.72,"type":"fiat"}
/// gbp : {"name":"British Pound Sterling","unit":"£","value":33722.324,"type":"fiat"}
/// hkd : {"name":"Hong Kong Dollar","unit":"HK$","value":361166.267,"type":"fiat"}
/// huf : {"name":"Hungarian Forint","unit":"Ft","value":13767446.714,"type":"fiat"}
/// idr : {"name":"Indonesian Rupiah","unit":"Rp","value":651723745.359,"type":"fiat"}
/// ils : {"name":"Israeli New Shekel","unit":"₪","value":151618.013,"type":"fiat"}
/// inr : {"name":"Indian Rupee","unit":"₹","value":3393993.339,"type":"fiat"}
/// jpy : {"name":"Japanese Yen","unit":"¥","value":4872437.849,"type":"fiat"}
/// krw : {"name":"South Korean Won","unit":"₩","value":51569192.38,"type":"fiat"}
/// kwd : {"name":"Kuwaiti Dinar","unit":"KD","value":14084.146,"type":"fiat"}
/// lkr : {"name":"Sri Lankan Rupee","unit":"Rs","value":9111048.391,"type":"fiat"}
/// mmk : {"name":"Burmese Kyat","unit":"K","value":65511755.919,"type":"fiat"}
/// mxn : {"name":"Mexican Peso","unit":"MX$","value":935453.094,"type":"fiat"}
/// myr : {"name":"Malaysian Ringgit","unit":"RM","value":188282.132,"type":"fiat"}
/// ngn : {"name":"Nigerian Naira","unit":"₦","value":18699087.752,"type":"fiat"}
/// nok : {"name":"Norwegian Krone","unit":"kr","value":393090.093,"type":"fiat"}
/// nzd : {"name":"New Zealand Dollar","unit":"NZ$","value":64452.586,"type":"fiat"}
/// php : {"name":"Philippine Peso","unit":"₱","value":2237968.204,"type":"fiat"}
/// pkr : {"name":"Pakistani Rupee","unit":"₨","value":7449482.631,"type":"fiat"}
/// pln : {"name":"Polish Zloty","unit":"zł","value":172003.636,"type":"fiat"}
/// rub : {"name":"Russian Ruble","unit":"₽","value":3445751.708,"type":"fiat"}
/// sar : {"name":"Saudi Riyal","unit":"SR","value":174755.308,"type":"fiat"}
/// sek : {"name":"Swedish Krona","unit":"kr","value":387481.554,"type":"fiat"}
/// sgd : {"name":"Singapore Dollar","unit":"S$","value":61783.932,"type":"fiat"}
/// thb : {"name":"Thai Baht","unit":"฿","value":1393422.885,"type":"fiat"}
/// try : {"name":"Turkish Lira","unit":"₺","value":329969.62,"type":"fiat"}
/// twd : {"name":"New Taiwan Dollar","unit":"NT$","value":1304431.148,"type":"fiat"}
/// uah : {"name":"Ukrainian hryvnia","unit":"₴","value":1289402.865,"type":"fiat"}
/// vef : {"name":"Venezuelan bolívar fuerte","unit":"Bs.F","value":4664.775,"type":"fiat"}
/// vnd : {"name":"Vietnamese đồng","unit":"₫","value":1070575513.496,"type":"fiat"}
/// zar : {"name":"South African Rand","unit":"R","value":686250.289,"type":"fiat"}
/// xdr : {"name":"IMF Special Drawing Rights","unit":"XDR","value":32372.414,"type":"fiat"}
/// xag : {"name":"Silver - Troy Ounce","unit":"XAG","value":1703.372,"type":"commodity"}
/// xau : {"name":"Gold - Troy Ounce","unit":"XAU","value":25.264,"type":"commodity"}
/// bits : {"name":"Bits","unit":"μBTC","value":1000000.0,"type":"crypto"}
/// sats : {"name":"Satoshi","unit":"sats","value":100000000.0,"type":"crypto"}

class Rates {
  Btc _btc;
  Eth _eth;
  Ltc _ltc;
  Bch _bch;
  Bnb _bnb;
  Eos _eos;
  Xrp _xrp;
  Xlm _xlm;
  Link _link;
  Dot _dot;
  Yfi _yfi;
  Usd _usd;
  Aed _aed;
  Ars _ars;
  Aud _aud;
  Bdt _bdt;
  Bhd _bhd;
  Bmd _bmd;
  Brl _brl;
  Cad _cad;
  Chf _chf;
  Clp _clp;
  Cny _cny;
  Czk _czk;
  Dkk _dkk;
  Eur _eur;
  Gbp _gbp;
  Hkd _hkd;
  Huf _huf;
  Idr _idr;
  Ils _ils;
  Inr _inr;
  Jpy _jpy;
  Krw _krw;
  Kwd _kwd;
  Lkr _lkr;
  Mmk _mmk;
  Mxn _mxn;
  Myr _myr;
  Ngn _ngn;
  Nok _nok;
  Nzd _nzd;
  Php _php;
  Pkr _pkr;
  Pln _pln;
  Rub _rub;
  Sar _sar;
  Sek _sek;
  Sgd _sgd;
  Thb _thb;
  Try _try;
  Twd _twd;
  Uah _uah;
  Vef _vef;
  Vnd _vnd;
  Zar _zar;
  Xdr _xdr;
  Xag _xag;
  Xau _xau;
  Bits _bits;
  Sats _sats;

  Btc get btc => _btc;

  Eth get eth => _eth;

  Ltc get ltc => _ltc;

  Bch get bch => _bch;

  Bnb get bnb => _bnb;

  Eos get eos => _eos;

  Xrp get xrp => _xrp;

  Xlm get xlm => _xlm;

  Link get link => _link;

  Dot get dot => _dot;

  Yfi get yfi => _yfi;

  Usd get usd => _usd;

  Aed get aed => _aed;

  Ars get ars => _ars;

  Aud get aud => _aud;

  Bdt get bdt => _bdt;

  Bhd get bhd => _bhd;

  Bmd get bmd => _bmd;

  Brl get brl => _brl;

  Cad get cad => _cad;

  Chf get chf => _chf;

  Clp get clp => _clp;

  Cny get cny => _cny;

  Czk get czk => _czk;

  Dkk get dkk => _dkk;

  Eur get eur => _eur;

  Gbp get gbp => _gbp;

  Hkd get hkd => _hkd;

  Huf get huf => _huf;

  Idr get idr => _idr;

  Ils get ils => _ils;

  Inr get inr => _inr;

  Jpy get jpy => _jpy;

  Krw get krw => _krw;

  Kwd get kwd => _kwd;

  Lkr get lkr => _lkr;

  Mmk get mmk => _mmk;

  Mxn get mxn => _mxn;

  Myr get myr => _myr;

  Ngn get ngn => _ngn;

  Nok get nok => _nok;

  Nzd get nzd => _nzd;

  Php get php => _php;

  Pkr get pkr => _pkr;

  Pln get pln => _pln;

  Rub get rub => _rub;

  Sar get sar => _sar;

  Sek get sek => _sek;

  Sgd get sgd => _sgd;

  Thb get thb => _thb;

  Try get trycrn => _try;

  Twd get twd => _twd;

  Uah get uah => _uah;

  Vef get vef => _vef;

  Vnd get vnd => _vnd;

  Zar get zar => _zar;

  Xdr get xdr => _xdr;

  Xag get xag => _xag;

  Xau get xau => _xau;

  Bits get bits => _bits;

  Sats get sats => _sats;

  Rates(
      {Btc btc,
      Eth eth,
      Ltc ltc,
      Bch bch,
      Bnb bnb,
      Eos eos,
      Xrp xrp,
      Xlm xlm,
      Link link,
      Dot dot,
      Yfi yfi,
      Usd usd,
      Aed aed,
      Ars ars,
      Aud aud,
      Bdt bdt,
      Bhd bhd,
      Bmd bmd,
      Brl brl,
      Cad cad,
      Chf chf,
      Clp clp,
      Cny cny,
      Czk czk,
      Dkk dkk,
      Eur eur,
      Gbp gbp,
      Hkd hkd,
      Huf huf,
      Idr idr,
      Ils ils,
      Inr inr,
      Jpy jpy,
      Krw krw,
      Kwd kwd,
      Lkr lkr,
      Mmk mmk,
      Mxn mxn,
      Myr myr,
      Ngn ngn,
      Nok nok,
      Nzd nzd,
      Php php,
      Pkr pkr,
      Pln pln,
      Rub rub,
      Sar sar,
      Sek sek,
      Sgd sgd,
      Thb thb,
      Try trycrn,
      Twd twd,
      Uah uah,
      Vef vef,
      Vnd vnd,
      Zar zar,
      Xdr xdr,
      Xag xag,
      Xau xau,
      Bits bits,
      Sats sats}) {
    _btc = btc;
    _eth = eth;
    _ltc = ltc;
    _bch = bch;
    _bnb = bnb;
    _eos = eos;
    _xrp = xrp;
    _xlm = xlm;
    _link = link;
    _dot = dot;
    _yfi = yfi;
    _usd = usd;
    _aed = aed;
    _ars = ars;
    _aud = aud;
    _bdt = bdt;
    _bhd = bhd;
    _bmd = bmd;
    _brl = brl;
    _cad = cad;
    _chf = chf;
    _clp = clp;
    _cny = cny;
    _czk = czk;
    _dkk = dkk;
    _eur = eur;
    _gbp = gbp;
    _hkd = hkd;
    _huf = huf;
    _idr = idr;
    _ils = ils;
    _inr = inr;
    _jpy = jpy;
    _krw = krw;
    _kwd = kwd;
    _lkr = lkr;
    _mmk = mmk;
    _mxn = mxn;
    _myr = myr;
    _ngn = ngn;
    _nok = nok;
    _nzd = nzd;
    _php = php;
    _pkr = pkr;
    _pln = pln;
    _rub = rub;
    _sar = sar;
    _sek = sek;
    _sgd = sgd;
    _thb = thb;
    _try = trycrn;
    _twd = twd;
    _uah = uah;
    _vef = vef;
    _vnd = vnd;
    _zar = zar;
    _xdr = xdr;
    _xag = xag;
    _xau = xau;
    _bits = bits;
    _sats = sats;
  }

  Rates.fromJson(dynamic json) {
    print("json$json");
    _btc = json["btc"] != null ? Btc.fromJson(json["btc"]) : null;
    _eth = json["eth"] != null ? Eth.fromJson(json["eth"]) : null;
    _ltc = json["ltc"] != null ? Ltc.fromJson(json["ltc"]) : null;
    _bch = json["bch"] != null ? Bch.fromJson(json["bch"]) : null;
    _bnb = json["bnb"] != null ? Bnb.fromJson(json["bnb"]) : null;
    _eos = json["eos"] != null ? Eos.fromJson(json["eos"]) : null;
    _xrp = json["xrp"] != null ? Xrp.fromJson(json["xrp"]) : null;
    _xlm = json["xlm"] != null ? Xlm.fromJson(json["xlm"]) : null;
    _link = json["link"] != null ? Link.fromJson(json["link"]) : null;
    _dot = json["dot"] != null ? Dot.fromJson(json["dot"]) : null;
    _yfi = json["yfi"] != null ? Yfi.fromJson(json["yfi"]) : null;
    _usd = json["usd"] != null ? Usd.fromJson(json["usd"]) : null;
    _aed = json["aed"] != null ? Aed.fromJson(json["aed"]) : null;
    _ars = json["ars"] != null ? Ars.fromJson(json["ars"]) : null;
    _aud = json["aud"] != null ? Aud.fromJson(json["aud"]) : null;
    _bdt = json["bdt"] != null ? Bdt.fromJson(json["bdt"]) : null;
    _bhd = json["bhd"] != null ? Bhd.fromJson(json["bhd"]) : null;
    _bmd = json["bmd"] != null ? Bmd.fromJson(json["bmd"]) : null;
    _brl = json["brl"] != null ? Brl.fromJson(json["brl"]) : null;
    _cad = json["cad"] != null ? Cad.fromJson(json["cad"]) : null;
    _chf = json["chf"] != null ? Chf.fromJson(json["chf"]) : null;
    _clp = json["clp"] != null ? Clp.fromJson(json["clp"]) : null;
    _cny = json["cny"] != null ? Cny.fromJson(json["cny"]) : null;
    _czk = json["czk"] != null ? Czk.fromJson(json["czk"]) : null;
    _dkk = json["dkk"] != null ? Dkk.fromJson(json["dkk"]) : null;
    _eur = json["eur"] != null ? Eur.fromJson(json["eur"]) : null;
    _gbp = json["gbp"] != null ? Gbp.fromJson(json["gbp"]) : null;
    _hkd = json["hkd"] != null ? Hkd.fromJson(json["hkd"]) : null;
    _huf = json["huf"] != null ? Huf.fromJson(json["huf"]) : null;
    _idr = json["idr"] != null ? Idr.fromJson(json["idr"]) : null;
    _ils = json["ils"] != null ? Ils.fromJson(json["ils"]) : null;
    _inr = json["inr"] != null ? Inr.fromJson(json["inr"]) : null;
    _jpy = json["jpy"] != null ? Jpy.fromJson(json["jpy"]) : null;
    _krw = json["krw"] != null ? Krw.fromJson(json["krw"]) : null;
    _kwd = json["kwd"] != null ? Kwd.fromJson(json["kwd"]) : null;
    _lkr = json["lkr"] != null ? Lkr.fromJson(json["lkr"]) : null;
    _mmk = json["mmk"] != null ? Mmk.fromJson(json["mmk"]) : null;
    _mxn = json["mxn"] != null ? Mxn.fromJson(json["mxn"]) : null;
    _myr = json["myr"] != null ? Myr.fromJson(json["myr"]) : null;
    _ngn = json["ngn"] != null ? Ngn.fromJson(json["ngn"]) : null;
    _nok = json["nok"] != null ? Nok.fromJson(json["nok"]) : null;
    _nzd = json["nzd"] != null ? Nzd.fromJson(json["nzd"]) : null;
    _php = json["php"] != null ? Php.fromJson(json["php"]) : null;
    _pkr = json["pkr"] != null ? Pkr.fromJson(json["pkr"]) : null;
    _pln = json["pln"] != null ? Pln.fromJson(json["pln"]) : null;
    _rub = json["rub"] != null ? Rub.fromJson(json["rub"]) : null;
    _sar = json["sar"] != null ? Sar.fromJson(json["sar"]) : null;
    _sek = json["sek"] != null ? Sek.fromJson(json["sek"]) : null;
    _sgd = json["sgd"] != null ? Sgd.fromJson(json["sgd"]) : null;
    _thb = json["thb"] != null ? Thb.fromJson(json["thb"]) : null;
    _try = json["try"] != null ? Try.fromJson(json["try"]) : null;
    _twd = json["twd"] != null ? Twd.fromJson(json["twd"]) : null;
    _uah = json["uah"] != null ? Uah.fromJson(json["uah"]) : null;
    _vef = json["vef"] != null ? Vef.fromJson(json["vef"]) : null;
    _vnd = json["vnd"] != null ? Vnd.fromJson(json["vnd"]) : null;
    _zar = json["zar"] != null ? Zar.fromJson(json["zar"]) : null;
    _xdr = json["xdr"] != null ? Xdr.fromJson(json["xdr"]) : null;
    _xag = json["xag"] != null ? Xag.fromJson(json["xag"]) : null;
    _xau = json["xau"] != null ? Xau.fromJson(json["xau"]) : null;
    _bits = json["bits"] != null ? Bits.fromJson(json["bits"]) : null;
    _sats = json["sats"] != null ? Sats.fromJson(json["sats"]) : null;
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    if (_btc != null) {
      map["btc"] = _btc.toJson();
    }
    if (_eth != null) {
      map["eth"] = _eth.toJson();
    }
    if (_ltc != null) {
      map["ltc"] = _ltc.toJson();
    }
    if (_bch != null) {
      map["bch"] = _bch.toJson();
    }
    if (_bnb != null) {
      map["bnb"] = _bnb.toJson();
    }
    if (_eos != null) {
      map["eos"] = _eos.toJson();
    }
    if (_xrp != null) {
      map["xrp"] = _xrp.toJson();
    }
    if (_xlm != null) {
      map["xlm"] = _xlm.toJson();
    }
    if (_link != null) {
      map["link"] = _link.toJson();
    }
    if (_dot != null) {
      map["dot"] = _dot.toJson();
    }
    if (_yfi != null) {
      map["yfi"] = _yfi.toJson();
    }
    if (_usd != null) {
      map["usd"] = _usd.toJson();
    }
    if (_aed != null) {
      map["aed"] = _aed.toJson();
    }
    if (_ars != null) {
      map["ars"] = _ars.toJson();
    }
    if (_aud != null) {
      map["aud"] = _aud.toJson();
    }
    if (_bdt != null) {
      map["bdt"] = _bdt.toJson();
    }
    if (_bhd != null) {
      map["bhd"] = _bhd.toJson();
    }
    if (_bmd != null) {
      map["bmd"] = _bmd.toJson();
    }
    if (_brl != null) {
      map["brl"] = _brl.toJson();
    }
    if (_cad != null) {
      map["cad"] = _cad.toJson();
    }
    if (_chf != null) {
      map["chf"] = _chf.toJson();
    }
    if (_clp != null) {
      map["clp"] = _clp.toJson();
    }
    if (_cny != null) {
      map["cny"] = _cny.toJson();
    }
    if (_czk != null) {
      map["czk"] = _czk.toJson();
    }
    if (_dkk != null) {
      map["dkk"] = _dkk.toJson();
    }
    if (_eur != null) {
      map["eur"] = _eur.toJson();
    }
    if (_gbp != null) {
      map["gbp"] = _gbp.toJson();
    }
    if (_hkd != null) {
      map["hkd"] = _hkd.toJson();
    }
    if (_huf != null) {
      map["huf"] = _huf.toJson();
    }
    if (_idr != null) {
      map["idr"] = _idr.toJson();
    }
    if (_ils != null) {
      map["ils"] = _ils.toJson();
    }
    if (_inr != null) {
      map["inr"] = _inr.toJson();
    }
    if (_jpy != null) {
      map["jpy"] = _jpy.toJson();
    }
    if (_krw != null) {
      map["krw"] = _krw.toJson();
    }
    if (_kwd != null) {
      map["kwd"] = _kwd.toJson();
    }
    if (_lkr != null) {
      map["lkr"] = _lkr.toJson();
    }
    if (_mmk != null) {
      map["mmk"] = _mmk.toJson();
    }
    if (_mxn != null) {
      map["mxn"] = _mxn.toJson();
    }
    if (_myr != null) {
      map["myr"] = _myr.toJson();
    }
    if (_ngn != null) {
      map["ngn"] = _ngn.toJson();
    }
    if (_nok != null) {
      map["nok"] = _nok.toJson();
    }
    if (_nzd != null) {
      map["nzd"] = _nzd.toJson();
    }
    if (_php != null) {
      map["php"] = _php.toJson();
    }
    if (_pkr != null) {
      map["pkr"] = _pkr.toJson();
    }
    if (_pln != null) {
      map["pln"] = _pln.toJson();
    }
    if (_rub != null) {
      map["rub"] = _rub.toJson();
    }
    if (_sar != null) {
      map["sar"] = _sar.toJson();
    }
    if (_sek != null) {
      map["sek"] = _sek.toJson();
    }
    if (_sgd != null) {
      map["sgd"] = _sgd.toJson();
    }
    if (_thb != null) {
      map["thb"] = _thb.toJson();
    }
    if (_try != null) {
      map["try"] = _try.toJson();
    }
    if (_twd != null) {
      map["twd"] = _twd.toJson();
    }
    if (_uah != null) {
      map["uah"] = _uah.toJson();
    }
    if (_vef != null) {
      map["vef"] = _vef.toJson();
    }
    if (_vnd != null) {
      map["vnd"] = _vnd.toJson();
    }
    if (_zar != null) {
      map["zar"] = _zar.toJson();
    }
    if (_xdr != null) {
      map["xdr"] = _xdr.toJson();
    }
    if (_xag != null) {
      map["xag"] = _xag.toJson();
    }
    if (_xau != null) {
      map["xau"] = _xau.toJson();
    }
    if (_bits != null) {
      map["bits"] = _bits.toJson();
    }
    if (_sats != null) {
      map["sats"] = _sats.toJson();
    }
    return map;
  }
}

/// name : "Satoshi"
/// unit : "sats"
/// value : 100000000.0
/// type : "crypto"

class Sats {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Sats({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Sats.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Bits"
/// unit : "μBTC"
/// value : 1000000.0
/// type : "crypto"

class Bits {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Bits({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Bits.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Gold - Troy Ounce"
/// unit : "XAU"
/// value : 25.264
/// type : "commodity"

class Xau {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Xau({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Xau.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Silver - Troy Ounce"
/// unit : "XAG"
/// value : 1703.372
/// type : "commodity"

class Xag {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Xag({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Xag.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "IMF Special Drawing Rights"
/// unit : "XDR"
/// value : 32372.414
/// type : "fiat"

class Xdr {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Xdr({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Xdr.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "South African Rand"
/// unit : "R"
/// value : 686250.289
/// type : "fiat"

class Zar {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Zar({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Zar.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Vietnamese đồng"
/// unit : "₫"
/// value : 1070575513.496
/// type : "fiat"

class Vnd {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Vnd({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Vnd.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Venezuelan bolívar fuerte"
/// unit : "Bs.F"
/// value : 4664.775
/// type : "fiat"

class Vef {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Vef({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Vef.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Ukrainian hryvnia"
/// unit : "₴"
/// value : 1289402.865
/// type : "fiat"

class Uah {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Uah({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Uah.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "New Taiwan Dollar"
/// unit : "NT$"
/// value : 1304431.148
/// type : "fiat"

class Twd {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Twd({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Twd.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Turkish Lira"
/// unit : "₺"
/// value : 329969.62
/// type : "fiat"

class Try {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Try({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Try.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Thai Baht"
/// unit : "฿"
/// value : 1393422.885
/// type : "fiat"

class Thb {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Thb({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Thb.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Singapore Dollar"
/// unit : "S$"
/// value : 61783.932
/// type : "fiat"

class Sgd {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Sgd({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Sgd.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Swedish Krona"
/// unit : "kr"
/// value : 387481.554
/// type : "fiat"

class Sek {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Sek({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Sek.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Saudi Riyal"
/// unit : "SR"
/// value : 174755.308
/// type : "fiat"

class Sar {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Sar({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Sar.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Russian Ruble"
/// unit : "₽"
/// value : 3445751.708
/// type : "fiat"

class Rub {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Rub({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Rub.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Polish Zloty"
/// unit : "zł"
/// value : 172003.636
/// type : "fiat"

class Pln {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Pln({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Pln.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Pakistani Rupee"
/// unit : "₨"
/// value : 7449482.631
/// type : "fiat"

class Pkr {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Pkr({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Pkr.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Philippine Peso"
/// unit : "₱"
/// value : 2237968.204
/// type : "fiat"

class Php {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Php({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Php.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "New Zealand Dollar"
/// unit : "NZ$"
/// value : 64452.586
/// type : "fiat"

class Nzd {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Nzd({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Nzd.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Norwegian Krone"
/// unit : "kr"
/// value : 393090.093
/// type : "fiat"

class Nok {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Nok({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Nok.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Nigerian Naira"
/// unit : "₦"
/// value : 18699087.752
/// type : "fiat"

class Ngn {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Ngn({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Ngn.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Malaysian Ringgit"
/// unit : "RM"
/// value : 188282.132
/// type : "fiat"

class Myr {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Myr({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Myr.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Mexican Peso"
/// unit : "MX$"
/// value : 935453.094
/// type : "fiat"

class Mxn {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Mxn({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Mxn.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Burmese Kyat"
/// unit : "K"
/// value : 65511755.919
/// type : "fiat"

class Mmk {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Mmk({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Mmk.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Sri Lankan Rupee"
/// unit : "Rs"
/// value : 9111048.391
/// type : "fiat"

class Lkr {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Lkr({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Lkr.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Kuwaiti Dinar"
/// unit : "KD"
/// value : 14084.146
/// type : "fiat"

class Kwd {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Kwd({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Kwd.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "South Korean Won"
/// unit : "₩"
/// value : 51569192.38
/// type : "fiat"

class Krw {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Krw({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Krw.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Japanese Yen"
/// unit : "¥"
/// value : 4872437.849
/// type : "fiat"

class Jpy {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Jpy({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Jpy.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Indian Rupee"
/// unit : "₹"
/// value : 3393993.339
/// type : "fiat"

class Inr {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Inr({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Inr.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Israeli New Shekel"
/// unit : "₪"
/// value : 151618.013
/// type : "fiat"

class Ils {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Ils({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Ils.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Indonesian Rupiah"
/// unit : "Rp"
/// value : 651723745.359
/// type : "fiat"

class Idr {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Idr({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Idr.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Hungarian Forint"
/// unit : "Ft"
/// value : 13767446.714
/// type : "fiat"

class Huf {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Huf({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Huf.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Hong Kong Dollar"
/// unit : "HK$"
/// value : 361166.267
/// type : "fiat"

class Hkd {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Hkd({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Hkd.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "British Pound Sterling"
/// unit : "£"
/// value : 33722.324
/// type : "fiat"

class Gbp {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Gbp({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Gbp.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Euro"
/// unit : "€"
/// value : 38425.72
/// type : "fiat"

class Eur {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Eur({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Eur.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Danish Krone"
/// unit : "kr."
/// value : 285779.806
/// type : "fiat"

class Dkk {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Dkk({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Dkk.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Czech Koruna"
/// unit : "Kč"
/// value : 989237.074
/// type : "fiat"

class Czk {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Czk({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Czk.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Chinese Yuan"
/// unit : "¥"
/// value : 299937.653
/// type : "fiat"

class Cny {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Cny({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Cny.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Chilean Peso"
/// unit : "CLP$"
/// value : 34227689.245
/// type : "fiat"

class Clp {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Clp({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Clp.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Swiss Franc"
/// unit : "Fr."
/// value : 41543.615
/// type : "fiat"

class Chf {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Chf({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Chf.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Canadian Dollar"
/// unit : "CA$"
/// value : 59158.325
/// type : "fiat"

class Cad {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Cad({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Cad.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Brazil Real"
/// unit : "R$"
/// value : 250558.259
/// type : "fiat"

class Brl {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Brl({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Brl.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Bermudian Dollar"
/// unit : "$"
/// value : 46587.191
/// type : "fiat"

class Bmd {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Bmd({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Bmd.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Bahraini Dinar"
/// unit : "BD"
/// value : 17564.861
/// type : "fiat"

class Bhd {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Bhd({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Bhd.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Bangladeshi Taka"
/// unit : "৳"
/// value : 3947239.061
/// type : "fiat"

class Bdt {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Bdt({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Bdt.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Australian Dollar"
/// unit : "A$"
/// value : 60201.925
/// type : "fiat"

class Aud {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Aud({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Aud.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Argentine Peso"
/// unit : "$"
/// value : 4112134.89
/// type : "fiat"

class Ars {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Ars({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Ars.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "United Arab Emirates Dirham"
/// unit : "DH"
/// value : 171115.265
/// type : "fiat"

class Aed {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Aed({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Aed.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "US Dollar"
/// unit : "$"
/// value : 46587.191
/// type : "fiat"

class Usd {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Usd({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Usd.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Yearn.finance"
/// unit : "YFI"
/// value : 1.246
/// type : "crypto"

class Yfi {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Yfi({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Yfi.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Polkadot"
/// unit : "DOT"
/// value : 1963.319
/// type : "crypto"

class Dot {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Dot({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Dot.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Chainlink"
/// unit : "LINK"
/// value : 1689.181
/// type : "crypto"

class Link {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Link({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Link.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Lumens"
/// unit : "XLM"
/// value : 114018.228
/// type : "crypto"

class Xlm {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Xlm({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Xlm.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "XRP"
/// unit : "XRP"
/// value : 95739.869
/// type : "crypto"

class Xrp {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Xrp({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Xrp.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "EOS"
/// unit : "EOS"
/// value : 10791.627
/// type : "crypto"

class Eos {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Eos({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Eos.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Binance Coin"
/// unit : "BNB"
/// value : 359.671
/// type : "crypto"

class Bnb {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Bnb({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Bnb.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Bitcoin Cash"
/// unit : "BCH"
/// value : 89.576
/// type : "crypto"

class Bch {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Bch({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Bch.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Litecoin"
/// unit : "LTC"
/// value : 244.696
/// type : "crypto"

class Ltc {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Ltc({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Ltc.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Ether"
/// unit : "ETH"
/// value : 25.795
/// type : "crypto"

class Eth {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Eth({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Eth.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}

/// name : "Bitcoin"
/// unit : "BTC"
/// value : 1.0
/// type : "crypto"

class Btc {
  String _name;
  String _unit;
  double _value;
  String _type;

  String get name => _name;

  String get unit => _unit;

  double get value => _value;

  String get type => _type;

  Btc({String name, String unit, double value, String type}) {
    _name = name;
    _unit = unit;
    _value = value;
    _type = type;
  }

  Btc.fromJson(dynamic json) {
    _name = json["name"];
    _unit = json["unit"];
    _value = json["value"];
    _type = json["type"];
  }

  Map<String, dynamic> toJson() {
    var map = <String, dynamic>{};
    map["name"] = _name;
    map["unit"] = _unit;
    map["value"] = _value;
    map["type"] = _type;
    return map;
  }
}
