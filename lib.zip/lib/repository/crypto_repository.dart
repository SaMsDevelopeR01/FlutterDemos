import 'dart:async';
import 'package:cryptocoin/models/crypto_chart_data.dart';
import 'package:cryptocoin/models/crypto_exchangelist_data.dart';
import 'package:cryptocoin/models/crypto_list_data.dart';
import 'package:cryptocoin/models/crypto_trendigs.dart';
import 'package:cryptocoin/models/exchangerate/exchange_rates.dart';
import 'package:meta/meta.dart';
import 'crypto_api_client.dart';

class CryptoRepository {
  final CryptoApiClient cryptoApiClient;

  CryptoRepository({@required this.cryptoApiClient})
      : assert(cryptoApiClient != null);

  Future<List<CryptoList>> fetchCryptoList() async {
    return await cryptoApiClient.fetchCryptoList();
  }

  Future<CryptoChart> fetchCryptoChart(String paramCoin,String paramDuration) async {
    return await cryptoApiClient.fetchCryptoChart(paramCoin,paramDuration);
  }

  Future<ExchangeRates> fetchCryptoExchangeRates() async {
    return await cryptoApiClient.fetchCryptoExchangeRates();
  }

  Future<List<CryptoExchangeList>> fetchCryptoExchangeList() async {
    return await cryptoApiClient.fetchCryptoExchangeList();
  }

  Future<CryptoTrendigs> fetchCryptoTrendig() async {
    return await cryptoApiClient.fetchCryptoTrending();
  }
}
