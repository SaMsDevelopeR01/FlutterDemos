import 'dart:convert';
import 'package:cryptocoin/models/crypto_chart_data.dart';
import 'package:cryptocoin/models/crypto_exchangelist_data.dart';
import 'package:cryptocoin/models/crypto_list_data.dart';
import 'package:cryptocoin/models/crypto_trendigs.dart';
import 'package:cryptocoin/models/exchangerate/exchange_rates.dart';
import 'package:http/http.dart' as http;
import 'package:meta/meta.dart';

class CryptoApiClient {
  final http.Client httpClient;

  CryptoApiClient({
    @required this.httpClient,
  }) : assert(httpClient != null);

  Future<List<CryptoList>> fetchCryptoList() async {


    final url =
        'https://api.coingecko.com/api/v3/coins/markets?vs_currency=eth&order=market_cap_desc&per_page=100&page=1&sparkline=false';
    final response = await this.httpClient.get(url);

    if (response.statusCode != 200) {
      throw new Exception('error getting data');
    }
    final json = jsonDecode(response.body);
    var array = List<CryptoList>();
    json.forEach((obj) {
      array.add(CryptoList.fromJson(obj));
    });
    return array;
  }

  Future<CryptoChart> fetchCryptoChart(String paramCoin,String paramDuration) async {
    //print("${paramCoin} and ${paramDuration}");
    final url =
        "https://api.coingecko.com/api/v3/coins/bitcoin/market_chart?vs_currency="+paramCoin+"&days="+paramDuration+"";
    final response = await this.httpClient.get(url);

    if (response.statusCode != 200) {
      throw new Exception('error getting data');
    }
    final json = jsonDecode(response.body);
    return CryptoChart.fromJson(json);
  }

  Future<ExchangeRates> fetchCryptoExchangeRates() async {
    final url = 'https://api.coingecko.com/api/v3/exchange_rates';
    final response = await this.httpClient.get(url);

    if (response.statusCode != 200) {
      throw new Exception('error getting data');
    }
    final json = jsonDecode(response.body);

    return ExchangeRates.fromJson(json);
  }

  Future<List<CryptoExchangeList>> fetchCryptoExchangeList() async {
    final url = 'https://api.coingecko.com/api/v3/exchanges';
    final response = await this.httpClient.get(url);

    if (response.statusCode != 200) {
      throw new Exception('error getting data');
    }
    final json = jsonDecode(response.body);
    var array = List<CryptoExchangeList>();
    json.forEach((obj) {
      array.add(CryptoExchangeList.fromJson(obj));
    });
    return array;
  }

  Future<CryptoTrendigs> fetchCryptoTrending() async {
    final url = 'https://api.coingecko.com/api/v3/search/trending';
    final response = await this.httpClient.get(url);

    if (response.statusCode != 200) {
      throw new Exception('error getting data');
    }
    final json = jsonDecode(response.body);
    return CryptoTrendigs.fromJson(json);
  }
}
