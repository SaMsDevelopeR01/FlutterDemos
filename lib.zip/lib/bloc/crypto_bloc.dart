import 'package:cryptocoin/models/crypto_chart_data.dart';
import 'package:cryptocoin/models/crypto_exchangelist_data.dart';
import 'package:cryptocoin/models/crypto_list_data.dart';
import 'package:cryptocoin/models/crypto_trendigs.dart';
import 'package:cryptocoin/models/exchangerate/exchange_rates.dart';
import 'package:cryptocoin/repository/crypto_repository.dart';
import 'package:meta/meta.dart';
import 'package:bloc/bloc.dart';
import 'crypto_event.dart';
import 'crypto_state.dart';

class CryptoBloc extends Bloc<CryptoEvent, CryptoState> {
  final CryptoRepository repository;

  CryptoBloc({@required this.repository}) : assert(repository != null);

  @override
  CryptoState get initialState => CryptoEmpty();

  @override
  Stream<CryptoState> mapEventToState(CryptoEvent event) async* {
    if (event is FetchCryptoList) {
      yield CryptoLoading();
      try {
        final List<CryptoList> cryptoList = await repository.fetchCryptoList();
        yield CryptoLoaded(cryptoList: cryptoList);
      } catch (e) {
        print(e);
        yield CryptoError();
      }
    }
    if (event is FetchCryptoChart) {
      yield ChartLoading();
      try {
        print("${event.paramCoin} and ${event.paramDuration}");

        final CryptoChart cryptoChart = await repository.fetchCryptoChart(event.paramCoin,event.paramDuration);
        yield ChartLoaded(cryptoChart: cryptoChart);
      } catch (e) {
        print(e);
        yield ChartError();
      }
    }
    if (event is FetchCryptoExchageRates) {
      yield ExchangeRateLoading();
      try {
        final ExchangeRates ExchangeRate =
            await repository.fetchCryptoExchangeRates();
        yield ExchangeRateLoaded(ExchangeRate: ExchangeRate);
      } catch (e) {
        print(e);
        yield ExchangeRateError();
      }
    }
    if (event is FetchCryptoExchageList) {
      yield ExchangeListLoading();
      try {
        final List<CryptoExchangeList> cryptoExchangeList =
            await repository.fetchCryptoExchangeList();
        yield ExchangeListLoaded(cryptoExchangeList: cryptoExchangeList);
      } catch (e) {
        print(e);
        yield ExchangeListError();
      }
    }
    if (event is FetchCryptoTrendig) {
      yield TrendingLoading();
      try {
        final CryptoTrendigs cryptoTrendigs =
            await repository.fetchCryptoTrendig();
        yield TrendingLoaded(cryptoTrendigs: cryptoTrendigs);
      } catch (e) {
        print(e);
        yield TrendingError();
      }
    }
  }
}
