import 'package:equatable/equatable.dart';

abstract class CryptoEvent extends Equatable {
  const CryptoEvent();
}

//price list
class FetchCryptoList extends CryptoEvent {
  const FetchCryptoList();

  @override
  List<Object> get props => [];
}

//market chart
class FetchCryptoChart extends CryptoEvent {
  final paramCoin;
  final paramDuration;
  const FetchCryptoChart(this.paramCoin, this.paramDuration);


  @override
  List<Object> get props => [];
}

//Exchange rates
class FetchCryptoExchageRates extends CryptoEvent {
  const FetchCryptoExchageRates();

  @override
  List<Object> get props => [];
}

//Exchange List
class FetchCryptoExchageList extends CryptoEvent {
  const FetchCryptoExchageList();

  @override
  List<Object> get props => [];
}

//Trendings
class FetchCryptoTrendig extends CryptoEvent {
  const FetchCryptoTrendig();

  @override
  List<Object> get props => [];
}
