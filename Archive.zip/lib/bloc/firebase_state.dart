import 'package:firebasereg/models/user.dart';
import 'package:meta/meta.dart';
import 'package:equatable/equatable.dart';

abstract class FirebaseState extends Equatable {
  const FirebaseState();

  @override
  List<Object> get props => [];
}

/*
***Register State***
 */

class RegisterEmpty extends FirebaseState {}

class RegisterLoading extends FirebaseState {}

class RegisterLoaded extends FirebaseState {
  final User register;

  const RegisterLoaded({@required this.register}) : assert(register != null);

  @override
  List<Object> get props => [];
}

class RegisterError extends FirebaseState {}
/*
***Login State***
 */

class LoginEmpty extends FirebaseState {}

class LoginLoading extends FirebaseState {}

class LoginLoaded extends FirebaseState {
  final User login;

  const LoginLoaded({@required this.login}) : assert(login != null);

  @override
  List<Object> get props => [];
}

class LoginError extends FirebaseState {}
