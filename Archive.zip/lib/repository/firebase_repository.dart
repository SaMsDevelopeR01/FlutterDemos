import 'dart:async';
import 'package:firebasereg/models/user.dart';
import 'package:firebasereg/repository/firebase_api_client.dart';
import 'package:meta/meta.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseRepository {
  final FirebaseApiClient firebaseApiClient;
  CollectionReference users = FirebaseFirestore.instance.collection('users');

  FirebaseRepository({@required this.firebaseApiClient})
      : assert(firebaseApiClient != null);

  Future<User> fetchRegister(String email, String password,
      String confirmPassword, String phno) async {
    return await firebaseApiClient.fetchRegister(
        email, password, confirmPassword, phno);
  }

  Future<User> fetchLogin(String email, String password) async {
    return await firebaseApiClient.fetchLogin(email, password);
  }
}
